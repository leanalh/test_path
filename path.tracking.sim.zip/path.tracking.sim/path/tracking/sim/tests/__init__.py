try:
    from .test_model import TestExtensionModel
except ImportError:
    pass
