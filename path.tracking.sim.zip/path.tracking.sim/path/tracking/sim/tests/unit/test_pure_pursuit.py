"""
test_pure_pursuit.py – Kit-free unit tests for domain.pure_pursuit.compute_steer.

Run with:  pytest path/tracking/sim/tests/unit/test_pure_pursuit.py
"""

import math

import numpy as np
import pytest

from domain.pure_pursuit import compute_steer

MAX_STEER = math.pi / 3   # 60° – same as PurePursuitScenario.MAX_STEER_ANGLE_RADIANS


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _axle_pair(heading_deg: float, wheelbase: float = 200.0):
    """Return (front_axle, rear_axle) for a vehicle pointing at *heading_deg*
    (0 = +Z forward, positive = clockwise when viewed from above)."""
    angle = math.radians(heading_deg)
    fwd = np.array([math.sin(angle), 0.0, math.cos(angle)])
    rear = np.array([0.0, 0.0, 0.0])
    front = rear + fwd * wheelbase
    return front, rear


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_straight_ahead_steer_near_zero():
    """Destination directly ahead → steering should be ≈ 0."""
    front, rear = _axle_pair(0.0)
    dest = np.array([0.0, 0.0, 1000.0])
    steer = compute_steer(front, rear, dest, MAX_STEER)
    assert abs(steer) < 0.05, f"Expected ~0 steer, got {steer}"


def test_90_degrees_left():
    """Destination 90° to the left → negative (left) steering, magnitude close to ±1."""
    front, rear = _axle_pair(0.0)
    dest = np.array([-500.0, 0.0, 0.0])
    steer = compute_steer(front, rear, dest, MAX_STEER)
    assert steer < -0.5, f"Expected strong left steer, got {steer}"


def test_90_degrees_right():
    """Destination 90° to the right → positive (right) steering, magnitude close to ±1."""
    front, rear = _axle_pair(0.0)
    dest = np.array([500.0, 0.0, 0.0])
    steer = compute_steer(front, rear, dest, MAX_STEER)
    assert steer > 0.5, f"Expected strong right steer, got {steer}"


def test_overshoot_clamped_to_plus_one():
    """Extreme right turn must be clamped to +1."""
    front, rear = _axle_pair(0.0)
    # Destination almost directly behind-right forces theta >> max steer.
    dest = np.array([50.0, 0.0, -5000.0])
    steer = compute_steer(front, rear, dest, MAX_STEER)
    assert steer == pytest.approx(1.0, abs=1e-9) or steer <= 1.0, (
        f"Expected steer ≤ 1.0, got {steer}"
    )


def test_overshoot_clamped_to_minus_one():
    """Extreme left turn must be clamped to -1."""
    front, rear = _axle_pair(0.0)
    dest = np.array([-50.0, 0.0, -5000.0])
    steer = compute_steer(front, rear, dest, MAX_STEER)
    assert steer == pytest.approx(-1.0, abs=1e-9) or steer >= -1.0, (
        f"Expected steer ≥ -1.0, got {steer}"
    )


def test_degenerate_zero_distance_returns_zero():
    """Coincident front/rear axle positions must not raise and must return 0."""
    front = rear = np.array([0.0, 0.0, 0.0])
    dest = np.array([100.0, 0.0, 0.0])
    steer = compute_steer(front, rear, dest, MAX_STEER)
    assert steer == 0.0
