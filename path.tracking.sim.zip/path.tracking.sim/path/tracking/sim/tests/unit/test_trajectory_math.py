"""
test_trajectory_math.py – Kit-free unit tests for domain.trajectory_math.

Run with:  pytest path/tracking/sim/tests/unit/test_trajectory_math.py
"""

import numpy as np
import pytest

from domain.trajectory_math import advance_pointer, is_within_lookahead


# ---------------------------------------------------------------------------
# is_within_lookahead
# ---------------------------------------------------------------------------

def test_within_lookahead_returns_true():
    vehicle = np.array([0.0, 0.0, 0.0])
    waypoint = np.array([100.0, 0.0, 0.0])
    assert is_within_lookahead(vehicle, waypoint, lookahead=200.0) is True


def test_outside_lookahead_returns_false():
    vehicle = np.array([0.0, 0.0, 0.0])
    waypoint = np.array([300.0, 0.0, 0.0])
    assert is_within_lookahead(vehicle, waypoint, lookahead=200.0) is False


def test_exactly_on_boundary_is_not_within():
    """Distance == lookahead should return False (strict less-than)."""
    vehicle = np.array([0.0, 0.0, 0.0])
    waypoint = np.array([200.0, 0.0, 0.0])
    assert is_within_lookahead(vehicle, waypoint, lookahead=200.0) is False


def test_3d_distance_used():
    """Confirm the full 3-D Euclidean distance is used, not a 2-D projection."""
    vehicle = np.array([0.0, 0.0, 0.0])
    waypoint = np.array([100.0, 100.0, 100.0])   # distance ≈ 173.2
    assert is_within_lookahead(vehicle, waypoint, lookahead=200.0) is True
    assert is_within_lookahead(vehicle, waypoint, lookahead=100.0) is False


# ---------------------------------------------------------------------------
# advance_pointer
# ---------------------------------------------------------------------------

def test_advance_normal():
    assert advance_pointer(0, 5, close_loop=False) == 1
    assert advance_pointer(3, 5, close_loop=False) == 4


def test_advance_open_loop_at_end_stays():
    """Open loop: pointer must not exceed num_points - 1."""
    assert advance_pointer(4, 5, close_loop=False) == 4


def test_advance_closed_loop_wraps():
    """Closed loop: last index wraps back to 0."""
    assert advance_pointer(4, 5, close_loop=True) == 0


def test_advance_closed_loop_mid_sequence():
    """Closed loop mid-sequence must still advance normally."""
    assert advance_pointer(2, 5, close_loop=True) == 3
