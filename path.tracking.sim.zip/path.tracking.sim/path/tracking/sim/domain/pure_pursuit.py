"""
pure_pursuit.py – Standalone Pure Pursuit steering math.

No USD, no omni, no carb, no pxr imports.  Uses only numpy and math so that
unit tests can run without a Kit context.

Reference:
  "Implementation of the Pure Pursuit Path Tracking Algorithm", R.C. Coulter, 1992.
  https://www.ri.cmu.edu/pub_files/pub3/coulter_r_craig_1992_1/coulter_r_craig_1992_1.pdf
"""

import math

import numpy as np


def compute_steer(
    front_axle_pos: np.ndarray,
    rear_axle_pos: np.ndarray,
    dest_pos: np.ndarray,
    max_steer_angle_radians: float,
) -> float:
    """Return a steering value in [-1, 1].  Positive = steer right.

    All positions are shape-(3,) arrays in the XZ plane (Y-up convention);
    the Y component is assumed to be already zeroed by the caller.

    Args:
        front_axle_pos:         World-space front-axle midpoint (Y=0).
        rear_axle_pos:          World-space rear-axle midpoint  (Y=0).
        dest_pos:               World-space lookahead destination (Y=0).
        max_steer_angle_radians: Clamp threshold (absolute value).

    Returns:
        Normalised steering command in [-1, 1].
    """
    lookahead = dest_pos - rear_axle_pos
    forward = front_axle_pos - rear_axle_pos

    lookahead_dist = float(np.linalg.norm(lookahead))
    forward_dist = float(np.linalg.norm(forward))

    if lookahead_dist < 1e-6 or forward_dist < 1e-6:
        return 0.0

    lookahead = lookahead / lookahead_dist
    forward = forward / forward_dist

    # Signed angle in the XZ plane (Y-up, left-handed rotation).
    dot = float(lookahead[0] * forward[0] + lookahead[2] * forward[2])
    cross = float(lookahead[0] * forward[2] - lookahead[2] * forward[0])
    alpha = math.atan2(cross, dot)

    theta = math.atan(2.0 * forward_dist * math.sin(alpha) / lookahead_dist)
    return float(np.clip(theta / max_steer_angle_radians, -1.0, 1.0))
