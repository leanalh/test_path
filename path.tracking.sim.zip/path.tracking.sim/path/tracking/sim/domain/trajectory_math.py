"""
trajectory_math.py – Standalone waypoint / lookahead utilities.

No USD, no omni, no carb, no pxr imports.  Uses only numpy so that unit tests
can run without a Kit context.
"""

import numpy as np


def is_within_lookahead(
    vehicle_pos: np.ndarray,
    waypoint: np.ndarray,
    lookahead: float,
) -> bool:
    """Return True if *waypoint* lies within *lookahead* distance of *vehicle_pos*.

    Args:
        vehicle_pos: Shape-(3,) world-space vehicle position.
        waypoint:    Shape-(3,) world-space waypoint position.
        lookahead:   Lookahead radius in stage units (must be > 0).

    Returns:
        True when ``‖vehicle_pos − waypoint‖ < lookahead``.
    """
    return float(np.linalg.norm(vehicle_pos - waypoint)) < lookahead


def advance_pointer(pointer: int, num_points: int, close_loop: bool) -> int:
    """Return the next waypoint index, optionally wrapping for closed loops.

    Args:
        pointer:     Current zero-based waypoint index.
        num_points:  Total number of waypoints in the trajectory.
        close_loop:  When True the sequence wraps from the last point back to 0.

    Returns:
        Next index, or the unchanged *pointer* if the trajectory is open and
        already at the final waypoint.
    """
    next_ptr = pointer + 1
    if next_ptr >= num_points:
        return 0 if close_loop else pointer
    return next_ptr
