try:
    from .scripts.extension import PathTrackingExtension
except ImportError:
    # carb/omni not available outside a Kit runtime (e.g. plain pytest).
    pass
