"""
conftest.py – pytest configuration for Kit-free unit tests.

Adds path/tracking/sim/ to sys.path so that ``from domain.xxx import ...``
resolves without needing a Kit context.
"""

import os
import sys

_DOMAIN_PARENT = os.path.join(os.path.dirname(__file__), "path", "tracking", "sim")
if _DOMAIN_PARENT not in sys.path:
    sys.path.insert(0, _DOMAIN_PARENT)
