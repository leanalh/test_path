# Changelog

## [3.0.0] - 2026-03-09

### Changed
- Target runtime upgraded to Kit 106.5 / 109 (Omniverse USD Composer 2025.x).

### Fixed
- `extension.toml`: dependency renamed from `"omni.physx.vehicle"` to `"omni.physxvehicle"` (correct name in Kit 106+). This was the primary cause of the extension failing to load.
- `scene_draw.py`: `viewport_window.get_frame()` is now called as a context manager with the real `ext_id` string (Kit 106+ API). `SceneDebugRenderer.__init__` accepts `ext_id: str` as its first argument.
- `path_tracker.py`: `PurePursuitScenario.__init__` accepts `ext_id: str` and forwards it to `SceneDebugRenderer`.
- `model.py`: `load_simulation()` passes `self._ext_id` when constructing each `PurePursuitScenario`.

### Added
- `domain/pure_pursuit.py`: USD-free `compute_steer()` function extracted from `PurePursuitPathTracker` (numpy only, no pxr/omni/carb).
- `domain/trajectory_math.py`: USD-free `is_within_lookahead()` and `advance_pointer()` helpers.
- `tests/unit/test_pure_pursuit.py`: 6 pytest cases — straight ahead, 90° left, 90° right, ±1 overshoot clamp, degenerate zero-distance.
- `tests/unit/test_trajectory_math.py`: 7 pytest cases — within/outside/boundary lookahead, 3-D distance, open/closed loop advancement.

## [2.0.0] - 2026-03-04

### Added
- Scene-based debug visualisation using `omni.ui.scene`, replacing the deprecated `omni.debugdraw` dependency.
- Graceful fallback when no viewport is active (debug overlay silently disabled).

### Changed
- Extension renamed from `ext.path.tracking` to `path.tracking.sim` to follow NVIDIA naming conventions.
- Module restructured under `omni/path/tracking/` namespace.
- Minimum target: Kit 105 / Omniverse USD Composer 2023.2.
- Async operations now use `asyncio.ensure_future` rather than the low-level `run_coroutine_threadsafe`.

### Fixed
- `Vehicle.accelerate()` was inconsistently reading the prim via `_vehicle()` instead of `_prim`.
- `PurePursuitScenario.teardown()` called `self._dest.teardown()` on an always-`None` attribute.
- `ExtensionModel.load_sample_vehicle()` silently discarded the computed `root_vehicle_path` by
  overwriting it before passing it to the wizard command.
- Rear-steering inversion logic is now preserved but disabled in the UI until the upstream
  PhysX Vehicle regression is resolved.

## [1.0.2-beta] - 2023-01-01 (ext.path.tracking – archived)

- Initial public release as `ext.path.tracking`.
- Known regressions: preset vehicle scene broken in Kit 104, forklift model removed, rear steering UI disabled.
