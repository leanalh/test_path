import logging

import omni.ext
import omni.kit.app

from .path_tracker import PathTracker
from .ui_builder import UIBuilder

logger = logging.getLogger(__name__)


class SimplePathTrackingExtension(omni.ext.IExt):
    """Kit 109 extension entry point.

    Wires together PathTracker ↔ UIBuilder and drives the update loop via the
    application's update event stream (no deprecated IApp callback style).
    """

    def on_startup(self, ext_id: str):
        logger.info("simple_path_tracking starting up (ext_id=%s)", ext_id)

        self._tracker = PathTracker()
        self._ui = UIBuilder(self._tracker)

        # Subscribe to the application update loop
        app = omni.kit.app.get_app()
        self._update_sub = (
            app.get_update_event_stream()
            .create_subscription_to_pop(self._on_update, name="simple_path_tracking")
        )

        logger.info("simple_path_tracking started")

    def on_shutdown(self):
        logger.info("simple_path_tracking shutting down")

        # Cancel the update subscription first so no more ticks fire
        self._update_sub = None

        self._tracker.stop()

        if self._ui:
            self._ui.destroy()
            self._ui = None

        self._tracker = None
        logger.info("simple_path_tracking shut down")

    # ─── Update tick ──────────────────────────────────────────────────────────

    def _on_update(self, event):
        """Called every frame by the application event stream."""
        dt: float = event.payload.get("dt", 0.016)
        status = self._tracker.update(dt)
        if status and self._ui:
            self._ui.update_status(status)
