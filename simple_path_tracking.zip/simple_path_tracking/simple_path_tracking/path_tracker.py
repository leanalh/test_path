import logging
import math
from typing import List, Optional

from pxr import Gf, Usd, UsdGeom

import omni.usd

logger = logging.getLogger(__name__)


class PathTracker:
    """Moves a vehicle prim along a BasisCurve using kinematic transform updates.

    No PhysX — pure USD xform writes every update tick.
    """

    def __init__(self):
        self._vehicle_path: str = ""
        self._curve_path: str = ""
        self._speed_ms: float = 5.0
        self._tire_diameter_cm: float = 60.0

        self._samples: List[Gf.Vec3d] = []
        self._sample_index: int = 0
        self._accumulated_dist: float = 0.0

        self._wheel_prims: List[Usd.Prim] = []
        self._total_rotation: float = 0.0

        self._initial_xform: Optional[Gf.Matrix4d] = None
        self.is_running: bool = False

    # ─── Public API ───────────────────────────────────────────────────────────

    def load(
        self,
        vehicle_path: str,
        curve_path: str,
        speed_ms: float,
        tire_diameter_cm: float,
    ) -> str:
        """Validate prims, sample curve, cache wheel prims.

        Returns a human-readable status string — never raises.
        """
        stage = omni.usd.get_context().get_stage()
        if stage is None:
            return "Error: No stage is open"

        # Validate vehicle prim
        vehicle_prim = stage.GetPrimAtPath(vehicle_path)
        if not vehicle_prim or not vehicle_prim.IsValid():
            return f"Error: Vehicle prim not found at '{vehicle_path}'"

        # Validate curve prim
        curve_prim = stage.GetPrimAtPath(curve_path)
        if not curve_prim or not curve_prim.IsValid():
            return f"Error: Curve prim not found at '{curve_path}'"

        basis_curves = UsdGeom.BasisCurves(curve_prim)
        if not basis_curves:
            return f"Error: Prim at '{curve_path}' is not a BasisCurves"

        points_attr = basis_curves.GetPointsAttr()
        if not points_attr or not points_attr.HasValue():
            return f"Error: BasisCurves at '{curve_path}' has no points attribute"

        raw_points = points_attr.Get()
        if not raw_points or len(raw_points) < 2:
            count = len(raw_points) if raw_points else 0
            return f"Error: BasisCurves needs ≥ 2 points, got {count}"

        # Sample curve into dense polyline
        self._samples = self._sample_curve(
            [Gf.Vec3d(p[0], p[1], p[2]) for p in raw_points], n=500
        )
        if len(self._samples) < 2:
            return "Error: Curve sampling produced fewer than 2 samples"

        self._vehicle_path = vehicle_path
        self._curve_path = curve_path
        self._speed_ms = float(speed_ms)
        self._tire_diameter_cm = float(tire_diameter_cm)

        # Reset traversal state
        self._sample_index = 0
        self._accumulated_dist = 0.0
        self._total_rotation = 0.0
        self.is_running = False

        # Store initial vehicle xform for reset
        self._initial_xform = UsdGeom.Xformable(vehicle_prim).GetLocalTransformation()

        # Cache wheel prims (warn but don't fail if none found)
        self._wheel_prims = self._find_wheel_prims(vehicle_prim)
        if not self._wheel_prims:
            logger.warning(
                "No wheel prims (WheelFL/FR/RL/RR) found under '%s' — "
                "vehicle body will still move",
                vehicle_path,
            )

        logger.info(
            "PathTracker loaded: vehicle='%s', curve='%s', %d samples, %d wheels",
            vehicle_path,
            curve_path,
            len(self._samples),
            len(self._wheel_prims),
        )
        return (
            f"Loaded — {len(self._samples)} path samples, "
            f"{len(self._wheel_prims)} wheel(s) found"
        )

    def start(self):
        if not self._samples:
            logger.warning("start() called but no path is loaded — call load() first")
            return
        self.is_running = True
        logger.info("Path tracker started")

    def stop(self):
        self.is_running = False
        logger.info("Path tracker stopped")

    def reset(self):
        """Stop and restore the vehicle to its initial transform."""
        self.is_running = False
        self._sample_index = 0
        self._accumulated_dist = 0.0
        self._total_rotation = 0.0

        if self._vehicle_path and self._initial_xform is not None:
            stage = omni.usd.get_context().get_stage()
            if stage:
                vehicle_prim = stage.GetPrimAtPath(self._vehicle_path)
                if vehicle_prim and vehicle_prim.IsValid():
                    xform_op = UsdGeom.Xformable(vehicle_prim).MakeMatrixXform()
                    xform_op.Set(self._initial_xform)

        logger.info("Path tracker reset")

    def update(self, dt: float) -> str:
        """Advance the vehicle one tick.

        Returns a status string for display; returns "" if not running.
        The entire tick is wrapped in try/except — never raises.
        """
        if not self.is_running or not self._samples:
            return ""

        try:
            last_idx = len(self._samples) - 1

            # Already at end?
            if self._sample_index >= last_idx:
                self.stop()
                return "End of path reached"

            # Advance cumulative distance
            self._accumulated_dist += self._speed_ms * dt

            # Walk segments until we exhaust accumulated distance
            while self._sample_index < last_idx - 1:
                seg_vec = (
                    self._samples[self._sample_index + 1]
                    - self._samples[self._sample_index]
                )
                seg_len = seg_vec.GetLength()
                if seg_len < 1e-9:
                    # Degenerate segment — skip it
                    self._sample_index += 1
                    continue
                if self._accumulated_dist <= seg_len:
                    break
                self._accumulated_dist -= seg_len
                self._sample_index += 1

            # Interpolate position and forward direction within current segment
            if self._sample_index >= last_idx:
                pos = self._samples[last_idx]
                forward = (
                    self._samples[last_idx] - self._samples[last_idx - 1]
                ).GetNormalized()
                self.stop()
                return "End of path reached"
            else:
                seg_vec = (
                    self._samples[self._sample_index + 1]
                    - self._samples[self._sample_index]
                )
                seg_len = seg_vec.GetLength()
                t = (
                    min(self._accumulated_dist / seg_len, 1.0)
                    if seg_len > 1e-9
                    else 0.0
                )
                pos = self._samples[self._sample_index] + seg_vec * t
                forward = seg_vec.GetNormalized()

            # Write vehicle transform
            matrix = self._build_transform(pos, forward)
            stage = omni.usd.get_context().get_stage()
            if stage:
                vehicle_prim = stage.GetPrimAtPath(self._vehicle_path)
                if vehicle_prim and vehicle_prim.IsValid():
                    xform_op = UsdGeom.Xformable(vehicle_prim).MakeMatrixXform()
                    xform_op.Set(matrix)

            # Spin wheels
            tire_radius_m = self._tire_diameter_cm / 200.0
            if tire_radius_m > 1e-9:
                angular_velocity = self._speed_ms / tire_radius_m  # rad/s
                delta_angle = angular_velocity * dt                  # rad/tick
                self._spin_wheels(delta_angle)

            progress = self._sample_index / max(last_idx, 1) * 100.0
            return f"Running… {progress:.0f}%"

        except Exception as exc:
            self.stop()
            logger.error("PathTracker.update() exception: %s", exc, exc_info=True)
            return f"Error: {exc}"

    # ─── Private helpers ──────────────────────────────────────────────────────

    def _sample_curve(self, points: List[Gf.Vec3d], n: int = 500) -> List[Gf.Vec3d]:
        """Resample raw control points into *n* evenly-spaced polyline samples."""
        if len(points) < 2:
            return list(points)

        # Build cumulative chord-length table
        chords: List[float] = [0.0]
        for i in range(1, len(points)):
            chords.append(chords[-1] + (points[i] - points[i - 1]).GetLength())

        total = chords[-1]
        if total < 1e-9:
            return list(points)

        samples: List[Gf.Vec3d] = []
        for k in range(n):
            target = total * k / (n - 1)

            # Binary search for the enclosing segment
            lo, hi = 0, len(chords) - 1
            while hi - lo > 1:
                mid = (lo + hi) // 2
                if chords[mid] <= target:
                    lo = mid
                else:
                    hi = mid

            seg_len = chords[hi] - chords[lo]
            t = (target - chords[lo]) / seg_len if seg_len > 1e-9 else 0.0
            samples.append(points[lo] + (points[hi] - points[lo]) * t)

        return samples

    def _build_transform(self, pos: Gf.Vec3d, forward: Gf.Vec3d) -> Gf.Matrix4d:
        """Build a world-space rotation matrix from a position and forward vector.

        Assumes Z-up world.  The vehicle's local +X axis is aligned to *forward*.
        """
        fwd = forward.GetNormalized()

        # Yaw angle around world Z from the forward direction in the XY plane
        yaw_deg = math.degrees(math.atan2(fwd[1], fwd[0]))
        rotation = Gf.Rotation(Gf.Vec3d(0.0, 0.0, 1.0), yaw_deg)

        # Gf.Matrix4d(rotation, translation) builds a proper rigid-body matrix
        return Gf.Matrix4d(rotation, pos)

    def _find_wheel_prims(self, vehicle_prim: Usd.Prim) -> List[Usd.Prim]:
        """Recursively search for WheelFL/FR/RL/RR under *vehicle_prim*."""
        target_names = {"wheelfl", "wheelfr", "wheelrl", "wheelrr"}
        found: List[Usd.Prim] = []

        def _recurse(prim: Usd.Prim):
            for child in prim.GetChildren():
                if child.GetName().lower() in target_names:
                    found.append(child)
                    logger.info("Found wheel prim: %s", child.GetPath())
                _recurse(child)

        _recurse(vehicle_prim)
        return found

    def _spin_wheels(self, delta_angle_rad: float):
        """Apply an incremental rotation around each wheel's local X axis."""
        stage = omni.usd.get_context().get_stage()
        if not stage:
            return

        spin_deg = math.degrees(delta_angle_rad)
        spin_mat = Gf.Matrix4d(
            Gf.Rotation(Gf.Vec3d(1.0, 0.0, 0.0), spin_deg), Gf.Vec3d(0.0, 0.0, 0.0)
        )

        for wheel_prim in self._wheel_prims:
            if not wheel_prim.IsValid():
                continue
            xformable = UsdGeom.Xformable(wheel_prim)
            current = xformable.GetLocalTransformation()
            # Post-multiply: apply spin in the wheel's own local space
            new_xform = current * spin_mat
            xform_op = xformable.MakeMatrixXform()
            xform_op.Set(new_xform)
