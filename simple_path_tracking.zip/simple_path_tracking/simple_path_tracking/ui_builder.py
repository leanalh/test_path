import logging

import omni.ui as ui
import omni.usd

from .path_tracker import PathTracker

logger = logging.getLogger(__name__)

# ─── Layout constants (mirrored from the reference ext.path.tracking ui.py) ──
LABEL_WIDTH = 150
DEFAULT_BTN_HEIGHT = 22
LINE_HEIGHT = 32
ELEM_MARGIN = 4

# ─── Style dictionaries ───────────────────────────────────────────────────────
_COLLAPSABLE_FRAME_STYLE = {
    "CollapsableFrame": {
        "background_color": 0xFF333333,
        "secondary_color": 0xFF333333,
        "color": 0xFFCCCCCC,
        "border_radius": 4,
        "border_color": 0x0,
        "border_width": 0,
        "font_size": 14,
        "padding": ELEM_MARGIN * 2,
        "margin_width": ELEM_MARGIN,
        "margin_height": ELEM_MARGIN,
    },
    "CollapsableFrame:hovered": {"secondary_color": 0xFF3D3D3D},
    "CollapsableFrame:pressed": {"secondary_color": 0xFF333333},
}

_IMPORTANT_BUTTON_STYLE = {
    "Button": {
        "background_color": 0x7000B976,
        "border_radius": 4,
        "border_color": 0xFF00B976,
        "border_width": 1,
    },
    "Button:hovered": {"background_color": 0x9900B976},
    "Button:pressed": {"background_color": 0xCC00B976},
    "Button.Label": {"color": 0xFFFFFFFF, "font_size": 14},
}

_STANDARD_BUTTON_STYLE = {
    "Button": {
        "background_color": 0xFF444444,
        "border_radius": 4,
        "border_color": 0xFF555555,
        "border_width": 1,
    },
    "Button:hovered": {"background_color": 0xFF4E4E4E},
    "Button:pressed": {"background_color": 0xFF3A3A3A},
    "Button.Label": {"color": 0xFFCCCCCC, "font_size": 14},
}

_LABEL_STYLE = {"Label": {"color": 0xFFCCCCCC, "font_size": 14}}

_STATUS_STYLE = {
    "Label": {"color": 0xFF00B976, "font_size": 13},
}

_FIELD_STYLE = {
    "Field": {
        "background_color": 0xFF1E1E1E,
        "border_radius": 4,
        "border_color": 0xFF555555,
        "border_width": 1,
        "color": 0xFFCCCCCC,
        "font_size": 14,
    },
    "Field:focused": {"border_color": 0xFF00B976},
}


class UIBuilder:
    """Owns and builds the 'Simple Path Tracker' omni.ui window.

    Construction idioms and visual style follow the ext.path.tracking reference.
    """

    def __init__(self, tracker: PathTracker):
        self._tracker = tracker
        self._window: ui.Window = None

        # Widget references retained for programmatic updates
        self._vehicle_field: ui.StringField = None
        self._curve_field: ui.StringField = None
        self._speed_field: ui.FloatField = None
        self._tire_field: ui.FloatField = None
        self._status_label: ui.Label = None
        self._start_btn: ui.Button = None
        self._stop_btn: ui.Button = None

        self._build_window()

    # ─── Public ───────────────────────────────────────────────────────────────

    def update_status(self, msg: str):
        """Called from the extension's update subscription with the latest status."""
        if self._status_label and msg:
            self._status_label.text = msg

    def destroy(self):
        if self._window:
            self._window.destroy()
            self._window = None

    # ─── Window construction ─────────────────────────────────────────────────

    def _build_window(self):
        self._window = ui.Window(
            "Simple Path Tracker",
            width=420,
            height=0,          # auto-size
            dockPreference=ui.DockPreference.LEFT_BOTTOM,
        )
        with self._window.frame:
            with ui.VStack(spacing=ELEM_MARGIN):
                self._build_path_setup_frame()
                self._build_parameters_frame()
                self._build_controls_frame()
                self._build_status_frame()

    # ─── Collapsable frames ───────────────────────────────────────────────────

    def _build_path_setup_frame(self):
        with ui.CollapsableFrame(
            "Path Setup",
            height=0,
            collapsed=False,
            style=_COLLAPSABLE_FRAME_STYLE,
        ):
            with ui.VStack(spacing=ELEM_MARGIN, height=0):
                ui.Spacer(height=ELEM_MARGIN)
                self._build_prim_row(
                    label="Vehicle Prim Path",
                    tooltip="USD path to the vehicle root prim, e.g. /World/Vehicle",
                    on_pick=self._on_pick_vehicle,
                    field_ref_setter=lambda f: setattr(self, "_vehicle_field", f),
                )
                ui.Spacer(height=ELEM_MARGIN)
                self._build_prim_row(
                    label="Curve Prim Path",
                    tooltip="USD path to the BasisCurves prim defining the route",
                    on_pick=self._on_pick_curve,
                    field_ref_setter=lambda f: setattr(self, "_curve_field", f),
                )
                ui.Spacer(height=ELEM_MARGIN)

    def _build_parameters_frame(self):
        with ui.CollapsableFrame(
            "Parameters",
            height=0,
            collapsed=False,
            style=_COLLAPSABLE_FRAME_STYLE,
        ):
            with ui.VStack(spacing=ELEM_MARGIN, height=0):
                ui.Spacer(height=ELEM_MARGIN)

                # Speed row
                with ui.HStack(height=DEFAULT_BTN_HEIGHT):
                    ui.Label(
                        "Speed (m/s)",
                        width=LABEL_WIDTH,
                        style=_LABEL_STYLE,
                        tooltip="Constant travel speed along the curve in metres per second",
                    )
                    self._speed_field = ui.FloatField(
                        height=DEFAULT_BTN_HEIGHT,
                        style=_FIELD_STYLE,
                    )
                    self._speed_field.model.set_value(5.0)

                ui.Spacer(height=ELEM_MARGIN)

                # Tire diameter row
                with ui.HStack(height=DEFAULT_BTN_HEIGHT):
                    ui.Label(
                        "Tire Diameter (cm)",
                        width=LABEL_WIDTH,
                        style=_LABEL_STYLE,
                        tooltip="Outer tire diameter in centimetres — used to compute wheel spin rate",
                    )
                    self._tire_field = ui.FloatField(
                        height=DEFAULT_BTN_HEIGHT,
                        style=_FIELD_STYLE,
                    )
                    self._tire_field.model.set_value(60.0)

                ui.Spacer(height=ELEM_MARGIN)

                # Load button — full width, accent colour
                with ui.HStack(height=DEFAULT_BTN_HEIGHT):
                    ui.Spacer(width=LABEL_WIDTH)
                    ui.Button(
                        "Load",
                        height=DEFAULT_BTN_HEIGHT,
                        style=_IMPORTANT_BUTTON_STYLE,
                        tooltip="Validate prims and sample the curve.  Must be clicked before Start.",
                        clicked_fn=self._on_load,
                    )

                ui.Spacer(height=ELEM_MARGIN)

    def _build_controls_frame(self):
        with ui.CollapsableFrame(
            "Controls",
            height=0,
            collapsed=False,
            style=_COLLAPSABLE_FRAME_STYLE,
        ):
            with ui.VStack(spacing=ELEM_MARGIN, height=0):
                ui.Spacer(height=ELEM_MARGIN)
                with ui.HStack(height=DEFAULT_BTN_HEIGHT, spacing=ELEM_MARGIN):
                    self._start_btn = ui.Button(
                        "Start",
                        height=DEFAULT_BTN_HEIGHT,
                        style=_IMPORTANT_BUTTON_STYLE,
                        tooltip="Begin moving the vehicle along the loaded path",
                        clicked_fn=self._on_start,
                    )
                    self._stop_btn = ui.Button(
                        "Stop",
                        height=DEFAULT_BTN_HEIGHT,
                        style=_STANDARD_BUTTON_STYLE,
                        tooltip="Pause movement (can be resumed with Start)",
                        clicked_fn=self._on_stop,
                    )
                    ui.Button(
                        "Reset",
                        height=DEFAULT_BTN_HEIGHT,
                        style=_STANDARD_BUTTON_STYLE,
                        tooltip="Stop and return the vehicle to its initial position",
                        clicked_fn=self._on_reset,
                    )
                ui.Spacer(height=ELEM_MARGIN)

    def _build_status_frame(self):
        with ui.CollapsableFrame(
            "Status",
            height=0,
            collapsed=False,
            style=_COLLAPSABLE_FRAME_STYLE,
        ):
            with ui.VStack(spacing=ELEM_MARGIN, height=0):
                ui.Spacer(height=ELEM_MARGIN)
                self._status_label = ui.Label(
                    "Ready",
                    word_wrap=True,
                    style=_STATUS_STYLE,
                )
                ui.Spacer(height=ELEM_MARGIN)

    # ─── Row builder ─────────────────────────────────────────────────────────

    def _build_prim_row(self, label: str, tooltip: str, on_pick, field_ref_setter):
        """One label + string field + Pick button row (mirrors path-tracking reference)."""
        with ui.HStack(height=DEFAULT_BTN_HEIGHT):
            ui.Label(label, width=LABEL_WIDTH, style=_LABEL_STYLE, tooltip=tooltip)
            field = ui.StringField(height=DEFAULT_BTN_HEIGHT, style=_FIELD_STYLE)
            field_ref_setter(field)
            ui.Spacer(width=ELEM_MARGIN)
            ui.Button(
                "Pick",
                width=40,
                height=DEFAULT_BTN_HEIGHT,
                style=_STANDARD_BUTTON_STYLE,
                tooltip="Use the current viewport selection",
                clicked_fn=on_pick,
            )

    # ─── Button callbacks ─────────────────────────────────────────────────────

    def _on_pick_vehicle(self):
        paths = omni.usd.get_context().get_selection().get_selected_prim_paths()
        if paths:
            self._vehicle_field.model.set_value(paths[0])
            logger.info("Vehicle prim path set from selection: %s", paths[0])
        else:
            self.update_status("Select a prim in the viewport first")

    def _on_pick_curve(self):
        paths = omni.usd.get_context().get_selection().get_selected_prim_paths()
        if paths:
            self._curve_field.model.set_value(paths[0])
            logger.info("Curve prim path set from selection: %s", paths[0])
        else:
            self.update_status("Select a prim in the viewport first")

    def _on_load(self):
        vehicle_path = self._vehicle_field.model.get_value_as_string().strip()
        curve_path = self._curve_field.model.get_value_as_string().strip()
        speed_ms = self._speed_field.model.get_value_as_float()
        tire_cm = self._tire_field.model.get_value_as_float()

        if not vehicle_path:
            self.update_status("Error: Vehicle prim path is empty")
            return
        if not curve_path:
            self.update_status("Error: Curve prim path is empty")
            return

        status = self._tracker.load(vehicle_path, curve_path, speed_ms, tire_cm)
        self.update_status(status)
        logger.info("Load result: %s", status)

    def _on_start(self):
        self._tracker.start()
        if self._tracker.is_running:
            self.update_status("Running…")

    def _on_stop(self):
        self._tracker.stop()
        self.update_status("Stopped")

    def _on_reset(self):
        self._tracker.reset()
        self.update_status("Reset — ready")
