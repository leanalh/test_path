
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Tuple

import carb.settings
import omni.usd
from pxr import Sdf

LOGGER = logging.getLogger("tracking_motion_path.render_preset_manager")

SUPPORTED_PREFIXES = ("rtx:", "renderer:")
PATH_TRACING_PREFIX = "rtx:pathtracing:"
REALTIME_PREFIX = "rtx:rtpt:"


@dataclass
class RenderPresetValidationResult:
    path: str
    is_valid: bool = False
    applied_key_count: int = 0
    renderer_mode: str = "Shared/Common"
    layer_identifier: Optional[str] = None
    valid_settings: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


class RenderPresetManager:
    """
    Validates and temporarily applies user-supplied USD render presets.

    Notes:
    - Accepts .usd / .usda
    - Reads customLayerData["renderSettings"]
    - Allows only rtx:* and renderer:* keys
    - Does NOT use os.path.exists(), so Nucleus/Omniverse paths work
    - Applies settings via carb.settings (matches stock omni.rtx.window.settings
      USDSettingsSerialiser.load_from_usd on Kit 109 and Kit 110). The Movie
      Capture backend reads renderer quality from carb.settings, not from USD
      session sublayers.
    """

    def __init__(self, schema: Optional[Mapping[str, Any]] = None):
        self._schema = dict(schema or {})
        self._active_layer_identifier: Optional[str] = None

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------
    def validate_file(self, preset_path: str) -> RenderPresetValidationResult:
        result = RenderPresetValidationResult(path=str(preset_path or ""))

        if not preset_path:
            result.errors.append("No preset path provided.")
            return result

        lower_path = str(preset_path).lower()
        if not lower_path.endswith((".usd", ".usda")):
            result.errors.append("Preset file must be .usd or .usda.")
            return result

        try:
            layer = Sdf.Layer.FindOrOpen(preset_path)
        except Exception as exc:
            result.errors.append(f"Failed to open preset layer: {exc}")
            LOGGER.exception("Could not open render preset: %s", preset_path)
            return result

        if not layer:
            result.errors.append("Failed to open preset layer.")
            return result

        result.layer_identifier = layer.identifier

        try:
            render_settings = layer.customLayerData.get("renderSettings", {})
        except Exception as exc:
            result.errors.append(f"Could not read customLayerData.renderSettings: {exc}")
            LOGGER.exception("Could not read renderSettings from preset: %s", preset_path)
            return result

        if not isinstance(render_settings, dict) or not render_settings:
            result.errors.append("Preset has no customLayerData.renderSettings dictionary.")
            return result

        result.renderer_mode = self._infer_renderer_mode(render_settings.keys())

        for key, value in render_settings.items():
            key = str(key)

            if not key.startswith(SUPPORTED_PREFIXES):
                result.warnings.append(f"Ignored unsupported key: {key}")
                continue

            expected_type = self._schema.get(key)
            if expected_type and not self._matches_schema_type(value, str(expected_type)):
                result.errors.append(
                    f"Type mismatch for {key}: expected {expected_type}, got {type(value).__name__}"
                )
                continue

            result.valid_settings[key] = value

        result.applied_key_count = len(result.valid_settings)

        if result.applied_key_count == 0:
            result.errors.append("No valid render settings were found in the preset.")

        result.is_valid = len(result.errors) == 0 and result.applied_key_count > 0
        return result

    # ------------------------------------------------------------------
    # Primary: carb.settings application (matches Movie Capture backend)
    # ------------------------------------------------------------------
    def apply_preset_to_carb_settings(
        self, preset_path: str
    ) -> Tuple[RenderPresetValidationResult, Dict[str, Tuple[bool, Any]]]:
        """
        Validate the preset and push every valid setting into carb.settings.
        Returns (validation_result, restore_token). The restore_token maps
        each carb key to (had_prior_value, prior_value). Pass it back to
        restore_settings() after capture finishes or is cancelled.
        """
        result = self.validate_file(preset_path)
        restore_token: Dict[str, Tuple[bool, Any]] = {}

        if not result.is_valid:
            return result, restore_token

        settings = carb.settings.get_settings()
        applied = 0

        for usd_key, value in result.valid_settings.items():
            carb_key = self._usd_key_to_carb_path(usd_key)

            prev: Any = None
            had_prior = False
            try:
                prev = settings.get(carb_key)
                had_prior = prev is not None
            except Exception:
                LOGGER.debug(
                    "carb.settings.get failed for %s; treating as unset.",
                    carb_key,
                    exc_info=True,
                )
                prev = None
                had_prior = False

            if carb_key in restore_token:
                # Duplicate USD key mapping to same carb path — keep the original prior.
                pass
            else:
                restore_token[carb_key] = (had_prior, prev)

            try:
                settings.set(carb_key, value)
                applied += 1
            except Exception:
                LOGGER.exception(
                    "Failed to apply render preset setting %s = %r", carb_key, value
                )

        LOGGER.info(
            "Render preset: applied %d/%d carb.settings entries from %s",
            applied,
            len(result.valid_settings),
            preset_path,
        )
        for carb_key, (had_prior, prev) in restore_token.items():
            LOGGER.debug(
                "  %s -> new=%r (prior_had=%s, prior=%r)",
                carb_key,
                result.valid_settings.get(self._carb_path_to_usd_key(carb_key)),
                had_prior,
                prev,
            )

        self._active_layer_identifier = result.layer_identifier
        return result, restore_token

    def apply_carb_settings_dict(
        self, settings_dict: Mapping[str, Any]
    ) -> Dict[str, Tuple[bool, Any]]:
        """
        Apply a pre-built {carb_key: value} dict to carb.settings and return a
        restore_token in the same shape as apply_preset_to_carb_settings.
        Used by live-preview flows that don't read from a USD file.
        """
        restore_token: Dict[str, Tuple[bool, Any]] = {}
        if not settings_dict:
            return restore_token

        settings = carb.settings.get_settings()
        applied = 0

        for carb_key, value in settings_dict.items():
            prev: Any = None
            had_prior = False
            try:
                prev = settings.get(carb_key)
                had_prior = prev is not None
            except Exception:
                LOGGER.debug(
                    "carb.settings.get failed for %s; treating as unset.",
                    carb_key,
                    exc_info=True,
                )

            if carb_key not in restore_token:
                restore_token[carb_key] = (had_prior, prev)

            try:
                settings.set(carb_key, value)
                applied += 1
            except Exception:
                LOGGER.exception(
                    "Failed to apply live preset setting %s = %r", carb_key, value
                )

        LOGGER.info(
            "Live render preset: applied %d/%d carb.settings entries.",
            applied,
            len(settings_dict),
        )
        return restore_token

    def restore_settings(self, restore_token: Optional[Dict[str, Tuple[bool, Any]]]) -> int:
        """
        Restore carb.settings entries captured by apply_preset_to_carb_settings.
        Returns the number of entries restored.
        """
        if not restore_token:
            return 0

        settings = carb.settings.get_settings()
        restored = 0
        destroyed = 0

        for carb_key, (had_prior, prev) in restore_token.items():
            try:
                if had_prior:
                    settings.set(carb_key, prev)
                    restored += 1
                else:
                    # Key was unset before we touched it — try to remove our addition.
                    destroy_fn = getattr(settings, "destroy_item", None)
                    if callable(destroy_fn):
                        try:
                            destroy_fn(carb_key)
                            destroyed += 1
                            continue
                        except Exception:
                            LOGGER.debug(
                                "carb.settings.destroy_item failed for %s; leaving value in place.",
                                carb_key,
                                exc_info=True,
                            )
                    # Don't write None back — that can corrupt the setting type.
                    LOGGER.debug(
                        "Leaving carb setting %s in place (no prior value and "
                        "destroy_item unavailable).",
                        carb_key,
                    )
            except Exception:
                LOGGER.exception("Failed to restore carb setting %s", carb_key)

        LOGGER.info(
            "Render preset: restored %d carb.settings entries (destroyed %d, total %d).",
            restored,
            destroyed,
            len(restore_token),
        )
        return restored + destroyed

    # ------------------------------------------------------------------
    # Legacy: USD session sublayer (kept as fallback; no longer primary)
    # ------------------------------------------------------------------
    def apply_preset_to_session(self, preset_path: str) -> RenderPresetValidationResult:
        """
        Legacy path that attaches the preset layer as a session sublayer.
        The Movie Capture backend does NOT read renderSettings from session
        sublayers, so this is retained only for non-capture use cases.
        """
        result = self.validate_file(preset_path)
        if not result.is_valid:
            return result

        stage = omni.usd.get_context().get_stage()
        if stage is None:
            result.errors.append("No active USD stage.")
            result.is_valid = False
            return result

        session_layer = stage.GetSessionLayer()
        if not result.layer_identifier:
            result.errors.append("Preset layer has no identifier.")
            result.is_valid = False
            return result

        if result.layer_identifier not in session_layer.subLayerPaths:
            session_layer.subLayerPaths.append(result.layer_identifier)
            LOGGER.info("Applied render preset layer to session: %s", result.layer_identifier)

        self._active_layer_identifier = result.layer_identifier
        return result

    def remove_from_session(self, layer_identifier: Optional[str] = None) -> bool:
        identifier = layer_identifier or self._active_layer_identifier
        if not identifier:
            return False

        stage = omni.usd.get_context().get_stage()
        if stage is None:
            return False

        session_layer = stage.GetSessionLayer()

        try:
            if identifier in session_layer.subLayerPaths:
                session_layer.subLayerPaths.remove(identifier)
                LOGGER.info("Removed render preset layer from session: %s", identifier)
            self._active_layer_identifier = None
            return True
        except Exception:
            LOGGER.exception("Failed to remove render preset layer from session: %s", identifier)
            return False

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _usd_key_to_carb_path(usd_key: str) -> str:
        # Stock USDSettingsSerialiser uses "rtx/pathtracing/spp" (no leading
        # slash). carb.settings accepts both; normalise to a leading slash so
        # logs and lookups match the canonical form.
        key = str(usd_key).replace(":", "/")
        if not key.startswith("/"):
            key = "/" + key
        return key

    @staticmethod
    def _carb_path_to_usd_key(carb_path: str) -> str:
        key = str(carb_path or "")
        if key.startswith("/"):
            key = key[1:]
        return key.replace("/", ":")

    @staticmethod
    def _matches_schema_type(value: Any, expected_type: str) -> bool:
        normalized = str(expected_type or "").strip().lower()

        if normalized == "bool":
            return isinstance(value, bool)

        if normalized == "int":
            return isinstance(value, int) and not isinstance(value, bool)

        if normalized in {"float", "double"}:
            return isinstance(value, (int, float)) and not isinstance(value, bool)

        if normalized == "string":
            return isinstance(value, str)

        return True

    @staticmethod
    def _infer_renderer_mode(keys) -> str:
        has_path_tracing = False
        has_realtime = False

        for key in keys:
            key = str(key)
            if key.startswith(PATH_TRACING_PREFIX):
                has_path_tracing = True
            elif key.startswith(REALTIME_PREFIX):
                has_realtime = True

        if has_path_tracing and has_realtime:
            return "Mixed"
        if has_path_tracing:
            return "RTX Interactive"
        if has_realtime:
            return "RTX Real-Time"
        return "Shared/Common"
