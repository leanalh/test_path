from dataclasses import dataclass, field
from typing import List, Optional, Tuple


# -----------------------------------------------------------------------------
# Wheel Settings (leader vehicle only)
# -----------------------------------------------------------------------------
@dataclass
class WheelSettings:
    front_left_path: Optional[str] = None
    front_right_path: Optional[str] = None
    rear_left_path: Optional[str] = None
    rear_right_path: Optional[str] = None

    wheel_diameter: float = 1.0
    spin_axis: str = "Y"
    invert_spin: bool = True
    front_steer_factor: float = 10
    rear_steer_factor: float = 10

    def all_paths(self) -> List[str]:
        return [
            p
            for p in (
                self.front_left_path,
                self.front_right_path,
                self.rear_left_path,
                self.rear_right_path,
            )
            if p
        ]

    def summary(self) -> str:
        paths = self.all_paths()
        return ", ".join(paths) if paths else "-"

    def clear(self):
        self.front_left_path = None
        self.front_right_path = None
        self.rear_left_path = None
        self.rear_right_path = None

    def has_all_wheels(self) -> bool:
        return len(self.all_paths()) == 4

@dataclass
class WheelRuntimeState:
    current_wheel_angle: float = 0.0
    accumulated_distance: float = 0.0
    previous_vehicle_world_pos: Optional[Tuple[float, float, float]] = None
    current_front_steer_angle: float = 0.0

    def reset(self):
        self.current_wheel_angle = 0.0
        self.accumulated_distance = 0.0
        self.previous_vehicle_world_pos = None
        self.current_front_steer_angle = 0.0
# -----------------------------------------------------------------------------
# Runtime State (leader vehicle only)
# -----------------------------------------------------------------------------
@dataclass
class RuntimeState:
    status_text: str = "Ready"
    last_error: str = ""

    scenario_running: bool = False
    wheel_sync_enabled: bool = False
    




    current_u_value: float = 0.0
    current_wheel_angle: float = 0.0
    accumulated_distance: float = 0.0
    previous_vehicle_world_pos: Optional[Tuple[float, float, float]] = None
    current_front_steer_angle: float = 0.0

    # Live speedometer (manual scenario mode). Signed: negative when reversing.
    current_velocity_kmh: float = 0.0
    is_reverse: bool = False

    # Movie capture runtime
    movie_capture_progress_fraction: float = 0.0
    movie_capture_progress_text: str = ""
    movie_capture_current_frame: int = 0
    movie_capture_total_frames: int = 0

    def reset(self):
        self.status_text = "Ready"
        self.last_error = ""
        self.scenario_running = False
        self.wheel_sync_enabled = False
        self.current_u_value = 0.0
        self.current_wheel_angle = 0.0
        self.accumulated_distance = 0.0
        self.previous_vehicle_world_pos = None
        self.current_front_steer_angle = 0.0
        self.current_velocity_kmh = 0.0
        self.is_reverse = False


# -----------------------------------------------------------------------------
# Per‑vehicle Motion State (for convoy support)
# -----------------------------------------------------------------------------
@dataclass
class VehicleMotionState:
    name: str
    rig_path: Optional[str] = None

    # Motion Path graph bookkeeping
    graph_path: Optional[str] = None
    read_prims_node_path: Optional[str] = None
    motion_path_node_path: Optional[str] = None
    set_xform_node_path: Optional[str] = None
    u_attr_path: Optional[str] = None

    # Convoy behavior
    offset_u: float = 0.0
    offset_distance_m: float = 0.0  
    enabled: bool = True

    # Per-vehicle wheel capture + runtime
    wheel: WheelSettings = field(default_factory=WheelSettings)
    wheel_runtime: WheelRuntimeState = field(default_factory=WheelRuntimeState)

    def clear_motion_graph(self):
        self.graph_path = None
        self.read_prims_node_path = None
        self.motion_path_node_path = None
        self.set_xform_node_path = None
        self.u_attr_path = None


    def clear(self):
            self.rig_path = None
            self.clear_motion_graph()
            self.offset_u = 0.0
            self.offset_distance_m = 0.0
            self.enabled = True
            self.wheel.clear()
            self.wheel_runtime.reset


# -----------------------------------------------------------------------------
# Application Model
# -----------------------------------------------------------------------------
@dataclass
class AppModel:
    # Shared path
    curve_path: Optional[str] = None


    


    # Vehicles (leader + optional convoy)
    vehicles: List[VehicleMotionState] = field(default_factory=list)

    # Timeline / playback
    # NOTE: start_frame and end_frame are deprecated direct inputs; they remain
    # so legacy scenes that wrote them still load. Live timing is derived from
    # target_speed_kmh + curve length via ScenarioController.recompute_duration().
    start_frame: int = 0
    end_frame: int = 100

    # Derived: written by ScenarioController whenever speed or curve changes.
    # Not user-editable in the UI.
    duration_seconds: float = 10.0

    # Primary timing input. Duration is computed from path length / this speed.
    target_speed_kmh: float = 50.0

    # Scenario mode:
    #   "auto"   — constant speed = target_speed_kmh, duration derived
    #   "manual" — gamepad drive: target_speed_kmh becomes max forward speed
    scenario_mode: str = "auto"

    show_hud: bool = True

    # Vehicle orientation / lift
    vehicle_forward_axis: Optional[str] = None
    vehicle_up_axis: Optional[str] = None
    vehicle_forward_sign: int = 1
    vehicle_aim_rotation_xyz: Tuple[float, float, float] = (0.0, 0.0, 90.0)
    vehicle_path_height_offset: Optional[float] = None
    vehicle_ground_clearance_extra: float = 0.0
    vehicle_ground_ref_path: Optional[str] = None
    vehicle_ground_ref_name: str = "ground_ref"

    
    default_gap_u: float = 0.05
    
    default_gap_distance_m: float = 10.0          
    gap_display_unit: str = "m"

    wrap_offsets_on_closed_path: bool = False

    # Leader‑vehicle subsystems
    
    
    runtime: RuntimeState = field(default_factory=RuntimeState)

    
    # Cameras (leader vehicle)
    driver_camera_path: Optional[str] = None
    driver_camera_offset_xyz: Tuple[float, float, float] = (1337.0, -355.0, 1027.3)
    driver_camera_rotation_xyz: Tuple[float, float, float] = (90.0, 0.0, 90.0)

    # Follow camera
    spectator_camera_path: Optional[str] = None
    spectator_camera_offset_xyz: Tuple[float, float, float] = (-6000.0, 4200.0, 800.0)
    spectator_camera_rotation_xyz: Tuple[float, float, float] = (0.0, 0.0, 90)

    # Above follow camera
    spectator_above_camera_path: Optional[str] = None
    spectator_above_camera_offset_xyz: Tuple[float, float, float] = (1400.0, 0.0, 12700.0)
    spectator_above_camera_rotation_xyz: Tuple[float, float, float] = (180, 0.0, -90)

    # Internal target points on the vehicle
    spectator_camera_target_offset_xyz: Tuple[float, float, float] = (1500.0, 0.0, 700.0)
    spectator_above_camera_target_offset_xyz: Tuple[float, float, float] = (1500.0, 0.0, 700.0)

    driver_camera_horizontal_aperture: float = 110.0
    driver_camera_horizontal_aperture_offset: float = 15.0
    driver_camera_vertical_aperture: float = 24.0
    driver_camera_vertical_aperture_offset: float = 0.0


    # -------------------------------------------------------------------------
    # Movie capture settings
    # -------------------------------------------------------------------------
    movie_capture_output_dir: str = ""
    movie_capture_file_name: str = "tracking_motion_path"
    movie_capture_format: str = ".mp4"

    movie_capture_width: int = 1280
    movie_capture_height: int = 720
    movie_capture_fps: int = 24
    movie_capture_quality_index: int = 0

    # seconds-only range
    # In "auto" mode these mirror the derived scenario duration; in "custom"
    # mode the user controls them directly.
    movie_capture_range_mode: str = "auto"  # "auto" | "custom"
    movie_capture_start_seconds: float = 0.0
    movie_capture_end_seconds: float = 10.0


    # keep these simple
    movie_capture_samples_per_pixel: int = 1
    movie_capture_subframes: int = 1
    movie_capture_rt_wait_for_resolve_seconds: int = 0

    # runtime flags
    movie_capture_is_recording: bool = False
    movie_capture_is_paused: bool = False

    # easiest way to get the original progress dialog
    movie_capture_show_default_progress_window: bool = True
    


    

    



    # ------------------------------------------------------------------
    # Vehicle helpers
    # ------------------------------------------------------------------

    def ensure_vehicle_count(self, count: int):
        while len(self.vehicles) < count:
            index = len(self.vehicles)
            self.vehicles.append(
                VehicleMotionState(
                    name=f"Vehicle {index + 1}",
                    offset_u=0.0,
                    offset_distance_m=0.0
                )
            )

    def add_vehicle(self, name: Optional[str] = None) -> VehicleMotionState:
        index = len(self.vehicles)
        vehicle = VehicleMotionState(
            name=name or f"Vehicle {index + 1}",
            offset_u=0.0,
            offset_distance_m=0.0,
        )
        self.vehicles.append(vehicle)
        return vehicle

    def remove_vehicle(self, index: int):
        if 0 <= index < len(self.vehicles):
            del self.vehicles[index]

    def get_vehicle(self, index: int) -> VehicleMotionState:
        self.ensure_vehicle_count(index + 1)
        return self.vehicles[index]

    def has_any_vehicle(self) -> bool:
        return any(v.rig_path for v in self.vehicles)

    # ------------------------------------------------------------------
    # Legacy single‑vehicle compatibility (leader = vehicles[0])
    # ------------------------------------------------------------------
    @property
    def vehicle_rig_path(self) -> Optional[str]:
        return self.vehicles[0].rig_path if self.vehicles else None

    @vehicle_rig_path.setter
    def vehicle_rig_path(self, value: Optional[str]):
        self.ensure_vehicle_count(1)
        self.vehicles[0].rig_path = value

    @property
    def graph_path(self) -> Optional[str]:
        return self.vehicles[0].graph_path if self.vehicles else None

    @graph_path.setter
    def graph_path(self, value: Optional[str]):
        self.ensure_vehicle_count(1)
        self.vehicles[0].graph_path = value

    @property
    def motion_path_node_path(self) -> Optional[str]:
        return self.vehicles[0].motion_path_node_path if self.vehicles else None

    @motion_path_node_path.setter
    def motion_path_node_path(self, value: Optional[str]):
        self.ensure_vehicle_count(1)
        self.vehicles[0].motion_path_node_path = value

    @property
    def u_attr_path(self) -> Optional[str]:
        return self.vehicles[0].u_attr_path if self.vehicles else None

    @u_attr_path.setter
    def u_attr_path(self, value: Optional[str]):
        self.ensure_vehicle_count(1)
        self.vehicles[0].u_attr_path = value


    @property
    def wheel(self) -> WheelSettings:
        """
        Backward-compatible leader-wheel alias.
        """
        self.ensure_vehicle_count(1)
        return self.vehicles[0].wheel

    # ------------------------------------------------------------------
    # Reset helpers
    # ------------------------------------------------------------------
    def reset_runtime(self):
        self.runtime.reset()

    def reset_all(self):
        self.curve_path = None
        self.vehicles = []
        self.start_frame = 0
        self.end_frame = 100
        self.duration_seconds = 10.0
        self.target_speed_kmh = 50.0
        self.scenario_mode = "auto"
        self.movie_capture_range_mode = "auto"
        self.vehicle_forward_axis = None
        self.vehicle_up_axis = None
        self.vehicle_forward_sign = 1
        self.vehicle_aim_rotation_xyz = (0.0, 0.0, 90.0)
        self.vehicle_path_height_offset = None
        self.vehicle_ground_clearance_extra = 0.0
        self.default_gap_u = 0.05
        self.wrap_offsets_on_closed_path = False
        self.runtime = RuntimeState()
        
        self.driver_camera_path = None
        self.driver_camera_offset_xyz = (1337, -355.0, 1027.3)
        self.driver_camera_rotation_xyz = (90.0, 0.0, 90.0)

        self.spectator_camera_path = None
        self.spectator_camera_offset_xyz = (-6000.0, 4200.0, 800.0)
        self.spectator_camera_rotation_xyz = (0.0, 0.0, 90)

        self.spectator_above_camera_path = None
        self.spectator_above_camera_offset_xyz = (1400.0, 0.0, 12700.0)
        self.spectator_above_camera_rotation_xyz = (180, 0.0, -90)

        self.spectator_camera_target_offset_xyz = (1500.0, 0.0, 700.0)
        self.spectator_above_camera_target_offset_xyz = (1500.0, 0.0, 700.0)