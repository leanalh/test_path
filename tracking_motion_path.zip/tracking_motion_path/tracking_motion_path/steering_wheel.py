import logging

import omni.kit.app
import omni.timeline
import omni.usd
from pxr import UsdGeom

LOGGER = logging.getLogger("tracking_motion_path.steering_wheel")


class SteeringWheelController:
    """
    Visual-only steering wheel controller.

    Workflow:
    - capture exactly ONE steering wheel CONTROL prim (not the imported wheel mesh prim)
    - read current_front_steer_angle from runtime
    - apply steering wheel rotation to that clean control prim
    - use ONE single-axis custom rotate op
    - do NOT mutate transforms during capture
    """

    _STEERING_WHEEL_OP_SUFFIX = "trackingMotionPathSteeringWheel"
    _DEFAULT_STEERING_RATIO = 3.0         
    _DEFAULT_MAX_STEERING_WHEEL_ANGLE = 90
    RETURN_SPEED_MULT = 1.8
    DEADZONE_DEG = 0.4
    CENTER_SOFT_RANGE = 60.0  # degrees 
    CENTER_SOFT_GAIN = 0.6    # 0..1       # ~1.25 turns

    def __init__(self, model):
        self._model = model
        self._app = omni.kit.app.get_app()
        self._timeline = omni.timeline.get_timeline_interface()
        self._update_subscription = None

        # -----------------------------
        # Steering wheel dynamic state
        # -----------------------------
        self._current_wheel_angle_deg = 0.0
        self._wheel_velocity = 0.0

        # -----------------------------
        # Tuning constants (can move to model later)
        # -----------------------------
        self._omega = 8.0   # stiffness
        self._zeta = 1.0    # critical damping

        # -----------------------------
        # Lazy model attributes
        # -----------------------------
        if not hasattr(self._model, "steering_wheel_path"):
            self._model.steering_wheel_path = None

        if not hasattr(self._model, "steering_wheel_invert"):
            self._model.steering_wheel_invert = False

        if not hasattr(self._model, "steering_ratio"):
            self._model.steering_ratio = self._DEFAULT_STEERING_RATIO

        if not hasattr(self._model, "max_steering_wheel_angle"):
            self._model.max_steering_wheel_angle = self._DEFAULT_MAX_STEERING_WHEEL_ANGLE

        if not hasattr(self._model, "steering_wheel_axis"):
            self._model.steering_wheel_axis = "x"

        # -----------------------------
        # Runtime state
        # -----------------------------
        runtime = getattr(self._model, "runtime", None)
        if runtime is not None:
            if not hasattr(runtime, "steering_wheel_sync_enabled"):
                runtime.steering_wheel_sync_enabled = False
            if not hasattr(runtime, "current_front_steer_angle"):
                runtime.current_front_steer_angle = 0.0
            if not hasattr(runtime, "current_steering_wheel_angle"):
                runtime.current_steering_wheel_angle = 0.0
    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def assign_steering_wheel_from_selection(self):
        """
        Capture exactly one selected prim as the steering wheel CONTROL prim.

        IMPORTANT:
        - This should be a clean parent Xform (e.g. SteeringWheel_CTRL),
          not the imported steering wheel mesh/group.
        - Do NOT author any rotation here; capture must be non-destructive.
        """
        selected = list(
            omni.usd.get_context().get_selection().get_selected_prim_paths()
        )
        if len(selected) != 1:
            raise RuntimeError("Select exactly 1 steering wheel CONTROL prim")

        self._model.steering_wheel_path = str(selected[0])
        self._model.runtime.status_text = "Steering wheel control prim captured."

    def get_steering_wheel_summary(self) -> str:
        return str(getattr(self._model, "steering_wheel_path", None) or "-")

    def prepare_for_scenario(self, start_frame: int = 0, end_frame: int = 100):
        self._model.runtime.current_steering_wheel_angle = 0.0
        self._reset_internal_state(apply_usd=True)
        self._apply_angle_to_steering_wheel(0.0)

    def start(self):
        if self._update_subscription is None:
            self._update_subscription = (
                self._app.get_update_event_stream().create_subscription_to_pop(
                    self._on_update,
                    name="tracking_motion_path.steering_wheel",
                )
            )
        self._model.runtime.steering_wheel_sync_enabled = True

    def stop(self):
        self._reset_internal_state(apply_usd=True)
        self._model.runtime.steering_wheel_sync_enabled = False

    def reset(self):
        self._reset_internal_state(apply_usd=True)
        self._apply_angle_to_steering_wheel(0.0)
        self._model.runtime.current_steering_wheel_angle = 0.0

    def shutdown(self):
        self.stop()
        self._update_subscription = None

    # ------------------------------------------------------------------
    # Update loop
    # ------------------------------------------------------------------
    def _on_update(self, event):
        if not self._timeline.is_playing():
            return

        runtime = self._model.runtime
        if not getattr(runtime, "steering_wheel_sync_enabled", False):
            return

        front_steer = float(getattr(runtime, "current_front_steer_angle", 0.0) or 0.0)

        # Clamp incoming front steer to expected range
        max_front_steer = float(getattr(self._model, "max_front_steer_deg", 10.0))
        front_steer = max(-max_front_steer, min(max_front_steer, front_steer))

        # Steering ratio
        target_angle = front_steer * float(self._model.steering_ratio)

        # Clamp target steering wheel angle
        max_angle = float(self._model.max_steering_wheel_angle)
        target_angle = max(-max_angle, min(max_angle, target_angle))

        # Center softening
        if abs(target_angle) < self.CENTER_SOFT_RANGE:
            target_angle *= self.CENTER_SOFT_GAIN

        dt = float(event.payload.get("dt", 0.0))
        if dt <= 0.0:
            return

        # -------------------------------------------------
        # Stable spring integration for Movie Capture
        # -------------------------------------------------
        fixed_dt = 1.0 / 120.0
        max_dt = 0.25
        dt = min(dt, max_dt)

        steps = max(1, int(dt / fixed_dt))
        step_dt = dt / steps

        for _ in range(steps):
            error = target_angle - self._current_wheel_angle_deg

            self._wheel_velocity += (
                (self._omega ** 2) * error
                - 2.0 * self._zeta * self._omega * self._wheel_velocity
            ) * step_dt

            # Prevent runaway velocities
            max_velocity = 720.0
            self._wheel_velocity = max(
                -max_velocity,
                min(max_velocity, self._wheel_velocity),
            )

            self._current_wheel_angle_deg += self._wheel_velocity * step_dt

            self._current_wheel_angle_deg = max(
                -max_angle,
                min(max_angle, self._current_wheel_angle_deg),
            )

        angle = self._current_wheel_angle_deg
        if bool(getattr(self._model, "steering_wheel_invert", False)):
            angle *= -1.0

        self._apply_angle_to_steering_wheel(angle)
        runtime.current_steering_wheel_angle = float(angle)

        

    # ------------------------------------------------------------------
    # USD transform application
    # ------------------------------------------------------------------
    def _apply_angle_to_steering_wheel(self, angle_deg: float):
        stage = omni.usd.get_context().get_stage()
        if not stage:
            return

        steering_wheel_path = getattr(self._model, "steering_wheel_path", None)
        if not steering_wheel_path:
            return

        prim = stage.GetPrimAtPath(str(steering_wheel_path))
        if not prim or not prim.IsValid():
            LOGGER.warning(
                "Steering wheel control prim is invalid or missing: %s",
                steering_wheel_path,
            )
            return

        xformable = UsdGeom.Xformable(prim)
        if not xformable:
            LOGGER.warning(
                "Steering wheel control prim is not xformable: %s",
                steering_wheel_path,
            )
            return

        op = self._get_or_create_steering_op(xformable)
        if not op:
            LOGGER.warning(
                "Failed to create steering wheel xform op on: %s",
                steering_wheel_path,
            )
            return

        # Single-axis rotation only, on the CONTROL prim.
        op.Set(float(angle_deg))

    def _get_or_create_steering_op(self, xformable: UsdGeom.Xformable):
        axis = str(getattr(self._model, "steering_wheel_axis", "x")).lower()

        if axis == "x":
            desired_name = f"xformOp:rotateX:{self._STEERING_WHEEL_OP_SUFFIX}"
        elif axis == "z":
            desired_name = f"xformOp:rotateZ:{self._STEERING_WHEEL_OP_SUFFIX}"
        else:
            raise RuntimeError(
                f"Unsupported steering_wheel_axis='{axis}'. Use 'x' or 'z'."
            )

        for op in xformable.GetOrderedXformOps():
            try:
                if op.GetOpName() == desired_name:
                    return op
            except Exception:
                pass

        if axis == "x":
            op = xformable.AddRotateXOp(
                precision=UsdGeom.XformOp.PrecisionDouble,
                opSuffix=self._STEERING_WHEEL_OP_SUFFIX,
            )
        else:
            op = xformable.AddRotateZOp(
                precision=UsdGeom.XformOp.PrecisionDouble,
                opSuffix=self._STEERING_WHEEL_OP_SUFFIX,
            )

        self._ensure_steering_op_order(xformable, op)
        return op

    def _ensure_steering_op_order(self, xformable: UsdGeom.Xformable, steering_op):
        """
        Preserve all existing ops exactly as they are and append our managed
        steering op last.

    
        """
        managed_name = steering_op.GetOpName()

        ordered_ops = list(xformable.GetOrderedXformOps())
        other_ops = []
        for op in ordered_ops:
            try:
                if op.GetOpName() != managed_name:
                    other_ops.append(op)
            except Exception:
                continue

        xformable.SetXformOpOrder(other_ops + [steering_op])

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------
    def clear_steering_wheel(self):
        """
        Fully undo steering-wheel changes:
        - stop live sync
        - remove managed steering wheel op
        - clear captured steering wheel path
        """
        self.stop()

        stage = omni.usd.get_context().get_stage()
        steering_wheel_path = getattr(self._model, "steering_wheel_path", None)

        if stage and steering_wheel_path:
            prim = stage.GetPrimAtPath(str(steering_wheel_path))
            if prim and prim.IsValid():
                self._remove_managed_steering_op(prim)

        self._model.steering_wheel_path = None
        self._model.runtime.current_steering_wheel_angle = 0.0
        self._model.runtime.current_front_steer_angle = 0.0

    def _remove_managed_steering_op(self, prim):
        xformable = UsdGeom.Xformable(prim)
        if not xformable:
            return

        axis = str(getattr(self._model, "steering_wheel_axis", "x")).lower()
        if axis == "x":
            managed_name = f"xformOp:rotateX:{self._STEERING_WHEEL_OP_SUFFIX}"
        else:
            managed_name = f"xformOp:rotateZ:{self._STEERING_WHEEL_OP_SUFFIX}"

        ordered_ops = list(xformable.GetOrderedXformOps())
        keep_ops = []
        for op in ordered_ops:
            try:
                if op.GetOpName() != managed_name:
                    keep_ops.append(op)
            except Exception:
                pass

        try:
            xformable.SetXformOpOrder(keep_ops)
        except Exception:
            LOGGER.debug("Failed resetting steering wheel op order.", exc_info=True)

        try:
            prim.RemoveProperty(managed_name)
        except Exception:
            LOGGER.debug(
                "Failed removing steering wheel property: %s",
                managed_name,
                exc_info=True,
            )



    def _reset_internal_state(self, apply_usd: bool = True):
        self._current_wheel_angle_deg = 0.0
        self._wheel_velocity = 0.0

        runtime = self._model.runtime
        runtime.current_steering_wheel_angle = 0.0

        if apply_usd:
            self._apply_angle_to_steering_wheel(0.0)
