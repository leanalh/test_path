import logging
import math
from typing import Optional, Tuple

import omni.kit.app
import omni.usd
from pxr import Gf, Sdf, Usd, UsdGeom

LOGGER = logging.getLogger("tracking_motion_path.driver_camera")


class DriverCameraController:
    CAMERA_BASENAME = "DriverCamera"
    SPECTATOR_CAMERA_NAME = "SpectatorCamera"
    SPECTATOR_ABOVE_CAMERA_NAME = "SpectatorAboveCamera"
    XFORM_OP_SUFFIX = "trackingMotionPathCamera"

    DRIVER_LOOK_SPEED_DEG_PER_SEC = 90.0
    DRIVER_LOOK_DEADZONE = 0.15
    DRIVER_LOOK_SMOOTHING_TIME_SEC = 0.08
    DRIVER_LOOK_MIN_DELTA_DEG = 1e-4


    def __init__(self, model):
        self._model = model
        self._app = omni.kit.app.get_app()
        self._follow_sub = None

        
    # Smooth driver look control
        self._driver_look_sub = None
        self._driver_look_input_raw = 0.0
        self._driver_look_input_smoothed = 0.0
        self._last_driver_camera_status_z = None


    # ------------------------------------------------------------------
    # Driver camera
    # ------------------------------------------------------------------
    def create_or_update_driver_camera(
        self,
        offset_xyz: Optional[Tuple[float, float, float]] = None,
        rotation_xyz: Optional[Tuple[float, float, float]] = None,
        focal_length: float = 35,
        
        horizontal_aperture: float = 110.0,
        horizontal_aperture_offset: float = 15.0,
        vertical_aperture: float = 24.0,
        vertical_aperture_offset: float = 0.0,

    ) -> str:
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        vehicle_path = getattr(self._model, "vehicle_rig_path", None)
        if not vehicle_path:
            raise RuntimeError("Capture the vehicle first.")

        vehicle_prim = stage.GetPrimAtPath(vehicle_path)
        if not vehicle_prim or not vehicle_prim.IsValid():
            raise RuntimeError(f"Invalid vehicle prim: {vehicle_path}")

        if not UsdGeom.Xformable(vehicle_prim):
            raise RuntimeError(f"Vehicle prim is not xformable: {vehicle_path}")

        offset_xyz = tuple(
            offset_xyz
            or getattr(self._model, "driver_camera_offset_xyz", (1337.0, -355.0, 1017.3))
        )
        rotation_xyz = tuple(
            rotation_xyz
            or getattr(self._model, "driver_camera_rotation_xyz", (90.0, 0.0, 90.0))
        )

        horizontal_aperture = float(
            horizontal_aperture
            if horizontal_aperture is not None
            else getattr(self._model, "driver_camera_horizontal_aperture", 110.0)
        )
        horizontal_aperture_offset = float(
            horizontal_aperture_offset
            if horizontal_aperture_offset is not None
            else getattr(self._model, "driver_camera_horizontal_aperture_offset", 15.0)
        )
        vertical_aperture = float(
            vertical_aperture
            if vertical_aperture is not None
            else getattr(self._model, "driver_camera_vertical_aperture", 24.0)
        )
        vertical_aperture_offset = float(
            vertical_aperture_offset
            if vertical_aperture_offset is not None
            else getattr(self._model, "driver_camera_vertical_aperture_offset", 0.0)
        )

        camera_path = Sdf.Path(f"{vehicle_prim.GetPath()}/{self.CAMERA_BASENAME}")
        camera = UsdGeom.Camera.Define(stage, camera_path)
        xformable = UsdGeom.Xformable(camera.GetPrim())

        self._set_translate(xformable, offset_xyz)
        self._set_rotate_xyz(xformable, rotation_xyz)

        

        camera.GetFocalLengthAttr().Set(float(focal_length))
        camera.GetClippingRangeAttr().Set(Gf.Vec2f(0.01, 1000000.0))

        camera.GetHorizontalApertureAttr().Set(float(horizontal_aperture))
        camera.GetHorizontalApertureOffsetAttr().Set(float(horizontal_aperture_offset))
        camera.GetVerticalApertureAttr().Set(float(vertical_aperture))
        camera.GetVerticalApertureOffsetAttr().Set(float(vertical_aperture_offset))


        self._model.driver_camera_horizontal_aperture = float(horizontal_aperture)
        self._model.driver_camera_horizontal_aperture_offset = float(horizontal_aperture_offset)
        self._model.driver_camera_vertical_aperture = float(vertical_aperture)
        self._model.driver_camera_vertical_aperture_offset = float(vertical_aperture_offset)


        self._model.driver_camera_path = str(camera_path)

        self._model.driver_camera_rotation_xyz = tuple(float(v) for v in rotation_xyz)

        self._model.runtime.status_text = f"Driver camera ready: {camera_path}"
        return str(camera_path)
    


    def activate_driver_camera(self):
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        camera_path = getattr(self._model, "driver_camera_path", None)
        if not self._is_valid_camera_prim(camera_path):
            raise RuntimeError("Driver camera does not exist or is no longer valid.")

        self._activate_viewport_camera(camera_path)
        self._model.runtime.status_text = f"Driver camera activated: {camera_path}"


    def start_driver_look_updates(self):
        if self._driver_look_sub is None:
            self._driver_look_sub = (
                self._app.get_update_event_stream().create_subscription_to_pop(
                    self._on_driver_look_update,
                    name="tracking_motion_path.driver_camera_look",
                )
            )

    def stop_driver_look_updates(self):
        self._driver_look_sub = None
        self._driver_look_input_raw = 0.0
        self._driver_look_input_smoothed = 0.0

    def set_driver_camera_z_input(self, raw_input: float):
        """
        Store normalized horizontal look input in [-1, 1].
        Positive -> rotate left (increase Z)
        Negative -> rotate right (decrease Z)
        """
        self._driver_look_input_raw = max(-1.0, min(1.0, float(raw_input)))

    def _extract_dt_seconds(self, event) -> float:
        payload = getattr(event, "payload", None)
        if isinstance(payload, dict):
            for key in ("dt", "delta_time", "elapsed_s"):
                value = payload.get(key)
                if value is not None:
                    try:
                        dt = float(value)
                        if dt > 0.0:
                            return dt
                    except Exception:
                        pass

        for attr in ("dt", "delta_time", "elapsed_s"):
            try:
                value = getattr(event, attr, None)
                if value is not None:
                    dt = float(value)
                    if dt > 0.0:
                        return dt
            except Exception:
                pass

        # Safe fallback
        return 1.0 / 60.0

    def _apply_deadzone_and_remap(self, value: float) -> float:
        value = max(-1.0, min(1.0, float(value)))
        deadzone = float(self.DRIVER_LOOK_DEADZONE)

        if abs(value) <= deadzone:
            return 0.0

        magnitude = (abs(value) - deadzone) / (1.0 - deadzone)
        return math.copysign(magnitude, value)

    def _on_driver_look_update(self, event):
        try:
            camera_path = getattr(self._model, "driver_camera_path", None)
            if not self._is_valid_camera_prim(camera_path):
                self._driver_look_input_smoothed = 0.0
                return

            dt = self._extract_dt_seconds(event)

            raw = self._apply_deadzone_and_remap(self._driver_look_input_raw)

            smoothing_time = max(float(self.DRIVER_LOOK_SMOOTHING_TIME_SEC), 1e-6)
            alpha = 1.0 - math.exp(-dt / smoothing_time)
            self._driver_look_input_smoothed += (
                raw - self._driver_look_input_smoothed
            ) * alpha

            # Snap very small residual movement to zero
            if abs(self._driver_look_input_smoothed) < 1e-4 and raw == 0.0:
                self._driver_look_input_smoothed = 0.0
                return

            delta_deg = (
                self._driver_look_input_smoothed
                * float(self.DRIVER_LOOK_SPEED_DEG_PER_SEC)
                * dt
            )

            if abs(delta_deg) < float(self.DRIVER_LOOK_MIN_DELTA_DEG):
                return

            self.adjust_driver_camera_z(delta_deg, update_status=False)

        except Exception as exc:
            LOGGER.exception("Driver camera look update failed: %s", exc)
            self._model.runtime.last_error = str(exc)


    # ------------------------------------------------------------------
    # Follow target spectator camera
    # ------------------------------------------------------------------
    def create_or_update_spectator_camera(self, focal_length: float = 18) -> str:
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        vehicle_path = getattr(self._model, "vehicle_rig_path", None)
        if not vehicle_path:
            raise RuntimeError("Capture the vehicle first.")

        camera_path = Sdf.Path(f"/World/{self.SPECTATOR_CAMERA_NAME}")
        camera = UsdGeom.Camera.Define(stage, camera_path)
        camera.GetFocalLengthAttr().Set(float(focal_length))
        camera.GetClippingRangeAttr().Set(Gf.Vec2f(0.01, 1000000.0))

        self._model.spectator_camera_path = str(camera_path)

        self._start_follow_updates()
        self._update_follow_camera_now(
            camera_path=str(camera_path),
            follow_offset_xyz=getattr(
                self._model,
                "spectator_camera_offset_xyz",
                (-6000.0, 2000.0, 1800.0),
            ),
            target_offset_xyz=getattr(
                self._model,
                "spectator_camera_target_offset_xyz",
                (1500.0, 0.0, 700.0),
            ),
            rotation_offset_xyz=getattr(
                self._model,
                "spectator_camera_rotation_xyz",
                (0.0, 0.0, 0.0),
            ),
        )

        self._model.runtime.status_text = f"Spectator camera ready: {camera_path}"
        return str(camera_path)

    def activate_spectator_camera(self):
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        camera_path = getattr(self._model, "spectator_camera_path", None)
        if not self._is_valid_camera_prim(camera_path):
            camera_path = self.create_or_update_spectator_camera()

        self._activate_viewport_camera(camera_path)
        self._model.runtime.status_text = f"Spectator camera activated: {camera_path}"

    # ------------------------------------------------------------------
    # Above follow camera
    # ------------------------------------------------------------------
    def create_or_update_spectator_above_camera(self, focal_length: float = 18) -> str:
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        vehicle_path = getattr(self._model, "vehicle_rig_path", None)
        if not vehicle_path:
            raise RuntimeError("Capture the vehicle first.")

        camera_path = Sdf.Path(f"/World/{self.SPECTATOR_ABOVE_CAMERA_NAME}")
        camera = UsdGeom.Camera.Define(stage, camera_path)
        camera.GetFocalLengthAttr().Set(float(focal_length))
        camera.GetClippingRangeAttr().Set(Gf.Vec2f(0.01, 1000000.0))

        self._model.spectator_above_camera_path = str(camera_path)

        self._start_follow_updates()
        self._update_follow_camera_now(
            camera_path=str(camera_path),
            follow_offset_xyz=getattr(
                self._model,
                "spectator_above_camera_offset_xyz",
                (1400.0, 0.0, 12700.0),
            ),
            target_offset_xyz=getattr(
                self._model,
                "spectator_above_camera_target_offset_xyz",
                (1500.0, 0.0, 700.0),
            ),
            rotation_offset_xyz=getattr(
                self._model,
                "spectator_above_camera_rotation_xyz",
                (180, 0.0, -90),
            ),
        )

        self._model.runtime.status_text = f"Spectator Above camera ready: {camera_path}"
        return str(camera_path)

    def activate_spectator_above_camera(self):
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        camera_path = getattr(self._model, "spectator_above_camera_path", None)
        if not self._is_valid_camera_prim(camera_path):
            camera_path = self.create_or_update_spectator_above_camera()

        self._activate_viewport_camera(camera_path)
        self._model.runtime.status_text = f"Spectator Above camera activated: {camera_path}"

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------
    def cleanup(self) -> int:
        self._stop_follow_updates()
        self.stop_driver_look_updates()
        return self.reset_cameras()

    def reset_cameras(self) -> int:
        self._stop_follow_updates()
        self.stop_driver_look_updates()

        stage = omni.usd.get_context().get_stage()
        if not stage:
            self._model.driver_camera_path = None
            self._model.spectator_camera_path = None
            self._model.spectator_above_camera_path = None
            return 0

        paths_to_remove = set()

        driver_camera_path = getattr(self._model, "driver_camera_path", None)
        if driver_camera_path:
            paths_to_remove.add(str(driver_camera_path))

        spectator_camera_path = getattr(self._model, "spectator_camera_path", None)
        if spectator_camera_path:
            paths_to_remove.add(str(spectator_camera_path))

        spectator_above_camera_path = getattr(self._model, "spectator_above_camera_path", None)
        if spectator_above_camera_path:
            paths_to_remove.add(str(spectator_above_camera_path))

        for prim in Usd.PrimRange(stage.GetPseudoRoot()):
            if not prim or not prim.IsValid():
                continue
            name = prim.GetName()
            if name == "DriverCameraRig" or name.startswith("DriverCameraRig_"):
                paths_to_remove.add(str(prim.GetPath()))
            if name == "SpectatorCameraRig":
                paths_to_remove.add(str(prim.GetPath()))

        removed_count = 0
        for path in sorted(paths_to_remove, key=len, reverse=True):
            prim = stage.GetPrimAtPath(path)
            if prim and prim.IsValid():
                try:
                    stage.RemovePrim(path)
                    removed_count += 1
                except Exception:
                    LOGGER.exception("Failed to remove camera prim: %s", path)

        self._model.driver_camera_path = None
        self._model.spectator_camera_path = None
        self._model.spectator_above_camera_path = None
        self._model.runtime.status_text = f"Removed {removed_count} camera prim(s)."
        return removed_count

    # ------------------------------------------------------------------
    # Shared follow update loop
    # ------------------------------------------------------------------
    def _start_follow_updates(self):
        if self._follow_sub is None:
            self._follow_sub = (
                self._app.get_update_event_stream().create_subscription_to_pop(
                    self._on_follow_update,
                    name="tracking_motion_path.follow_cameras",
                )
            )

    def _stop_follow_updates(self):
        self._follow_sub = None

    def _on_follow_update(self, _event):
        try:
            spectator_camera_path = getattr(self._model, "spectator_camera_path", None)
            if self._is_valid_camera_prim(spectator_camera_path):
                self._update_follow_camera_now(
                    camera_path=str(spectator_camera_path),
                    follow_offset_xyz=getattr(
                        self._model,
                        "spectator_camera_offset_xyz",
                        (-6000.0, 2000.0, 1800.0),
                    ),
                    target_offset_xyz=getattr(
                        self._model,
                        "spectator_camera_target_offset_xyz",
                        (1500.0, 0.0, 700.0),
                    ),
                    rotation_offset_xyz=getattr(
                        self._model,
                        "spectator_camera_rotation_xyz",
                        (0.0, 0.0, 0.0),
                    ),
                )

            spectator_above_camera_path = getattr(self._model, "spectator_above_camera_path", None)
            if self._is_valid_camera_prim(spectator_above_camera_path):
                self._update_follow_camera_now(
                    camera_path=str(spectator_above_camera_path),
                    follow_offset_xyz=getattr(
                        self._model,
                        "spectator_above_camera_offset_xyz",
                        (0.0, 3500.0, 4500.0),
                    ),
                    target_offset_xyz=getattr(
                        self._model,
                        "spectator_above_camera_target_offset_xyz",
                        (1400.0, 0.0, 12700.0),
                    ),
                    rotation_offset_xyz=getattr(
                        self._model,
                        "spectator_above_camera_rotation_xyz",
                        (-180, 0.0, 90),
                    ),
                )
        except Exception as exc:
            LOGGER.exception("Follow camera update failed: %s", exc)
            self._model.runtime.last_error = str(exc)

    def _update_follow_camera_now(
        self,
        camera_path: str,
        follow_offset_xyz,
        target_offset_xyz,
        rotation_offset_xyz,
    ):
        stage = omni.usd.get_context().get_stage()
        if not stage:
            return

        vehicle_path = getattr(self._model, "vehicle_rig_path", None)
        if not vehicle_path:
            return

        vehicle_prim = stage.GetPrimAtPath(str(vehicle_path))
        camera_prim = stage.GetPrimAtPath(str(camera_path))
        if not vehicle_prim or not vehicle_prim.IsValid():
            return
        if not camera_prim or not camera_prim.IsValid():
            return

        vehicle_world = UsdGeom.XformCache(Usd.TimeCode.Default()).GetLocalToWorldTransform(vehicle_prim)

        camera_world_pos = vehicle_world.Transform(
            Gf.Vec3d(
                float(follow_offset_xyz[0]),
                float(follow_offset_xyz[1]),
                float(follow_offset_xyz[2]),
            )
        )
        target_world_pos = vehicle_world.Transform(
            Gf.Vec3d(
                float(target_offset_xyz[0]),
                float(target_offset_xyz[1]),
                float(target_offset_xyz[2]),
            )
        )

        auto_rotation_xyz = self._compute_follow_rotation_xyz(
            eye_xyz=(
                float(camera_world_pos[0]),
                float(camera_world_pos[1]),
                float(camera_world_pos[2]),
            ),
            target_xyz=(
                float(target_world_pos[0]),
                float(target_world_pos[1]),
                float(target_world_pos[2]),
            ),
        )

        final_rotation_xyz = (
            float(auto_rotation_xyz[0] + rotation_offset_xyz[0]),
            float(auto_rotation_xyz[1] + rotation_offset_xyz[1]),
            float(auto_rotation_xyz[2] + rotation_offset_xyz[2]),
        )

        xformable = UsdGeom.Xformable(camera_prim)
        self._set_translate(
            xformable,
            (
                float(camera_world_pos[0]),
                float(camera_world_pos[1]),
                float(camera_world_pos[2]),
            ),
        )
        self._set_rotate_xyz(xformable, final_rotation_xyz)

    def _compute_follow_rotation_xyz(self, eye_xyz, target_xyz):
        dx = float(target_xyz[0]) - float(eye_xyz[0])
        dy = float(target_xyz[1]) - float(eye_xyz[1])
        dz = float(target_xyz[2]) - float(eye_xyz[2])

        planar = math.sqrt(dx * dx + dy * dy)
        if planar <= 1e-8 and abs(dz) <= 1e-8:
            return (90.0, 0.0, 180.0)

        yaw_deg = math.degrees(math.atan2(dy, dx))
        pitch_deg = -math.degrees(math.atan2(dz, max(planar, 1e-8)))

        # Stable look-at:
        # - X rotation handles pitch
        # - Z rotation handles yaw
        # - Y stays 0
        return (
            float(90.0 + pitch_deg),
            0.0,
            float(180.0 + yaw_deg),
        )

    # ------------------------------------------------------------------
    # USD helpers
    # ------------------------------------------------------------------
    def _activate_viewport_camera(self, camera_path: str):
        try:
            import omni.kit.viewport.utility as viewport_utility

            viewport = viewport_utility.get_active_viewport()
            if viewport is None:
                raise RuntimeError("No active viewport found.")
            viewport.camera_path = str(camera_path)
        except Exception as exc:
            LOGGER.exception("Failed to switch viewport camera: %s", exc)
            raise RuntimeError(f"Failed to switch viewport camera: {exc}") from exc

    def _set_translate(self, xformable: UsdGeom.Xformable, value_xyz):
        op = self._get_or_create_translate_op(xformable)
        op.Set(Gf.Vec3d(*[float(v) for v in value_xyz]))

    def _set_rotate_xyz(self, xformable: UsdGeom.Xformable, value_xyz):
        op = self._get_or_create_rotate_xyz_op(xformable)
        op.Set(Gf.Vec3f(*[float(v) for v in value_xyz]))

    def _get_or_create_translate_op(self, xformable: UsdGeom.Xformable):
        desired_name = f"xformOp:translate:{self.XFORM_OP_SUFFIX}"
        for op in xformable.GetOrderedXformOps():
            try:
                if op.GetOpName() == desired_name:
                    return op
            except Exception:
                pass
        return xformable.AddTranslateOp(
            precision=UsdGeom.XformOp.PrecisionDouble,
            opSuffix=self.XFORM_OP_SUFFIX,
        )

    def _get_or_create_rotate_xyz_op(self, xformable: UsdGeom.Xformable):
        desired_name = f"xformOp:rotateXYZ:{self.XFORM_OP_SUFFIX}"
        for op in xformable.GetOrderedXformOps():
            try:
                if op.GetOpName() == desired_name:
                    return op
            except Exception:
                pass
        return xformable.AddRotateXYZOp(
            precision=UsdGeom.XformOp.PrecisionFloat,
            opSuffix=self.XFORM_OP_SUFFIX,
        )

    def _is_valid_camera_prim(self, camera_path: str) -> bool:
        if not camera_path:
            return False
        stage = omni.usd.get_context().get_stage()
        if not stage:
            return False
        prim = stage.GetPrimAtPath(camera_path)
        return bool(prim and prim.IsValid() and prim.IsA(UsdGeom.Camera))
    

    def set_driver_camera_rotation_xyz(self, rotation_xyz):
        """
        Persist and apply the driver camera rotation immediately.

        This updates:
        - self._model.driver_camera_rotation_xyz
        - the existing driver camera prim if it already exists
        - or creates the driver camera with the requested rotation if missing
        """
        rotation_xyz = tuple(float(v) for v in rotation_xyz)
        self._model.driver_camera_rotation_xyz = rotation_xyz

        stage = omni.usd.get_context().get_stage()
        if not stage:
            return

        camera_path = getattr(self._model, "driver_camera_path", None)

        # If camera does not exist yet, create it with the requested rotation
        if not self._is_valid_camera_prim(camera_path):
            self.create_or_update_driver_camera(rotation_xyz=rotation_xyz)
            return

        camera_prim = stage.GetPrimAtPath(str(camera_path))
        if not camera_prim or not camera_prim.IsValid():
            return

        xformable = UsdGeom.Xformable(camera_prim)
        self._set_rotate_xyz(xformable, rotation_xyz)

    def adjust_driver_camera_z(self, delta_deg: float, update_status: bool = True):
        
        current_rotation = tuple(
            getattr(self._model, "driver_camera_rotation_xyz", (90.0, 0.0, 90.0))
        )
        x = float(current_rotation[0])
        y = float(current_rotation[1])
        z = float(current_rotation[2]) + float(delta_deg)

        self.set_driver_camera_rotation_xyz((x, y, z))

        if update_status:
            if (
                self._last_driver_camera_status_z is None
                or abs(z - self._last_driver_camera_status_z) >= 1.0
            ):
                self._model.runtime.status_text = f"Driver camera Z rotation: {z:.2f}°"
                self._last_driver_camera_status_z = z