from functools import partial
import logging

import omni.ext
import omni.ui as ui
import omni.usd

from .model import AppModel
from .motion_path_adapter import MotionPathAdapter
from .scenario_controller import ScenarioController
from .ui import TrackingMotionPathWindow
from .wheel_sync import WheelSyncController
from .driver_camera import DriverCameraController
from .steering_wheel import SteeringWheelController

from .gamepad_camera_controller import GamepadCameraController
from .gamepad_drive_controller import GamepadDriveController
from .movie_capture_controller import MovieCaptureController
from .vehicle_speed_controller import VehicleSpeedController
from .hud import HudController
from .trajectory_importer import TrajectoryImporter
from .trajectory_playback_controller import TrajectoryPlaybackController






LOGGER = logging.getLogger("tracking_motion_path.extension")


class TrackingMotionPathExtension(omni.ext.IExt):
    """
    Extension entry point.

    Clean version:
    - Keeps model / adapters / controllers lifecycle explicit
    - Matches simplified MotionPathAdapter + ScenarioController
    - Uses closed-path wrap by default
    """

    WINDOW_NAME = "Tracking Motion Path"

    # ------------------------------------------------------------------
    # Extension lifecycle
    # ------------------------------------------------------------------
    def on_startup(self, ext_id):
        self._ext_id = ext_id
        self._window = None

        
        self._hud = None
        self._speed_controller = None


        # ------------------------------------------------------------------
        # Model
        # ------------------------------------------------------------------
        self._model = AppModel()
        self._model.wrap_offsets_on_closed_path = False
        self._model.ensure_vehicle_count(1)


        self._trajectory_importer = TrajectoryImporter()
        self._trajectory_playback_controller = TrajectoryPlaybackController(self._model)
        self._trajectory_playback_controller.startup()



        
        self._hud = HudController(
            ext_id=ext_id,
            prefer_xr=False,
        )
        self._hud.set_speed(0.0)
        self._refresh_hud_visibility()



        # ------------------------------------------------------------------
        # Motion Path adapters (one per vehicle)
        # ------------------------------------------------------------------
        self._motion_path_adapters = [
            MotionPathAdapter(model=self._model, vehicle_index=0)
        ]

        # ------------------------------------------------------------------
        # Controllers
        # ------------------------------------------------------------------
        self._wheel_sync_controllers = [
            WheelSyncController(model=self._model, vehicle_index=0)
        ]

        self._steering_wheel_controller = SteeringWheelController(
            model=self._model
        )

        # Manual-drive speed integrator; consumed by ScenarioController when
        # scenario_mode == "manual".
        self._speed_controller = VehicleSpeedController(
            model=self._model,
            on_speed_changed=self._on_speed_changed,
        )
        self._speed_controller.startup()

        self._scenario_controller = ScenarioController(
            model=self._model,
            motion_path_adapters=self._motion_path_adapters,
            wheel_sync_controllers=self._wheel_sync_controllers,
            steering_wheel_controller=self._steering_wheel_controller,
            speed_controller=self._speed_controller,
        )

        self._driver_camera_controller = DriverCameraController(
            model=self._model
        )


        self._movie_capture_controller = MovieCaptureController(
            model=self._model,
            driver_camera_controller=self._driver_camera_controller,
        )
        self._movie_capture_controller.startup()


        # Clean up any leftover cameras from a previous run
        try:
            self._driver_camera_controller.cleanup()
        except Exception:
            LOGGER.debug("No previous cameras to clean up.", exc_info=True)


        self._gamepad_drive = GamepadDriveController(
            self._model,
            self._speed_controller,
        )

        self._gamepad_camera = GamepadCameraController(
            self._model,
            self._driver_camera_controller,
            self._gamepad_drive,
            
            
        start_callback=self._on_gamepad_start,
        pause_resume_callback=self._on_gamepad_pause_resume,
        stop_reset_callback=self._on_gamepad_stop_reset,
        scenario_mode_toggle_callback=self._on_gamepad_toggle_scenario_mode,


        )

        self._gamepad_drive.startup()   # now only validates / prepares state
        self._gamepad_camera.startup()  # the only real subscription

        
        


        
       

       


        # ------------------------------------------------------------------
        # Window registration
        # ------------------------------------------------------------------
        ui.Workspace.set_show_window_fn(
            self.WINDOW_NAME,
            partial(self._show_window, None),
        )
        ui.Workspace.show_window(self.WINDOW_NAME)

        LOGGER.info("Tracking Motion Path extension started.")

    # ------------------------------------------------------------------
    # Adapter management (used by UI convoy section)
    # ------------------------------------------------------------------
    def ensure_adapters_match_model(self):
        required = len(self._model.vehicles)

        # Grow motion path adapters
        while len(self._motion_path_adapters) < required:
            index = len(self._motion_path_adapters)
            self._motion_path_adapters.append(
                MotionPathAdapter(model=self._model, vehicle_index=index)
            )

        # Shrink motion path adapters
        while len(self._motion_path_adapters) > required:
            adapter = self._motion_path_adapters.pop()
            try:
                adapter.reset_extension_state()
            except Exception:
                LOGGER.debug("Failed to reset removed adapter.", exc_info=True)

        # Grow wheel controllers
        while len(self._wheel_sync_controllers) < required:
            index = len(self._wheel_sync_controllers)
            self._wheel_sync_controllers.append(
                WheelSyncController(model=self._model, vehicle_index=index)
            )

        # Shrink wheel controllers
        while len(self._wheel_sync_controllers) > required:
            ctrl = self._wheel_sync_controllers.pop()
            try:
                ctrl.shutdown()
            except Exception:
                LOGGER.debug("Failed to shutdown removed wheel controller.", exc_info=True)

        # Notify scenario controller
        self._scenario_controller.set_adapters(self._motion_path_adapters)
        self._scenario_controller.set_wheel_sync_controllers(
            self._wheel_sync_controllers
        )

    # ------------------------------------------------------------------
    # Window handling
    # ------------------------------------------------------------------
    def _show_window(self, _menu, value):
        if value:
            if self._window is None:
                self._window = TrackingMotionPathWindow(
                    title=self.WINDOW_NAME,
                    width=560,
                    height=360,
                    model=self._model,
                    motion_path_adapters=self._motion_path_adapters,
                    ensure_adapters_match_model_fn=self.ensure_adapters_match_model,
                    scenario_controller=self._scenario_controller,
                    wheel_sync_controllers=self._wheel_sync_controllers,
                    driver_camera_controller=self._driver_camera_controller,
                    steering_wheel_controller=self._steering_wheel_controller,
                    movie_capture_controller=self._movie_capture_controller,
                    on_record_movie=self._movie_capture_controller.record,
                    on_pause_movie=self._movie_capture_controller.pause_or_resume,
                    on_stop_movie=self._movie_capture_controller.stop,
                    on_open_movie_capture_advanced=self._movie_capture_controller.open_advanced_settings,
                    trajectory_importer=self._trajectory_importer,
                    trajectory_playback_controller=self._trajectory_playback_controller,
                   
                )
                


            else:
                self._window.visible = True
        elif self._window:
            self._window.visible = False

    def _on_visibility_changed(self, visible):
        LOGGER.debug("Window visibility changed: %s", visible)

    # ------------------------------------------------------------------
    # Shutdown
    # ------------------------------------------------------------------
    def on_shutdown(self):
        LOGGER.info("Tracking Motion Path extension shutting down.")

        try:
            self._full_cleanup_before_shutdown()
        except Exception:
            LOGGER.exception("Full shutdown cleanup failed.")

        # Release scenario update subscription
        try:
            if self._scenario_controller:
                self._scenario_controller.shutdown()
        except Exception:
            LOGGER.exception("Failed to shutdown scenario controller.")

        try:
            if hasattr(self, "_gamepad_camera") and self._gamepad_camera:
                self._gamepad_camera.shutdown()
        except Exception:
            LOGGER.debug("Gamepad camera shutdown failed.", exc_info=True)

        try:
            if hasattr(self, "_gamepad_drive") and self._gamepad_drive:
                self._gamepad_drive.shutdown()
        except Exception:
            LOGGER.debug("Gamepad drive shutdown failed.", exc_info=True)

        try:
            if hasattr(self, "_speed_controller") and self._speed_controller:
                self._speed_controller.shutdown()
        except Exception:
            LOGGER.debug("Speed controller shutdown failed.", exc_info=True)


        # Workspace window callback
        try:
            ui.Workspace.set_show_window_fn(self.WINDOW_NAME, None)
        except Exception:
            LOGGER.debug(
                "Failed to clear Workspace show window callback.",
                exc_info=True,
            )

        # Shutdown wheel controllers
        try:
            for controller in self._wheel_sync_controllers or []:
                try:
                    controller.shutdown()
                except Exception:
                    LOGGER.exception("Failed to shutdown a wheel sync controller.")
        except Exception:
            LOGGER.exception("Failed to shutdown wheel sync controllers.")

        # Shutdown steering wheel controller
        try:
            if self._steering_wheel_controller:
                self._steering_wheel_controller.shutdown()
        except Exception:
            LOGGER.exception("Failed to shutdown steering wheel controller.")

        # Destroy window
        try:
            if self._window:
                self._window.destroy()
        except Exception:
            LOGGER.exception("Failed to destroy Tracking Motion Path window.")


        # Final camera cleanup
        try:
            if self._driver_camera_controller:
                self._driver_camera_controller.cleanup()
        except Exception:
            LOGGER.exception("Failed to cleanup driver/spectator cameras.")


        if self._movie_capture_controller is not None:
            try:
                self._movie_capture_controller.shutdown()
            except Exception:
                LOGGER.debug("Movie capture controller shutdown failed.", exc_info=True)
            self._movie_capture_controller = None

        
        if self._hud:
            self._hud.destroy()
            self._hud = None


        try:
            if hasattr(self, "_trajectory_playback_controller") and self._trajectory_playback_controller:
                self._trajectory_playback_controller.shutdown()
        except Exception:
            LOGGER.debug("Trajectory playback shutdown failed.", exc_info=True)


       


        # Clear references
        self._window = None
        self._scenario_controller = None
        self._wheel_sync_controllers = []
        self._steering_wheel_controller = None
        self._motion_path_adapters = []
        self._driver_camera_controller = None
        self._movie_capture_controller = None
        self._gamepad_camera = None
        self._gamepad_drive = None
        self._speed_controller = None
        self._model = None

        self._trajectory_playback_controller = None
        self._trajectory_importer = None

        LOGGER.info("Tracking Motion Path extension shut down.")

    def _full_cleanup_before_shutdown(self):
        LOGGER.info("Running full pre-shutdown cleanup for Tracking Motion Path.")

        # 1) Stop scenario playback and reset runtime state
        try:
            if self._scenario_controller:
                self._scenario_controller.stop_and_reset()
        except Exception:
            LOGGER.debug(
                "Scenario stop/reset failed during shutdown cleanup.",
                exc_info=True,
            )

        # 2) Clear wheel visuals / captures while controllers still know their vehicles
        try:
            for controller in list(self._wheel_sync_controllers or []):
                try:
                    if hasattr(controller, "clear_wheels"):
                        controller.clear_wheels()
                except Exception:
                    LOGGER.exception(
                        "Failed clearing wheel controller during shutdown cleanup."
                    )
        except Exception:
            LOGGER.exception(
                "Unexpected failure clearing wheel controllers during shutdown cleanup."
            )

        # 3) Clear steering wheel visual / capture
        try:
            if self._steering_wheel_controller:
                try:
                    if hasattr(self._steering_wheel_controller, "clear_steering_wheel"):
                        self._steering_wheel_controller.clear_steering_wheel()
                except Exception:
                    LOGGER.exception(
                        "Failed clearing steering wheel during shutdown cleanup."
                    )
        except Exception:
            LOGGER.exception(
                "Unexpected failure clearing steering wheel during shutdown cleanup."
            )

        # 4) Reset every adapter while snapshots still exist
        try:
            for adapter in list(self._motion_path_adapters or []):
                try:
                    adapter.reset_extension_state()
                except Exception:
                    LOGGER.exception("Failed adapter reset during shutdown cleanup.")
        except Exception:
            LOGGER.exception(
                "Unexpected failure resetting adapters during shutdown cleanup."
            )

        # 5) Fallback: remove any orphan graph roots still on stage
        try:
            self._remove_orphan_tracking_graphs()
        except Exception:
            LOGGER.exception("Failed orphan graph cleanup during shutdown.")

        # 6) Remove cameras after graph / vehicle cleanup
        try:
            if self._driver_camera_controller:
                self._driver_camera_controller.cleanup()
        except Exception:
            LOGGER.exception("Failed camera cleanup during shutdown cleanup.")

    def _remove_orphan_tracking_graphs(self) -> int:
        stage = omni.usd.get_context().get_stage()
        if not stage:
            return 0

        graph_paths = []
        for prim in stage.Traverse():
            if not prim or not prim.IsValid():
                continue

            path = str(prim.GetPath())
            if (
                prim.GetTypeName() == "OmniGraph"
                and path.startswith("/World/TrackingMotionPathGraph")
            ):
                graph_paths.append(path)

        removed = 0
        for path in sorted(graph_paths, key=len, reverse=True):
            prim = stage.GetPrimAtPath(path)
            if prim and prim.IsValid():
                try:
                    stage.RemovePrim(path)
                    removed += 1
                except Exception:
                    LOGGER.exception(
                        "Failed removing orphan Tracking Motion Path graph: %s",
                        path,
                    )

        if removed:
            LOGGER.warning(
                "Removed %s orphan Tracking Motion Path graph(s) during shutdown.",
                removed,
            )

        return removed
    

    def _on_speed_changed(self, speed_kmh: float) -> None:
        if self._hud:
            self._hud.set_speed(abs(speed_kmh))   # optional: nicer dashboard behavior
            self._refresh_hud_visibility()


    def _should_show_hud(self) -> bool:
        return (
            getattr(self._model, "scenario_mode", None) == "manual"
            and bool(getattr(self._model, "show_hud", True))
        )

    def _refresh_hud_visibility(self) -> None:
        if self._hud:
            self._hud.set_visible(self._should_show_hud())

        
    def _apply_scenario_mode(self, new_mode: str):
        """
        Apply scenario mode change (auto/manual) with full side effects.
        Shared by UI and gamepad.
        """
        new_mode = str(new_mode).lower()
        index = 1 if new_mode == "manual" else 0

        previous_mode = str(
            getattr(self._model, "scenario_mode", "auto") or "auto"
        ).lower()

        if new_mode == previous_mode:
            return

        was_running = bool(
            getattr(self._model.runtime, "scenario_running", False)
        )

        if was_running and self._scenario_controller:
            try:
                self._scenario_controller.stop_and_reset()
            except Exception:
                LOGGER.debug(
                    "Scenario stop failed during mode change.",
                    exc_info=True,
                )

       
        self._model.scenario_mode = new_mode
        self._scenario_mode_default_index = index

        if new_mode == "manual":
            self._model.movie_capture_range_mode = "custom"
            self._capture_range_mode_default_index = 1

            if float(
                getattr(self._model, "movie_capture_end_seconds", 0.0) or 0.0
            ) <= 0.0:
                self._model.movie_capture_end_seconds = 60.0

            self._model.movie_capture_start_seconds = 0.0

            try:
                self._movie_capture_start_seconds_model.set_value(0.0)
                self._movie_capture_end_seconds_model.set_value(
                    float(self._model.movie_capture_end_seconds)
                )
            except Exception:
                LOGGER.debug(
                    "Failed seeding custom capture range.",
                    exc_info=True,
                )

            status_text = "Mode: manual drive."
        else:
            status_text = "Mode: auto (constant speed)."

        if was_running:
            status_text += " Scenario stopped. Restart to apply."

        
        self._model.runtime.status_text = status_text

           
        try:
            if hasattr(self, "_scenario_mode_model") and self._scenario_mode_model:
                # 0 = auto, 1 = manual
                ui_index = 1 if new_mode == "manual" else 0
                self._scenario_mode_model.set_value(ui_index)
        except Exception:
            LOGGER.debug(
                "Failed to sync scenario mode UI state.",
                exc_info=True,
            )
        



    def _on_gamepad_toggle_scenario_mode(self):
        new_mode = "manual" if self._model.scenario_mode == "auto" else "auto"
        self._scenario_controller.set_scenario_mode(new_mode)




    def _on_gamepad_start(self):
        if self._is_recorded_trajectory_mode():
            try:
                self._trajectory_playback_controller.load_from_model()
                self._trajectory_playback_controller.start()
                self._model.runtime.status_text = "Recorded trajectory started."
            except Exception as exc:
                LOGGER.exception("Recorded trajectory start failed: %s", exc)
                self._model.runtime.last_error = str(exc)
            return

        # OLD BEHAVIOR UNCHANGED
        if self._window and hasattr(self._window, "_on_start"):
            self._window._on_start()



    def _on_gamepad_pause_resume(self):
        if self._is_recorded_trajectory_mode():
            try:
                self._trajectory_playback_controller.pause_resume()
            except Exception as exc:
                LOGGER.exception("Recorded trajectory pause/resume failed: %s", exc)
                self._model.runtime.last_error = str(exc)
            return

        # OLD BEHAVIOR UNCHANGED
        try:
            timeline = omni.timeline.get_timeline_interface()

            if timeline.is_playing():
                timeline.pause()
                self._model.runtime.status_text = "Gamepad: pause"
            else:
                timeline.play()
                self._model.runtime.status_text = "Gamepad: resume"

        except Exception as exc:
            LOGGER.exception("Gamepad pause/resume failed: %s", exc)
            self._model.runtime.last_error = str(exc)

    def _on_gamepad_stop_reset(self):
        """
        Stop playback and reset everything to the start.
        """
        if self._is_recorded_trajectory_mode():
            try:
                self._trajectory_playback_controller.stop_reset()
            except Exception as exc:
                LOGGER.exception("Recorded trajectory stop/reset failed: %s", exc)
                self._model.runtime.last_error = str(exc)
            return

        # OLD BEHAVIOR UNCHANGED
        try:
            timeline = omni.timeline.get_timeline_interface()
            timeline.stop()

            try:
                timeline.set_current_time(float(timeline.get_start_time()))
            except Exception:
                timeline.set_current_time(0.0)

            # Reset motion path adapters
            self._reset_motion_path_to_start()

            # Clear runtime/manual state safely
            if hasattr(self._model.runtime, "accumulated_distance"):
                self._model.runtime.accumulated_distance = 0.0
            if hasattr(self._model.runtime, "current_u_value"):
                self._model.runtime.current_u_value = 0.0

            self._model.runtime.status_text = "Gamepad: stop & reset"
            LOGGER.info("Gamepad stop & reset executed")

        except Exception as exc:
            LOGGER.exception("Gamepad stop/reset failed: %s", exc)
            self._model.runtime.last_error = str(exc)

    def _reset_motion_path_to_start(self):
        adapters = []

        if hasattr(self, "_motion_path_adapter") and self._motion_path_adapter:
            adapters.append(self._motion_path_adapter)

        if hasattr(self, "_motion_path_adapters"):
            adapters.extend(self._motion_path_adapters)

        seen = set()
        for adapter in adapters:
            if id(adapter) in seen:
                continue
            seen.add(id(adapter))

            if hasattr(adapter, "reset_motion_to_start"):
                adapter.reset_motion_to_start()


    def _is_recorded_trajectory_mode(self) -> bool:
        return str(getattr(self._model, "pose_source_mode", "motion_path")) == "recorded_trajectory"