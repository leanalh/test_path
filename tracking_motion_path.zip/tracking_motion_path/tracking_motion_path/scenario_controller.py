import logging
import math
import bisect
from typing import Optional

import omni.kit.app
import omni.timeline
import omni.usd
from pxr import Gf, Usd, UsdGeom

from .wheel_sync import WheelSyncController

LOGGER = logging.getLogger("tracking_motion_path.scenario_controller")

# Omniverse default when meters_per_unit isn't authored on the stage.
_FALLBACK_METERS_PER_UNIT = 0.01
_MIN_SPEED_KMH = 1.0


def compute_duration_seconds(
    curve_length_stage_units: float,
    target_speed_kmh: float,
    meters_per_unit: float,
) -> float:
    """
    Derive scenario duration from path length and target travel speed.

    Returns 0.0 when the curve hasn't been measured yet (caller decides what
    to render in that case). Raises ValueError on non-positive speed so the
    UI can surface a clear message instead of a silent divide-by-zero.
    """
    if target_speed_kmh <= 0.0:
        raise ValueError("Speed must be > 0 km/h")

    if curve_length_stage_units <= 0.0:
        return 0.0

    if not meters_per_unit or meters_per_unit <= 1e-12:
        LOGGER.debug(
            "meters_per_unit is unset or invalid (%r); falling back to %s.",
            meters_per_unit,
            _FALLBACK_METERS_PER_UNIT,
        )
        meters_per_unit = _FALLBACK_METERS_PER_UNIT

    path_length_meters = float(curve_length_stage_units) * float(meters_per_unit)
    speed_mps = float(target_speed_kmh) / 3.6
    return path_length_meters / speed_mps


class ScenarioController:
    """
    Clean multi-vehicle scenario controller.

    Guarantees:
    - Correct convoy placement immediately after graph creation
    - Stop / Reset restores the same convoy pose
    - No overlap on open paths
    - No teleport to end unless wrap is enabled
    """

    # ------------------------------------------------------------------
    # Init
    # ------------------------------------------------------------------
    def __init__(
        self,
        model,
        motion_path_adapters,
        wheel_sync_controllers,
        steering_wheel_controller,
        speed_controller=None,
    ):
        self._model = model
        self._adapters = list(motion_path_adapters)
        self._wheel_sync_controllers = list(wheel_sync_controllers)
        self._steering_wheel_controller = steering_wheel_controller
        self._speed_controller = speed_controller

        self._timeline = omni.timeline.get_timeline_interface()
        self._app = omni.kit.app.get_app()

        self._update_sub = (
            self._app.get_update_event_stream().create_subscription_to_pop(
                self._on_update,
                name="tracking_motion_path.scenario_controller",
            )
        )

        self._scenario_start_time_s = 0.0
        self._scenario_end_time_s = 0.0

        self._cached_curve_length_stage_units = 0.0
        self._cached_curve_path = None

        self._previous_u = None

        # Manual-mode driving state (signed mm along path).
        self._manual_distance_mm = 0.0
        self._previous_tick_time_s: Optional[float] = None

        self._wheel_sync = WheelSyncController(model)

    def set_speed_controller(self, speed_controller):
        self._speed_controller = speed_controller


    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def set_adapters(self, adapters):
        self._adapters = list(adapters)

    def set_wheel_sync_controllers(self, controllers):
        self._wheel_sync_controllers = list(controllers)

    # ------------------------------------------------------------------
    # Scenario lifecycle
    # ------------------------------------------------------------------
    def start_scenario(self):
        self._validate_capture_state()

        manual_mode = self._is_manual_mode()

        # Auto mode derives duration from speed + path length. Manual mode
        # has no fixed duration — the user decides when to stop.
        if not manual_mode:
            self.recompute_duration()

        # Reset manual-drive bookkeeping each time we start.
        self._manual_distance_mm = 0.0
        self._previous_tick_time_s = None
        if self._speed_controller is not None:
            try:
                self._speed_controller.reset()
            except Exception:
                LOGGER.debug("Speed controller reset failed.", exc_info=True)

        start_frame = int(self._model.start_frame)
        if manual_mode:
            end_frame = self._get_manual_safety_end_frame(start_frame)
        else:
            end_frame = int(self._get_effective_end_frame())

        # ✅ Guard: scenario must span at least 1 frame
        if end_frame <= start_frame:
            end_frame = start_frame + 1

        self._set_timeline_range(start_frame, end_frame)

        self._scenario_start_time_s = self._frame_to_seconds(start_frame)
        self._scenario_end_time_s = self._frame_to_seconds(end_frame)

        # ✅ Guard again after conversion
        if self._scenario_end_time_s <= self._scenario_start_time_s:
            self._scenario_end_time_s = self._scenario_start_time_s + (1.0 / max(self._get_fps(), 1.0))

        # Force convoy placement BEFORE first playback
        self._position_vehicles_at_scenario_start()

        # Start wheel controllers
        for controller in self._wheel_sync_controllers:
            if hasattr(controller, "prepare_for_scenario"):
                controller.prepare_for_scenario()
            if hasattr(controller, "start"):
                controller.start()

        # Start steering wheel controller
        if hasattr(self, "_steering_wheel_controller") and self._steering_wheel_controller:
            if hasattr(self._steering_wheel_controller, "prepare_for_scenario"):
                self._steering_wheel_controller.prepare_for_scenario()
            if hasattr(self._steering_wheel_controller, "start"):
                self._steering_wheel_controller.start()

        self._timeline.play()

        self._model.runtime.wheel_sync_enabled = True
        self._model.runtime.scenario_running = True
        self._model.runtime.status_text = "Scenario running."

    def pause_scenario(self):
        if self._timeline.is_playing():
            self._timeline.pause()
        else:
            self._timeline.play()

    def stop_and_reset(self):
        self._timeline.stop()

        for controller in self._wheel_sync_controllers:
            controller.stop()
            if hasattr(controller, "reset"):
                controller.reset()

        if self._steering_wheel_controller:
            if hasattr(self._steering_wheel_controller, "stop"):
                self._steering_wheel_controller.stop()
            if hasattr(self._steering_wheel_controller, "reset"):
                self._steering_wheel_controller.reset()

        if self._speed_controller is not None:
            try:
                self._speed_controller.reset()
            except Exception:
                LOGGER.debug("Speed controller reset failed.", exc_info=True)

        self._manual_distance_mm = 0.0
        self._previous_tick_time_s = None

        self._position_vehicles_at_scenario_start()

        self._model.runtime.wheel_sync_enabled = False
        self._model.runtime.scenario_running = False
        self._model.runtime.status_text = "Scenario stopped and reset."



    def shutdown(self):
        self._update_sub = None

    
    def _on_update(self, _event):
        if not self._model.runtime.scenario_running:
            return
        if not self._timeline.is_playing():
            return
        if not self._adapters:
            return

        # Leader defines the path timing
        leader = self._adapters[0]

        total_distance_mm = leader.get_total_distance_mm()
        wrap = bool(getattr(self._model, "wrap_offsets_on_closed_path", False))

        manual_mode = self._is_manual_mode()

        if manual_mode:
            leader_distance_mm, finished = self._advance_manual(
                total_distance_mm, wrap
            )
        else:
            leader_distance_mm, finished = self._advance_auto(total_distance_mm)

        # Move ALL vehicles using distance -> U
        for index, adapter in enumerate(self._adapters):
            vehicle = self._model.get_vehicle(index)

            if not vehicle.enabled:
                continue
            if not adapter.has_valid_motion_path():
                continue

            offset_distance_m = float(getattr(vehicle, "offset_distance_m", 0.0))
            offset_distance_mm = offset_distance_m * 1000.0

            target_distance_mm = leader_distance_mm - offset_distance_mm

            if wrap and total_distance_mm > 1e-6:
                target_distance_mm = target_distance_mm % total_distance_mm
            else:
                target_distance_mm = max(0.0, target_distance_mm)

            target_u = adapter.distance_to_u(target_distance_mm)
            adapter.set_u_value(target_u)

        # Publish ABSOLUTE leader distance for wheels
        self._model.runtime.accumulated_distance = float(leader_distance_mm)

        # Publish current U for UI/debug
        self._model.runtime.current_u_value = float(
            leader.distance_to_u(leader_distance_mm)
        )

        if finished:
            self.stop_and_reset()

    # ------------------------------------------------------------------
    # Per-mode advance helpers
    # ------------------------------------------------------------------
    def _advance_auto(self, total_distance_mm: float):
        """Classic constant-speed: distance = t * total_distance."""
        span = self._scenario_end_time_s - self._scenario_start_time_s
        if span <= 0.0:
            t = 1.0
        else:
            t = (
                self._timeline.get_current_time() - self._scenario_start_time_s
            ) / span
        t = max(0.0, min(1.0, float(t)))

        leader_distance_mm = t * total_distance_mm
        finished = t >= 1.0
        return leader_distance_mm, finished

    def _advance_manual(self, total_distance_mm: float, wrap: bool):
        """
        Manual mode: accumulate distance from the speed controller's velocity.
        Ends on open paths when we reach the end; loops forever on closed.
        """
        now = float(self._timeline.get_current_time())
        if self._previous_tick_time_s is None:
            dt = 0.0
        else:
            dt = max(0.0, now - self._previous_tick_time_s)
        self._previous_tick_time_s = now

        velocity_mm_per_s = 0.0
        if self._speed_controller is not None:
            try:
                velocity_mm_per_s = float(self._speed_controller.update(dt))
            except Exception:
                LOGGER.debug("Speed controller update failed.", exc_info=True)
                velocity_mm_per_s = 0.0

        self._manual_distance_mm += velocity_mm_per_s * dt

        finished = False
        if wrap and total_distance_mm > 1e-6:
            # Signed wrap so reversing past the start loops the other way.
            self._manual_distance_mm %= total_distance_mm
        else:
            # Open path: don't let user reverse past the start or overshoot
            # the end.
            if self._manual_distance_mm < 0.0:
                self._manual_distance_mm = 0.0
            if self._manual_distance_mm >= total_distance_mm > 0.0:
                self._manual_distance_mm = total_distance_mm
                finished = True

        return self._manual_distance_mm, finished

    def _is_manual_mode(self) -> bool:
        return (
            str(getattr(self._model, "scenario_mode", "auto")).lower() == "manual"
        )

    def _get_manual_safety_end_frame(self, start_frame: int) -> int:
        """
        Manual mode needs a timeline span so wheel sync / steering wheel
        controllers can sample motion, but the length is open-ended. Pick a
        cap large enough that the user will never bump into it naturally:
        path length at 1 km/h, with a floor of 10 minutes.
        """
        stage = omni.usd.get_context().get_stage()
        tps = stage.GetTimeCodesPerSecond() if stage else 24.0
        if not tps:
            tps = 24.0

        length_m = 0.0
        try:
            length = self.get_path_length_meters()
            if length is not None:
                length_m = float(length)
        except Exception:
            LOGGER.debug("get_path_length_meters failed in safety cap.", exc_info=True)

        # Seconds at a 1 km/h crawl, floored at 10 minutes so short paths still
        # have plenty of headroom.
        safety_seconds = max(600.0, length_m / (1.0 / 3.6))
        frames = max(1, int(round(safety_seconds * float(tps))))
        return start_frame + frames


    def set_scenario_mode(self, new_mode: str):
        new_mode = str(new_mode).lower()
        prev_mode = str(
            getattr(self._model, "scenario_mode", "auto") or "auto"
        ).lower()

        if new_mode == prev_mode:
            return

        was_running = bool(
            getattr(self._model.runtime, "scenario_running", False)
        )
        if was_running:
            self.stop_and_reset()

        self._model.scenario_mode = new_mode

        self._previous_tick_time_s = None
        self._manual_distance_mm = 0.0

        # ✅ THIS is what makes path length & duration appear immediately
        self.start_scenario()
        self.pause_scenario()



    def _position_vehicles_at_scenario_start(self):
        
        self._refresh_curve_length_cache()
        total_length = self._get_total_path_length_stage_units()
        base_u = self._get_start_base_u(total_length)
        self._force_place_vehicles(base_u)
        self._model.runtime.current_u_value = base_u

    def _force_place_vehicles(self, base_u: float):
        total_length = self._get_total_path_length_stage_units()
        wrap = bool(getattr(self._model, "wrap_offsets_on_closed_path", False))

        placements = []

        for index, adapter in enumerate(self._adapters):
            vehicle = self._model.get_vehicle(index)

            if not vehicle.enabled:
                continue
            if not adapter.has_valid_motion_path():
                continue

            offset_u = self._get_cumulative_offset_u(index, total_length)

            if wrap:
                target_u = (base_u - offset_u) % 1.0
            else:
                target_u = max(0.0, base_u - offset_u)

            dirty_u = self._compute_dirty_u(target_u)
            placements.append((adapter, dirty_u, target_u))

        # Dirty pass
        for adapter, dirty_u, _ in placements:
            adapter.set_u_value(dirty_u)

        for adapter, _, _ in placements:
            adapter.evaluate_graph_now()

        # Final pass
        for adapter, _, target_u in placements:
            adapter.set_u_value(target_u)

        for adapter, _, _ in placements:
            adapter.evaluate_graph_now()

        # Extra safety pass
        for adapter, _, _ in placements:
            try:
                adapter.evaluate_graph_now()
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Convoy math
    # ------------------------------------------------------------------
    def _get_start_base_u(self, total_length_stage_units: float) -> float:
        """
        Leader start position.
        - wrap ON  -> leader at 0
        - wrap OFF -> leader shifted forward to make room for convoy
        """
        if getattr(self._model, "wrap_offsets_on_closed_path", False):
            return 0.0

        last = len(self._adapters) - 1
        return min(
            1.0,
            self._get_cumulative_offset_u(last, total_length_stage_units),
        )

    def _get_cumulative_offset_u(
        self,
        vehicle_index: int,
        total_length_stage_units: float,
    ) -> float:
        if vehicle_index <= 0:
            return 0.0

        stage = omni.usd.get_context().get_stage()
        if not stage:
            return 0.0

        meters_per_unit = UsdGeom.GetStageMetersPerUnit(stage)
        if not meters_per_unit or meters_per_unit <= 1e-12:
            return 0.0

        total_u = 0.0

        for i in range(1, vehicle_index + 1):
            vehicle = self._model.get_vehicle(i)
            if not vehicle.enabled:
                continue

            dist_m = float(getattr(vehicle, "offset_distance_m", 0.0))
            if dist_m <= 0.0:
                continue

            dist_stage_units = dist_m / meters_per_unit

            if total_length_stage_units > 1e-8:
                total_u += dist_stage_units / total_length_stage_units

        return float(total_u)

    def _compute_dirty_u(self, target_u: float, eps: float = 1e-3) -> float:
        if target_u <= eps:
            return eps
        return max(0.0, target_u - eps)

    # ------------------------------------------------------------------
    # Curve helpers
    # ------------------------------------------------------------------
    def _refresh_curve_length_cache(self):
        curve_path = str(getattr(self._model, "curve_path", None) or "")
        if curve_path != self._cached_curve_path:
            self._cached_curve_length_stage_units = self._resolve_curve_length_stage_units()
            self._cached_curve_path = curve_path

    def invalidate_curve_length_cache(self):
        """Force the next length lookup to re-measure the curve (call after capture)."""
        self._cached_curve_path = None
        self._cached_curve_length_stage_units = 0.0

    def get_path_length_meters(self) -> Optional[float]:
        """
        Returns the captured curve length in meters, or None if no curve is
        captured yet. Used by the UI to show a read-only path-length readout.
        """
        self._refresh_curve_length_cache()
        length_units = float(self._cached_curve_length_stage_units)
        if length_units <= 0.0:
            return None

        meters_per_unit = self._get_meters_per_unit()
        return length_units * meters_per_unit

    def get_derived_duration_seconds(self) -> Optional[float]:
        """
        Compute the scenario duration from target speed and path length.
        Returns None when no curve is captured yet so the UI can show "—".
        Raises ValueError if speed is non-positive (caller should clamp first).
        """
        speed = float(getattr(self._model, "target_speed_kmh", 50.0) or 0.0)
        self._refresh_curve_length_cache()
        length_units = float(self._cached_curve_length_stage_units)
        if length_units <= 0.0:
            return None

        meters_per_unit = self._get_meters_per_unit()
        duration = compute_duration_seconds(length_units, speed, meters_per_unit)
        return duration if duration > 0.0 else None

    def recompute_duration(self) -> Optional[float]:
        """
        Recompute the derived duration and write it back to the model so any
        downstream consumer (capture range, timeline setup) sees fresh values.
        Returns the derived duration in seconds, or None if no curve yet.
        """
        try:
            duration = self.get_derived_duration_seconds()
        except ValueError:
            # Caller (UI) is expected to clamp speed before reaching here, but
            # defend against a stale model value rather than crashing playback.
            return None

        if duration is None:
            return None

        self._model.duration_seconds = float(duration)

        # Auto-mode capture range follows the scenario duration.
        range_mode = str(getattr(self._model, "movie_capture_range_mode", "auto") or "auto").lower()
        if range_mode == "auto":
            self._model.movie_capture_start_seconds = 0.0
            self._model.movie_capture_end_seconds = float(duration)

        return duration

    def _get_meters_per_unit(self) -> float:
        stage = omni.usd.get_context().get_stage()
        if stage is None:
            return _FALLBACK_METERS_PER_UNIT
        try:
            value = float(UsdGeom.GetStageMetersPerUnit(stage))
        except Exception:
            value = 0.0
        if value <= 1e-12:
            return _FALLBACK_METERS_PER_UNIT
        return value

    def _get_total_path_length_stage_units(self) -> float:
        self._refresh_curve_length_cache()
        return float(self._cached_curve_length_stage_units)

    def _resolve_curve_length_stage_units(self) -> float:
        stage = omni.usd.get_context().get_stage()
        if not stage or not self._model.curve_path:
            return 0.0

        prim = stage.GetPrimAtPath(str(self._model.curve_path))
        if not prim or not prim.IsA(UsdGeom.BasisCurves):
            return 0.0

        curve = UsdGeom.BasisCurves(prim)
        points = curve.GetPointsAttr().Get()
        if not points or len(points) < 2:
            return 0.0

        xform = UsdGeom.XformCache(Usd.TimeCode.Default()).GetLocalToWorldTransform(prim)

        total = 0.0
        for i in range(1, len(points)):
            p0 = xform.Transform(Gf.Vec3d(*points[i - 1]))
            p1 = xform.Transform(Gf.Vec3d(*points[i]))
            total += (p1 - p0).GetLength()

        return total

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------
    def _validate_capture_state(self):
        if not self._model.curve_path:
            raise RuntimeError("Capture a curve first.")
        if not self._model.vehicles:
            raise RuntimeError("Capture at least one vehicle.")

    def _set_timeline_range(self, start_frame: int, end_frame: int):
        self._timeline.set_start_time(self._frame_to_seconds(start_frame))
        self._timeline.set_end_time(self._frame_to_seconds(end_frame))
        self._timeline.set_current_time(self._frame_to_seconds(start_frame))

    def _get_effective_end_frame(self) -> int:
        start_frame = int(self._model.start_frame)

        # Prefer the speed-derived duration (recompute_duration writes it back
        # to model.duration_seconds before start). hasattr-guard so a legacy
        # model dict missing target_speed_kmh AND duration_seconds can still
        # fall through to the explicit end_frame path.
        has_speed = hasattr(self._model, "target_speed_kmh")
        has_duration = hasattr(self._model, "duration_seconds")

        if has_speed or has_duration:
            duration_seconds = float(getattr(self._model, "duration_seconds", 0.0) or 0.0)
            if duration_seconds > 0.0:
                stage = omni.usd.get_context().get_stage()
                if not stage:
                    raise RuntimeError("No USD stage is open.")

                tps = stage.GetTimeCodesPerSecond()
                if not tps:
                    tps = 24.0

                duration_frames = max(1, int(round(duration_seconds * float(tps))))
                return start_frame + duration_frames

        # Legacy fallback: scenes saved before the speed-driven model only had
        # an explicit end_frame.
        end_frame = int(self._model.end_frame)
        if end_frame <= start_frame:
            raise ValueError("end_frame must be greater than start_frame.")

        return end_frame


    @staticmethod
    def _frame_to_seconds(frame: int) -> float:
        stage = omni.usd.get_context().get_stage()
        tps = stage.GetTimeCodesPerSecond() if stage else 24.0
        return float(frame) / float(tps)



  

