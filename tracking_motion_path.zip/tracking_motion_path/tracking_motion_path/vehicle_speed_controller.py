import logging
from typing import Callable, Optional

LOGGER = logging.getLogger("tracking_motion_path.vehicle_speed")

# A bad VR frame can stretch dt to half a second; without a clamp the vehicle
# would jump several meters from a single tick.
_MAX_DT_S = 0.1


class VehicleSpeedController:
    """
    Integrates user throttle / brake / reverse input into a live velocity
    along the captured path. Used only when scenario_mode == "manual".

    Velocity is signed: positive = forward along the curve, negative = reverse.
    The scenario controller calls update(dt) once per tick and feeds the
    returned mm/s into its distance integrator.
    """

    # Tuning constants — promote to AppModel later if drivers want to edit.
    ACCELERATION_MS2 = 4.0       # m/s² when throttle pinned
    BRAKE_DECEL_MS2 = 20.0       # m/s² when brake pinned
    COAST_DECEL_MS2 = 1.5        # m/s² with no input (engine-braking feel)
    REVERSE_MAX_SPEED_MS = 5.0   # hard cap for reverse — slow & deliberate

    def __init__(
        self,
        model,
        on_speed_changed: Optional[Callable[[float], None]] = None,
    ):
        self._model = model
        self._on_speed_changed = on_speed_changed

        self._current_velocity_ms: float = 0.0
        self._throttle: float = 0.0
        self._brake: float = 0.0
        self._reverse: bool = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def startup(self):
        self.reset()

    def shutdown(self):
        self.reset()

    def reset(self):
        self._current_velocity_ms = 0.0
        self._throttle = 0.0
        self._brake = 0.0
        self._reverse = False
        self._publish_runtime()

    # ------------------------------------------------------------------
    # Input setters (called from the gamepad controller)
    # ------------------------------------------------------------------
    def set_throttle(self, value: float) -> None:
        self._throttle = _clamp01(value)

    def set_brake(self, value: float) -> None:
        self._brake = _clamp01(value)

    def set_reverse(self, enabled: bool) -> None:
        self._reverse = bool(enabled)

    def toggle_reverse(self) -> bool:
        self._reverse = not self._reverse
        return self._reverse

    # ------------------------------------------------------------------
    # Per-frame integration
    # ------------------------------------------------------------------
    def update(self, dt: float) -> float:
        """
        Integrate one tick. Returns the current velocity in mm/s for the
        scenario controller's distance accumulator.
        """
        if dt <= 0.0:
            return self._current_velocity_ms * 1000.0

        # VR drops or paused frames can spike dt; clamp so a bad tick doesn't
        # catapult the vehicle.
        if dt > _MAX_DT_S:
            dt = _MAX_DT_S

        target_speed_ms = self._get_target_speed_ms()

        # Brake wins over throttle (real-car behavior).
        if self._brake > 0.0:
            decel = self.BRAKE_DECEL_MS2 * self._brake * dt
            self._current_velocity_ms = _decay_to_zero(
                self._current_velocity_ms, decel
            )
        elif self._throttle > 0.0:
            if self._reverse:
                # Reverse requested: only apply once we're at or below 0.
                # If still moving forward, coast/decel down first so the user
                # doesn't slam into negative velocity at speed.
                if self._current_velocity_ms > 0.0:
                    decel = self.COAST_DECEL_MS2 * dt
                    self._current_velocity_ms = max(
                        0.0, self._current_velocity_ms - decel
                    )
                else:
                    accel = self.ACCELERATION_MS2 * self._throttle * dt
                    self._current_velocity_ms = max(
                        -self.REVERSE_MAX_SPEED_MS,
                        self._current_velocity_ms - accel,
                    )
            else:
                # Forward throttle. If we were reversing, climb back to 0
                # first under the same throttle.
                accel = self.ACCELERATION_MS2 * self._throttle * dt
                self._current_velocity_ms = min(
                    target_speed_ms,
                    self._current_velocity_ms + accel,
                )
        else:
            # No throttle, no brake — coast toward 0.
            decel = self.COAST_DECEL_MS2 * dt
            self._current_velocity_ms = _decay_to_zero(
                self._current_velocity_ms, decel
            )

        # Final clamp: forward target may have changed if user edited the
        # speed slider mid-drive.
        self._current_velocity_ms = max(
            -self.REVERSE_MAX_SPEED_MS,
            min(target_speed_ms, self._current_velocity_ms),
        )

        self._publish_runtime()
        return self._current_velocity_ms * 1000.0

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------
    @property
    def current_velocity_ms(self) -> float:
        return self._current_velocity_ms

    @property
    def current_velocity_kmh(self) -> float:
        return self._current_velocity_ms * 3.6

    @property
    def is_reverse(self) -> bool:
        return self._reverse

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _get_target_speed_ms(self) -> float:
        speed_kmh = float(getattr(self._model, "target_speed_kmh", 50.0) or 0.0)
        if speed_kmh <= 0.0:
            speed_kmh = 1.0
        return speed_kmh / 3.6

    def _publish_runtime(self) -> None:
        speed_kmh = float(self._current_velocity_ms * 3.6)

        runtime = getattr(self._model, "runtime", None)
        if runtime is not None:
            runtime.current_velocity_kmh = speed_kmh
            runtime.is_reverse = bool(self._reverse)

        # Push the live speed to the HUD
        if self._on_speed_changed is not None:
            try:
                self._on_speed_changed(speed_kmh)
            except Exception:
                LOGGER.exception("Failed to publish vehicle speed to HUD")


def _clamp01(value) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return 0.0
    if v < 0.0:
        return 0.0
    if v > 1.0:
        return 1.0
    return v


def _decay_to_zero(value: float, magnitude: float) -> float:
    """Move value toward 0 by `magnitude`, never crossing zero."""
    if value > 0.0:
        return max(0.0, value - magnitude)
    if value < 0.0:
        return min(0.0, value + magnitude)
    return 0.0

