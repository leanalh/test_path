# tracking_motion_path/hud.py

from __future__ import annotations

import logging
from typing import Optional

import omni.ui as ui
from omni.kit.viewport.utility import get_active_viewport_window


LOGGER = logging.getLogger(__name__)


# =============================================================================
# XR compatibility probe
# -----------------------------------------------------------------------------
# Newer Kit guidance points to omni.kit.scene_view.xr_utils.
# Older XR samples use omni.kit.xr.scene_view.utils.
# We probe both so your custom Kit app can run whichever one it ships with.
# =============================================================================

XR_HELPER_FLAVOR = None
SceneViewUtils = None
UiContainer = None
WidgetComponent = None
SpatialSource = None
RotationSpace = None
Gf = None

try:
    # Preferred newer path (newer Kit naming).
    # VERIFY: source for omni.kit.scene_view.xr_utils-1.0.0 was not available
    # at patch time, so the exact public surface beyond UiContainer is a
    # best-effort guess mirrored from the legacy package. _build() catches
    # AttributeError/TypeError and falls back if those names are missing.
    from omni.kit.scene_view.xr_utils import (  # type: ignore
        SceneViewUtils,
        UiContainer,
        WidgetComponent,
        SpatialSource,
    )
    from pxr import Gf  # type: ignore
    XR_HELPER_FLAVOR = "new"
except Exception:
    try:
        # Legacy path used by NVIDIA XR sample code (Kit 106/107 / Isaac Sim 5.x).
        from omni.kit.xr.scene_view.utils import UiContainer, WidgetComponent  # type: ignore
        from omni.kit.xr.scene_view.utils.spatial_source import (  # type: ignore
            SpatialSource,
            RotationSpace,
        )
        from pxr import Gf  # type: ignore

        XR_HELPER_FLAVOR = "legacy"
    except Exception:
        XR_HELPER_FLAVOR = None


# =============================================================================
# HUD configuration
# =============================================================================

DESKTOP_HUD_SPEC = {
    "offset_px": (12, 46),          # top-left, below viewport toolbar
    "panel_size_px": (120, 50),
    "bg_color": 0xCC111827,
    "border_color": 0xFF22D3EE,
    "label_color": 0xFF93C5FD,
    "value_color": 0xFFFFFFFF,
    "warning_color": 0xFFFFB020,
    "danger_color": 0xFFFF6B6B,
    "label_font_size": 14,
    "value_font_size": 20,
    "overspeed_warning_kmh": 50.0,
    "overspeed_danger_kmh": 80.0,
}

VR_HUD_SPEC = {
    # Design target for a small head-locked HUD:
    # left, up, forward relative to headset / view space
    "offset_m": (-0.08, 0.05, -0.40),
    "size_m": (0.18, 0.06),

    # Optional legacy sample-space fallback (scene units, not meters)
    # Only used if you later decide to create a camera-facing fallback widget.
    "legacy_scene_offset": (-80.0, 50.0, -400.0),

    "bg_color": 0x66111827,
    "border_color": 0xFF22D3EE,
    "label_color": 0xFF93C5FD,
    "value_color": 0xFFFFFFFF,
    "warning_color": 0xFFFFB020,
    "danger_color": 0xFFFF6B6B,
    "label_font_size": 14,
    "value_font_size": 18,
    "overspeed_warning_kmh": 50.0,
    "overspeed_danger_kmh": 80.0,
}


# =============================================================================
# Small reusable helpers
# =============================================================================

def _speed_color(speed_kmh: float, spec: dict) -> int:
    """Return the color for the current speed value."""
    if speed_kmh >= spec["overspeed_danger_kmh"]:
        return spec["danger_color"]
    if speed_kmh >= spec["overspeed_warning_kmh"]:
        return spec["warning_color"]
    return spec["value_color"]


# =============================================================================
# Base renderer
# =============================================================================

class BaseHudRenderer:
    """Common API used by the rest of your extension."""

    def set_speed(self, speed_kmh: float) -> None:
        raise NotImplementedError()

    def set_visible(self, visible: bool) -> None:
        raise NotImplementedError()

    def destroy(self) -> None:
        raise NotImplementedError()


# =============================================================================
# Desktop viewport overlay renderer
# =============================================================================

class DesktopHudRenderer(BaseHudRenderer):
    """
    Desktop top-corner HUD using the standard viewport overlay UI path.
    """

    def __init__(self, viewport_window, ext_id: str):
        self._viewport_window = viewport_window
        self._root: Optional[ui.Widget] = None
        self._label_speed: Optional[ui.Label] = None
        self._visible = True

        x, y = DESKTOP_HUD_SPEC["offset_px"]
        width, height = DESKTOP_HUD_SPEC["panel_size_px"]

        with self._viewport_window.get_frame(f"{ext_id}.desktop_hud"):
            with ui.Placer(offset_x=x, offset_y=y, width=0, height=0):
                self._root = ui.ZStack(width=width, height=height)

                with self._root:
                    ui.Rectangle(
                        width=width,
                        height=height,
                        style={
                            "background_color": DESKTOP_HUD_SPEC["bg_color"],
                            "border_color": DESKTOP_HUD_SPEC["border_color"],
                            "border_width": 1,
                            "border_radius": 8,
                        },
                    )

                    
                    with ui.Placer(offset_x=8, offset_y=6, width=0, height=0):
                        ui.Label(
                            "SPEED",
                            alignment=ui.Alignment.LEFT_TOP,
                            style={
                                "font_size": DESKTOP_HUD_SPEC["label_font_size"],
                                "color": DESKTOP_HUD_SPEC["label_color"],
                            },
                        )

                    # Big numeric speed
                    with ui.Placer(offset_x=8, offset_y=22, width=0, height=0):
                        self._label_speed = ui.Label(
                            "000.0 km/h",
                            alignment=ui.Alignment.LEFT_TOP,
                            style={
                                "font_size": DESKTOP_HUD_SPEC["value_font_size"],
                                "color": DESKTOP_HUD_SPEC["value_color"],
                            },
                        )

    def set_speed(self, speed_kmh: float) -> None:
        if self._label_speed:
            self._label_speed.text = f"{float(speed_kmh):05.1f} km/h"
            self._label_speed.style = {
                "font_size": DESKTOP_HUD_SPEC["value_font_size"],
                "color": _speed_color(float(speed_kmh), DESKTOP_HUD_SPEC),
            }

    def set_visible(self, visible: bool) -> None:
        self._visible = bool(visible)
        if self._root:
            self._root.visible = self._visible

    def destroy(self) -> None:
        self._label_speed = None
        self._root = None
        self._viewport_window = None


# =============================================================================
# Optional XR widget class (legacy sample-style widget)
# -----------------------------------------------------------------------------
# This widget class is harmless to keep even if you do not wire the XR panel yet.
# =============================================================================

class _XrSpeedWidget(ui.Widget):
    """
    Simple UI widget used by an XR widget component if you wire the XR path.
    """

    def __init__(self, text: str = "000.0 km/h", **kwargs):
        super().__init__(**kwargs)
        self._text = text
        self._speed_label: Optional[ui.Label] = None
        self._build_ui()

    def _build_ui(self) -> None:
        with ui.ZStack(width=420, height=70):
            ui.Rectangle(
                width=420,
                height=70,
                style={
                    "background_color": VR_HUD_SPEC["bg_color"],
                    "border_color": VR_HUD_SPEC["border_color"],
                    "border_width": 2,
                    "border_radius": 8,
                },
            )
            with ui.VStack(width=420, height=70, spacing=2, style={"margin": 10}):
                ui.Label(
                    "SPEED",
                    alignment=ui.Alignment.LEFT_TOP,
                    style={
                        "font_size": VR_HUD_SPEC["label_font_size"],
                        "color": VR_HUD_SPEC["label_color"],
                    },
                )
                self._speed_label = ui.Label(
                    self._text,
                    alignment=ui.Alignment.LEFT_TOP,
                    style={
                        "font_size": VR_HUD_SPEC["value_font_size"],
                        "color": VR_HUD_SPEC["value_color"],
                    },
                )

    def set_speed_text(self, text: str, color: int) -> None:
        self._text = text
        if self._speed_label:
            self._speed_label.text = self._text
            self._speed_label.style = {
                "font_size": VR_HUD_SPEC["value_font_size"],
                "color": color,
            }


# =============================================================================
# XR head-locked renderer (safe scaffold)
# -----------------------------------------------------------------------------
# IMPORTANT:
# - This class is intentionally safe.
# - It does not crash if the exact XR helper API is not available.
# - For now, it logs clearly and lets HudController fall back to desktop overlay.
#
# Why:
# NVIDIA's XR stack is correct for VR/XR HUDs, but the exact helper attachment
# API differs between the newer and legacy helper paths, and your app package
# determines which one actually exists at runtime.
# =============================================================================

class VrHeadLockedHudRenderer(BaseHudRenderer):
    """
    XR HUD renderer placeholder / scaffold.

    Current behavior:
    - probes which XR helper flavor is available
    - exposes a clean API to the rest of the extension
    - does not crash if the head-locked API is not yet wired
    """

    def __init__(self):
        self._current_speed_kmh = 0.0
        self._visible = True

        # XR refs / handles
        self._container = None
        self._widget_component = None
        self._widget_ref = None

        self._supported = False

        self._build()

    @property
    def is_supported(self) -> bool:
        return self._supported

    def _build(self) -> None:
        if XR_HELPER_FLAVOR is None:
            LOGGER.warning(
                "[HUD] No XR helper module found. XR HUD disabled; desktop fallback will be used."
            )
            self._supported = False
            return

        LOGGER.info("[HUD] XR helper flavor detected: %s", XR_HELPER_FLAVOR)

        try:
            size_w_m, size_h_m = VR_HUD_SPEC["size_m"]
            ox, oy, oz = VR_HUD_SPEC["offset_m"]

            # VERIFY: width/height passed to WidgetComponent are scene units; with
            # stage-meters and 0.18 x 0.06 m, resolution_scale must be high enough
            # that the pixel canvas (int(width * resolution_scale * unit_to_pixel_scale))
            # exceeds the inner ZStack's 420 x 70 px. 2400 -> 432 x 144 px canvas.
            resolution_scale = 2400.0

            widget_component = WidgetComponent(
                _XrSpeedWidget,
                width=size_w_m,
                height=size_h_m,
                resolution_scale=resolution_scale,
                unit_to_pixel_scale=1.0,
                construct_callback=self._on_widget_built,
            )

            # Head-lock: LookAtCamera tracks the headset transform, then the
            # translation source positions the panel relative to that head frame.
            # Stack order matters: parent space -> child space.
            # VERIFY: the legacy API has no explicit RotationSpace.HEAD; per the
            # LookAtCameraSpace docstring this primitive is the head-tracking
            # primitive ("causes the viewport camera transform to track the
            # headset's transform").
            look_source = SpatialSource.new_look_at_camera_source()
            translation_source = SpatialSource.new_translation_source(
                Gf.Vec3d(float(ox), float(oy), float(oz))
            )

            self._container = UiContainer(
                widget_component,
                space_stack=[look_source, translation_source],
            )
            self._widget_component = widget_component
            self._supported = True
            LOGGER.info(
                "[HUD] VR head-locked HUD attached (flavor=%s).", XR_HELPER_FLAVOR
            )

        except Exception as exc:
            # VERIFY: the "new" flavor may have a different UiContainer / WidgetComponent
            # signature; on AttributeError/TypeError here the desktop fallback engages.
            LOGGER.warning(
                "[HUD] Failed to build XR HUD (flavor=%s): %s. Desktop fallback will be used.",
                XR_HELPER_FLAVOR,
                exc,
            )
            self._container = None
            self._widget_component = None
            self._widget_ref = None
            self._supported = False

    def _on_widget_built(self, widget) -> None:
        """Captured live widget instance once WidgetComponent finishes building."""
        self._widget_ref = widget
        self._apply_speed_to_widget()

    def _apply_speed_to_widget(self) -> None:
        if self._widget_ref is None:
            return
        text = f"{self._current_speed_kmh:05.1f} km/h"
        color = _speed_color(self._current_speed_kmh, VR_HUD_SPEC)
        try:
            self._widget_ref.set_speed_text(text, color)
        except Exception as exc:
            LOGGER.debug("[HUD] XR set_speed_text failed: %s", exc)

    def set_speed(self, speed_kmh: float) -> None:
        self._current_speed_kmh = float(speed_kmh)
        self._apply_speed_to_widget()

    def set_visible(self, visible: bool) -> None:
        self._visible = bool(visible)
        if self._container is None:
            return
        try:
            # Legacy UiContainer exposes a .visible property setter.
            self._container.visible = self._visible
        except Exception:
            # VERIFY: fallback for newer flavor where the property may not exist.
            try:
                if hasattr(self._container, "root") and self._container.root is not None:
                    self._container.root.visible = self._visible
            except Exception as exc:
                LOGGER.debug("[HUD] XR set_visible failed: %s", exc)

    def destroy(self) -> None:
        # XR session may already be torn down by the time this runs; swallow
        # everything so shutdown remains clean.
        try:
            if self._container is not None and hasattr(self._container, "root"):
                root = self._container.root
                if root is not None and hasattr(root, "clear"):
                    root.clear()
        except Exception:
            pass

        self._container = None
        self._widget_component = None
        self._widget_ref = None
        self._supported = False


# =============================================================================
# Public controller used by extension.py and your speed controller
# =============================================================================

class HudController:
    """
    Single public API for the rest of the extension.

    Usage:
        hud = HudController(ext_id, prefer_xr=False)
        hud.set_speed(34.7)
        hud.destroy()
    """

    def __init__(self, ext_id: str, prefer_xr: bool = False):
        self._renderer: Optional[BaseHudRenderer] = None
        self._prefer_xr = bool(prefer_xr)

        if self._prefer_xr:
            xr_renderer = VrHeadLockedHudRenderer()
            if xr_renderer.is_supported:
                self._renderer = xr_renderer
            else:
                # Safe fallback to desktop overlay so the HUD always works
                viewport_window = get_active_viewport_window()
                if viewport_window:
                    self._renderer = DesktopHudRenderer(viewport_window, ext_id)
                else:
                    LOGGER.warning("[HUD] No active viewport window found for desktop fallback.")
        else:
            viewport_window = get_active_viewport_window()
            if viewport_window:
                self._renderer = DesktopHudRenderer(viewport_window, ext_id)
            else:
                LOGGER.warning("[HUD] No active viewport window found.")

    def set_speed(self, speed_kmh: float) -> None:
        if self._renderer:
            self._renderer.set_speed(speed_kmh)

    def set_visible(self, visible: bool) -> None:
        if self._renderer:
            self._renderer.set_visible(visible)

    def destroy(self) -> None:
        if self._renderer:
            self._renderer.destroy()
            self._renderer = None