import bisect
import logging
from typing import List, Tuple

import omni.kit.app
import omni.usd
from pxr import Gf, UsdGeom

LOGGER = logging.getLogger("tracking_motion_path.trajectory_playback")


class TrajectoryPlaybackController:
    """
    Minimal-risk playback controller for imported recorded trajectories.

    Expected model fields:
        model.vehicle_rig_path
        model.trajectory_times_s
        model.trajectory_positions_stage
        model.trajectory_rotations_deg
        model.trajectory_duration_s
        model.trajectory_loaded
        model.runtime.status_text
        model.runtime.last_error

    This controller is intentionally independent from MotionPathAdapter.
    It should only be used when pose_source_mode == "recorded_trajectory".
    """

    XFORM_OP_SUFFIX = "trackingMotionPathRecorded"
    MIN_SAMPLE_COUNT = 2
    MIN_DT_S = 1e-9

    def __init__(self, model):
        self._model = model
        self._app = omni.kit.app.get_app()

        self._update_sub = None

        self._enabled = False
        self._paused = False
        self._playback_time_s = 0.0

        self._times_s: List[float] = []
        self._positions_stage: List[Tuple[float, float, float]] = []
        self._rotations_deg: List[Tuple[float, float, float]] = []

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def startup(self):
        if self._update_sub is None:
            self._update_sub = (
                self._app.get_update_event_stream().create_subscription_to_pop(
                    self._on_update,
                    name="tracking_motion_path.trajectory_playback",
                )
            )
            LOGGER.info("Trajectory playback controller subscribed.")

    def shutdown(self):
        self.stop_reset()
        self._update_sub = None
        LOGGER.info("Trajectory playback controller shut down.")

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def load_from_model(self):
        """
        Load trajectory arrays from the model.
        """
        times_s = list(getattr(self._model, "trajectory_times_s", []) or [])
        positions_stage = list(getattr(self._model, "trajectory_positions_stage", []) or [])
        rotations_deg = list(getattr(self._model, "trajectory_rotations_deg", []) or [])

        self.load(
            times_s=times_s,
            positions_stage=positions_stage,
            rotations_deg=rotations_deg,
        )

    def load(self, times_s, positions_stage, rotations_deg):
        """
        Load normalized trajectory arrays.

        Assumptions:
        - times_s are monotonic and in seconds
        - positions_stage are already converted into stage units
        - rotations_deg are (pitch, roll, yaw)
        """
        if not times_s or len(times_s) < self.MIN_SAMPLE_COUNT:
            raise RuntimeError("Trajectory must contain at least 2 time samples.")

        if len(positions_stage) != len(times_s):
            raise RuntimeError("positions_stage length does not match times_s length.")

        if len(rotations_deg) != len(times_s):
            raise RuntimeError("rotations_deg length does not match times_s length.")

        normalized_times = [float(v) for v in times_s]
        for i in range(1, len(normalized_times)):
            if normalized_times[i] < normalized_times[i - 1]:
                raise RuntimeError("Trajectory times are not monotonic.")

        self._times_s = normalized_times
        self._positions_stage = [
            (float(p[0]), float(p[1]), float(p[2]))
            for p in positions_stage
        ]
        self._rotations_deg = [
            (float(r[0]), float(r[1]), float(r[2]))
            for r in rotations_deg
        ]

        self._playback_time_s = 0.0
        self._paused = False
        self._enabled = False

        try:
            self._model.trajectory_duration_s = float(self.duration_s)
            self._model.trajectory_loaded = True
        except Exception:
            LOGGER.debug("Could not write loaded trajectory info back to model.", exc_info=True)

        self._model.runtime.status_text = (
            "Recorded trajectory loaded: "
            f"{len(self._times_s)} samples, {self.duration_s:.3f}s."
        )

    # ------------------------------------------------------------------
    # Playback API
    # ------------------------------------------------------------------

    def start(self):
        self._ensure_ready()
        self._enabled = True
        self._paused = False
        self._model.runtime.status_text = (
            f"Recorded trajectory playing from {self._playback_time_s:.3f}s."
        )

    def pause_resume(self):
        self._ensure_loaded()

        if not self._enabled:
            # If not already playing, start from current time
            self.start()
            return

        self._paused = not self._paused

        if self._paused:
            self._model.runtime.status_text = (
                f"Recorded trajectory paused at {self._playback_time_s:.3f}s."
            )
        else:
            self._model.runtime.status_text = (
                f"Recorded trajectory resumed at {self._playback_time_s:.3f}s."
            )

    def stop_reset(self):
        self._enabled = False
        self._paused = False
        self._playback_time_s = 0.0

        if self.is_loaded:
            try:
                self._apply_pose(self._positions_stage[0], self._rotations_deg[0])
            except Exception:
                LOGGER.debug("Could not apply first trajectory sample during reset.", exc_info=True)

        try:
            self._model.trajectory_current_time_s = 0.0
        except Exception:
            pass

        if getattr(self._model, "runtime", None):
            self._model.runtime.status_text = "Recorded trajectory stopped and reset."

    def scrub_to_time(self, time_s: float):
        self._ensure_loaded()

        clamped = max(0.0, min(float(time_s), self.duration_s))
        self._playback_time_s = clamped

        pos, rot = self.sample_pose(clamped)
        self._apply_pose(pos, rot)

        try:
            self._model.trajectory_current_time_s = float(self._playback_time_s)
        except Exception:
            pass

        self._model.runtime.status_text = (
            f"Recorded trajectory scrubbed to {self._playback_time_s:.3f}s."
        )

    def apply_first_sample_now(self):
        self._ensure_loaded()
        self._apply_pose(self._positions_stage[0], self._rotations_deg[0])

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def is_loaded(self) -> bool:
        n = len(self._times_s)
        return (
            n >= self.MIN_SAMPLE_COUNT
            and len(self._positions_stage) == n
            and len(self._rotations_deg) == n
        )

    @property
    def duration_s(self) -> float:
        if not self._times_s:
            return 0.0
        return float(self._times_s[-1] - self._times_s[0])

    # ------------------------------------------------------------------
    # Update loop
    # ------------------------------------------------------------------

    def _on_update(self, event):
        if not self._enabled or self._paused:
            return

        try:
            self._ensure_ready()

            dt = self._extract_dt_seconds(event)
            if dt <= 0.0:
                return

            self._playback_time_s += dt

            if self._playback_time_s >= self.duration_s:
                if bool(getattr(self._model, "trajectory_loop_enabled", False)):
                    self._playback_time_s = 0.0
                else:
                    self._playback_time_s = self.duration_s
                    pos, rot = self.sample_pose(self._playback_time_s)
                    self._apply_pose(pos, rot)

                    try:
                        self._model.trajectory_current_time_s = float(self._playback_time_s)
                    except Exception:
                        pass

                    self._enabled = False
                    self._paused = False
                    self._model.runtime.status_text = "Recorded trajectory playback complete."
                    return

            pos, rot = self.sample_pose(self._playback_time_s)
            self._apply_pose(pos, rot)

            try:
                self._model.trajectory_current_time_s = float(self._playback_time_s)
            except Exception:
                pass

        except Exception as exc:
            LOGGER.exception("Recorded trajectory playback update failed: %s", exc)
            try:
                self._model.runtime.last_error = str(exc)
            except Exception:
                pass
            self._enabled = False
            self._paused = False

    # ------------------------------------------------------------------
    # Sampling
    # ------------------------------------------------------------------

    def sample_pose(self, playback_time_s: float):
        """
        Interpolate the imported pose at playback time in seconds.
        """
        self._ensure_loaded()

        t = max(0.0, min(float(playback_time_s), self.duration_s))
        t_abs = self._times_s[0] + t

        idx = bisect.bisect_right(self._times_s, t_abs) - 1
        if idx < 0:
            idx = 0

        if idx >= len(self._times_s) - 1:
            return self._positions_stage[-1], self._rotations_deg[-1]

        t0 = self._times_s[idx]
        t1 = self._times_s[idx + 1]

        if (t1 - t0) <= self.MIN_DT_S:
            return self._positions_stage[idx], self._rotations_deg[idx]

        alpha = (t_abs - t0) / (t1 - t0)
        alpha = max(0.0, min(1.0, alpha))

        p0 = self._positions_stage[idx]
        p1 = self._positions_stage[idx + 1]

        r0 = self._rotations_deg[idx]
        r1 = self._rotations_deg[idx + 1]

        pos = self._lerp_vec3(p0, p1, alpha)
        rot = self._lerp_vec3(r0, r1, alpha)

        return pos, rot

    # ------------------------------------------------------------------
    # USD pose application
    # ------------------------------------------------------------------

    def _apply_pose(self, position_stage_xyz, rotation_deg_xyz):
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        vehicle_path = getattr(self._model, "vehicle_rig_path", None)
        if not vehicle_path:
            raise RuntimeError("No captured vehicle prim is available.")

        prim = stage.GetPrimAtPath(str(vehicle_path))
        if not prim or not prim.IsValid():
            raise RuntimeError(f"Invalid vehicle prim: {vehicle_path}")

        xformable = UsdGeom.Xformable(prim)
        if not xformable:
            raise RuntimeError(f"Vehicle prim is not xformable: {vehicle_path}")

        translate_op = self._get_or_create_translate_op(xformable)
        rotate_op = self._get_or_create_rotate_xyz_op(xformable)

        self._ensure_recorded_op_order(xformable, translate_op, rotate_op)

        translate_op.Set(
            Gf.Vec3d(
                float(position_stage_xyz[0]),
                float(position_stage_xyz[1]),
                float(position_stage_xyz[2]),
            )
        )

        rotate_op.Set(
            Gf.Vec3f(
                float(rotation_deg_xyz[0]),
                float(rotation_deg_xyz[1]),
                float(rotation_deg_xyz[2]),
            )
        )

    def _get_or_create_translate_op(self, xformable):
        desired_name = f"xformOp:translate:{self.XFORM_OP_SUFFIX}"

        for op in xformable.GetOrderedXformOps():
            try:
                if op.GetOpName() == desired_name:
                    return op
            except Exception:
                pass

        return xformable.AddTranslateOp(
            precision=UsdGeom.XformOp.PrecisionDouble,
            opSuffix=self.XFORM_OP_SUFFIX,
        )

    def _get_or_create_rotate_xyz_op(self, xformable):
        desired_name = f"xformOp:rotateXYZ:{self.XFORM_OP_SUFFIX}"

        for op in xformable.GetOrderedXformOps():
            try:
                if op.GetOpName() == desired_name:
                    return op
            except Exception:
                pass

        return xformable.AddRotateXYZOp(
            precision=UsdGeom.XformOp.PrecisionFloat,
            opSuffix=self.XFORM_OP_SUFFIX,
        )

    def _ensure_recorded_op_order(self, xformable, translate_op, rotate_op):
        ordered = []
        for op in xformable.GetOrderedXformOps():
            try:
                name = op.GetOpName()
            except Exception:
                continue

            if name in (translate_op.GetOpName(), rotate_op.GetOpName()):
                continue

            ordered.append(op)

        ordered.append(translate_op)
        ordered.append(rotate_op)
        xformable.SetXformOpOrder(ordered, resetXformStack=False)

    # ------------------------------------------------------------------
    # Utility helpers
    # ------------------------------------------------------------------

    def _extract_dt_seconds(self, event) -> float:
        payload = getattr(event, "payload", None)
        if isinstance(payload, dict):
            for key in ("dt", "delta_time", "elapsed_s"):
                value = payload.get(key)
                if value is None:
                    continue
                try:
                    dt = float(value)
                    if dt > 0.0:
                        return dt
                except Exception:
                    pass

        for attr in ("dt", "delta_time", "elapsed_s"):
            try:
                value = getattr(event, attr, None)
                if value is None:
                    continue
                dt = float(value)
                if dt > 0.0:
                    return dt
            except Exception:
                pass

        return 1.0 / 60.0

    def _lerp_vec3(self, a, b, alpha):
        return (
            float(a[0] + (b[0] - a[0]) * alpha),
            float(a[1] + (b[1] - a[1]) * alpha),
            float(a[2] + (b[2] - a[2]) * alpha),
        )

    def _ensure_loaded(self):
        if not self.is_loaded:
            raise RuntimeError("No recorded trajectory is loaded.")

    def _ensure_ready(self):
        self._ensure_loaded()

        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        vehicle_path = getattr(self._model, "vehicle_rig_path", None)
        if not vehicle_path:
            raise RuntimeError("Capture the vehicle first.")

        prim = stage.GetPrimAtPath(str(vehicle_path))
        if not prim or not prim.IsValid():
            raise RuntimeError(f"Invalid vehicle prim: {vehicle_path}")