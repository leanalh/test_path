import logging
import math
from typing import List, Optional, Tuple

import omni.kit.app
import omni.timeline
import omni.usd
from pxr import Sdf, Usd, UsdGeom, Gf

LOGGER = logging.getLogger("tracking_motion_path.wheel_sync")


class WheelSyncController:

    _SPIN_OP_SUFFIX = "trackingMotionPathSpin"
    _STEER_OP_SUFFIX = "trackingMotionPathSteer"

    
    _DEFAULT_WHEEL_DIAMETER_MM = 680
    _DEFAULT_MAX_STEER_DEG = 10.0
    _DEFAULT_STEER_GAIN = 100.0
    _DEFAULT_STEER_RESPONSE = 0.5
    _DEFAULT_WHEELBASE_MM = 5000.0 


    _DISTANCE_EPSILON = 1e-8
    _POSITION_EPSILON = 1e-6
    _CURVE_SAMPLE_DU = 0.05

    # ------------------------------------------------------------------
    # Init / lifecycle
    # ------------------------------------------------------------------

    def __init__(self, model, vehicle_index: int = 0):
        self._model = model
        self._vehicle_index = int(vehicle_index)
        self._model.ensure_vehicle_count(self._vehicle_index + 1)

        self._app = omni.kit.app.get_app()
        self._timeline = omni.timeline.get_timeline_interface()

        self._update_subscription = None
        self._enabled = False

        self._meters_per_unit = 1.0
        self._resolved_wheelbase = 0.0
        self._current_steer_angle_deg = 0.0

    # ------------------------------------------------------------------
    # Model helpers
    # ------------------------------------------------------------------


    def _resolve_axes(self, axis_str: str):
        axis_str = (axis_str or "+X").upper()

        if axis_str == "+X":
            return 0, 1, 1
        if axis_str == "-X":
            return 0, 1, -1
        if axis_str == "+Y":
            return 1, 0, 1
        if axis_str == "-Y":
            return 1, 0, -1

        return 0, 1, 1

    def _vehicle_state(self):
        return self._model.get_vehicle(self._vehicle_index)

    def _wheel_settings(self):
        return self._vehicle_state().wheel

    def _get_vehicle_rig_path(self) -> Optional[str]:
        vehicle = self._vehicle_state()
        return str(vehicle.rig_path) if vehicle.rig_path else None

    def _get_motion_u_attr_path(self) -> Optional[str]:
        vehicle = self._vehicle_state()
        return str(vehicle.u_attr_path) if vehicle.u_attr_path else None

    def _get_current_u_value(self) -> float:
        attr_path = self._get_motion_u_attr_path()
        if not attr_path:
            return 0.0

        stage = omni.usd.get_context().get_stage()
        if not stage:
            return 0.0

        attr = stage.GetAttributeAtPath(Sdf.Path(attr_path))
        if not attr or not attr.IsValid():
            return 0.0

        try:
            return float(attr.Get() or 0.0)
        except Exception:
            return 0.0

   


    def assign_wheels_from_selection(self):
        """
        Assign FL, FR, RL, RR from selected wheel CTRLs using naming.
        Designed for symmetric control rigs.
        """
        stage = omni.usd.get_context().get_stage()
        selection = omni.usd.get_context().get_selection().get_selected_prim_paths()

        if len(selection) < 4:
            raise RuntimeError("Select at least 4 wheel controls.")

        wheel = self._wheel_settings()

        # Reset local temp variables (do NOT clear existing assignment yet)
        fl = fr = rl = rr = None

        for path in selection:
            prim = stage.GetPrimAtPath(path)
            if not prim or not prim.IsValid():
                continue

            

            name = prim.GetName().upper()

            if "AVG" in name:
                fl = path
            elif "AVD" in name:
                fr = path
            elif "ARG" in name:
                rl = path
            elif "ARD" in name:
                rr = path

        if not all([fl, fr, rl, rr]):
            raise RuntimeError(
                "Wheel capture failed.\n"
                "Expected CTRL names containing AVG, AVD, ARG, ARD."
            )

        # ✅ Commit assignment
        wheel.front_left_path = fl
        wheel.front_right_path = fr
        wheel.rear_left_path = rl
        wheel.rear_right_path = rr

        # ✅ Cache last valid assignment
        wheel._last_valid_wheel_paths = (fl, fr, rl, rr)

        LOGGER.info(
            "Wheels captured by name: FL=%s FR=%s RL=%s RR=%s",
            fl, fr, rl, rr,
        )

        return wheel.summary()



    def prepare_for_scenario(self, *_):
        stage = omni.usd.get_context().get_stage()
        self._meters_per_unit = (
            float(UsdGeom.GetStageMetersPerUnit(stage)) if stage else 1.0
        )

        # Auto-compute wheel diameter once per scenario start.
        # Store it in millimeters because runtime_distance is also in mm.
        wheel = self._wheel_settings()
        auto_diameter_mm = self._compute_auto_wheel_diameter_mm()

        if auto_diameter_mm > self._DISTANCE_EPSILON:
            wheel.wheel_diameter = float(auto_diameter_mm)
            LOGGER.info(
                "Auto wheel diameter for vehicle %s = %.3f mm",
                self._vehicle_index,
                float(auto_diameter_mm),
            )
        else:
            # Fallback only if nothing valid could be computed
            current = float(getattr(wheel, "wheel_diameter", 0.0) or 0.0)
            if current <= self._DISTANCE_EPSILON:
                wheel.wheel_diameter = float(self._DEFAULT_WHEEL_DIAMETER_MM)
                LOGGER.warning(
                    "Falling back to default wheel diameter for vehicle %s: %.3f mm",
                    self._vehicle_index,
                    float(self._DEFAULT_WHEEL_DIAMETER_MM),
                )

        self._resolved_wheelbase = self._resolve_wheelbase()
        self._current_steer_angle_deg = 0.0
        self._model.runtime.current_front_steer_angle = 0.0


    def start(self):
        if self._update_subscription is None:
            self._update_subscription = (
                self._app.get_update_event_stream().create_subscription_to_pop(
                    self._on_update,
                    name=f"tracking_motion_path.wheel_sync.{self._vehicle_index}",
                )
            )
        self._enabled = True

    def stop(self):
        if not self._enabled:
            return
        self._enabled = False
        self._model.runtime.current_front_steer_angle = 0.0

    def shutdown(self):
        self.stop()

    # ------------------------------------------------------------------
    # Update loop (ONE system only)
    # ------------------------------------------------------------------

    def _on_update(self, _event):

       
        if not self._enabled or not self._timeline.is_playing():
            return

        wheel = self._wheel_settings()
        if not wheel.all_paths():
            cached = getattr(wheel, "_last_valid_wheel_paths", None)
            if cached:
                (
                    wheel.front_left_path,
                    wheel.front_right_path,
                    wheel.rear_left_path,
                    wheel.rear_right_path,
                ) = cached
            else:
                return


        runtime_distance_mm = float(
            getattr(self._model.runtime, "accumulated_distance", 0.0)
        )

        diameter_mm = max(
            float(getattr(wheel, "wheel_diameter", self._DEFAULT_WHEEL_DIAMETER_MM)),
            self._DISTANCE_EPSILON,
        )

        circumference_mm = math.pi * diameter_mm

        spin_angle_deg = (runtime_distance_mm / circumference_mm) * 360.0
        if wheel.invert_spin:
            spin_angle_deg *= -1.0

        steer_angle_deg = self._compute_steer_from_curve()
        
        self._model.runtime.current_front_steer_angle = float(steer_angle_deg)

        self._apply_visuals(
                spin_angle_deg=float(spin_angle_deg),
                steer_angle_deg=float(steer_angle_deg),
            )


        self._apply_visuals(
            spin_angle_deg=float(spin_angle_deg),
            steer_angle_deg=float(steer_angle_deg),
        )

    # ------------------------------------------------------------------
    # Steering solve (curve curvature)
    # ------------------------------------------------------------------

    def _compute_steer_from_curve(self) -> float:
        u = self._get_current_u_value()
        du = self._CURVE_SAMPLE_DU

        p0 = self._sample_curve_position(max(0.0, u - du))
        p1 = self._sample_curve_position(u)
        p2 = self._sample_curve_position(min(1.0, u + du))

        if not p0 or not p1 or not p2:
            return float(self._current_steer_angle_deg)

        x0, y0 = p0[0], p0[1]
        x1, y1 = p1[0], p1[1]
        x2, y2 = p2[0], p2[1]

        v0x, v0y = x1 - x0, y1 - y0
        v1x, v1y = x2 - x1, y2 - y1

        len0 = math.hypot(v0x, v0y)
        len1 = math.hypot(v1x, v1y)
        if len0 < self._POSITION_EPSILON or len1 < self._POSITION_EPSILON:
            return float(self._current_steer_angle_deg)

        h0 = math.atan2(v0y, v0x)
        h1 = math.atan2(v1y, v1x)

        dtheta = h1 - h0
        while dtheta > math.pi:
            dtheta -= 2 * math.pi
        while dtheta < -math.pi:
            dtheta += 2 * math.pi

        ds = 0.5 * (len0 + len1)
        curvature = dtheta / max(ds, self._POSITION_EPSILON)

        wheelbase = max(self._resolved_wheelbase, self._POSITION_EPSILON)
        raw_steer = math.degrees(math.atan(wheelbase * curvature))

       

        
        if abs(raw_steer) < 0.1:   # degrees
            raw_steer = 0.0


        gain = float(getattr(self._model, "steer_angle_gain", self._DEFAULT_STEER_GAIN))
        max_steer = float(
            getattr(self._model, "max_front_steer_deg", self._DEFAULT_MAX_STEER_DEG)
        )
        

        rise_response = float(getattr(self._model, "steer_rise_response", 0.30))
        fall_response = float(getattr(self._model, "steer_fall_response", 0.08))

        target = max(-max_steer, min(max_steer, raw_steer * gain))
        delta = target - self._current_steer_angle_deg

        if abs(target) > abs(self._current_steer_angle_deg):
            response = rise_response
        else:
            response = fall_response
        
      
            target = 0.0

        steer = self._current_steer_angle_deg + delta * response
        self._current_steer_angle_deg = float(steer)
        return float(steer)
    # ------------------------------------------------------------------
    # Visual application
    # ------------------------------------------------------------------

    def _apply_visuals(self, spin_angle_deg: float, steer_angle_deg: float):
        stage = omni.usd.get_context().get_stage()
        if not stage:
            return

        wheel = self._wheel_settings()

        front = {str(wheel.front_left_path), str(wheel.front_right_path)}
        rear = {str(wheel.rear_left_path), str(wheel.rear_right_path)}

        for path in wheel.all_paths():
            prim = stage.GetPrimAtPath(str(path))
            if not prim or not prim.IsValid():
                continue

            steer = steer_angle_deg if str(path) in front else 0.0

            self._set_visual_angles(
                prim=prim,
                spin_angle_deg=float(spin_angle_deg),
                steer_angle_deg=float(steer),
            )

    def _set_visual_angles(
        self,
        prim,
        spin_angle_deg: float,
        steer_angle_deg: float,
    ):
        xformable = UsdGeom.Xformable(prim)
        if not xformable:
            return

        steer_op = self._get_or_create_rotate_z_op(xformable)
        spin_op = self._get_or_create_spin_op(xformable)

        self._ensure_op_order(xformable, steer_op, spin_op)

        # ✅ ONLY set values here
        steer_op.Set(float(steer_angle_deg))
        spin_op.Set(float(spin_angle_deg))
        

    # ------------------------------------------------------------------
    # USD helpers
    # ------------------------------------------------------------------

    def _get_or_create_rotate_z_op(
        self,
        xformable: UsdGeom.Xformable,
    ):
        suffix = self._STEER_OP_SUFFIX
        desired_name = f"xformOp:rotateZ:{suffix}"

        for op in xformable.GetOrderedXformOps():
            if op.GetOpName() == desired_name:
                return op

        # Create once
        op = xformable.AddRotateZOp(
            precision=UsdGeom.XformOp.PrecisionFloat,
            opSuffix=suffix,
        )

        # ✅ Order once (append to end)
        ordered = list(xformable.GetOrderedXformOps())
        ordered.remove(op)
        ordered.append(op)
        xformable.SetXformOpOrder(ordered, resetXformStack=False)

        return op


    def _get_or_create_spin_op(
        self,
        xformable: UsdGeom.Xformable,
    ):
        axis = (self._wheel_settings().spin_axis or "Y").upper()
        suffix = self._SPIN_OP_SUFFIX

        # Try reuse
        for op in xformable.GetOrderedXformOps():
            if suffix in op.GetOpName():
                return op

        # Create once
        if axis == "X":
            op = xformable.AddRotateXOp(
                precision=UsdGeom.XformOp.PrecisionFloat,
                opSuffix=suffix,
            )
        elif axis == "Z":
            op = xformable.AddRotateZOp(
                precision=UsdGeom.XformOp.PrecisionFloat,
                opSuffix=suffix,
            )
        else:
            op = xformable.AddRotateYOp(
                precision=UsdGeom.XformOp.PrecisionFloat,
                opSuffix=suffix,
            )

        # ✅ Order once
        ordered = list(xformable.GetOrderedXformOps())
        ordered.remove(op)
        ordered.append(op)
        xformable.SetXformOpOrder(ordered, resetXformStack=False)

        return op


    def _ensure_op_order(self, xformable, steer_op, spin_op):
        ordered = [
            op for op in xformable.GetOrderedXformOps()
            if op.GetOpName() not in (steer_op.GetOpName(), spin_op.GetOpName())
        ]
        ordered.extend([steer_op, spin_op])
        xformable.SetXformOpOrder(ordered, resetXformStack=False)

    # ------------------------------------------------------------------
    # Geometry helpers
    # ------------------------------------------------------------------

    def _resolve_wheelbase(self) -> float:
        wheel = self._wheel_settings()
        fl = self._get_world_position(wheel.front_left_path)
        fr = self._get_world_position(wheel.front_right_path)
        rl = self._get_world_position(wheel.rear_left_path)
        rr = self._get_world_position(wheel.rear_right_path)

        if fl and fr and rl and rr:
            fx = 0.5 * (fl[0] + fr[0])
            fy = 0.5 * (fl[1] + fr[1])
            rx = 0.5 * (rl[0] + rr[0])
            ry = 0.5 * (rl[1] + rr[1])
            return math.hypot(fx - rx, fy - ry)

        return self._DEFAULT_WHEELBASE_MM


    def _get_world_position(self, prim_path: Optional[str]):
        if not prim_path:
            return None
        stage = omni.usd.get_context().get_stage()
        prim = stage.GetPrimAtPath(str(prim_path))
        if not prim or not prim.IsValid():
            return None
        xf = UsdGeom.XformCache(Usd.TimeCode.Default()).GetLocalToWorldTransform(prim)
        t = xf.ExtractTranslation()
        return (float(t[0]), float(t[1]), float(t[2]))

    # ------------------------------------------------------------------
    # Curve sampling (unchanged logic)
    # ------------------------------------------------------------------

    def _sample_curve_position(self, u: float):
        stage = omni.usd.get_context().get_stage()
        curve_path = getattr(self._model, "curve_path", None)
        if not stage or not curve_path:
            return None

        prim = stage.GetPrimAtPath(str(curve_path))
        if not prim or not prim.IsA(UsdGeom.BasisCurves):
            return None

        curve = UsdGeom.BasisCurves(prim)
        points = curve.GetPointsAttr().Get()
        counts = curve.GetCurveVertexCountsAttr().Get()
        if not points or not counts:
            return None

        xf = UsdGeom.XformCache(Usd.TimeCode.Default()).GetLocalToWorldTransform(prim)

        world = []
        idx = 0
        for c in counts:
            for p in points[idx : idx + c]:
                wp = xf.Transform((float(p[0]), float(p[1]), float(p[2])))
                world.append((float(wp[0]), float(wp[1]), float(wp[2])))
            idx += c

        if len(world) < 2:
            return None

        lengths = [0.0]
        for i in range(1, len(world)):
            dx = world[i][0] - world[i - 1][0]
            dy = world[i][1] - world[i - 1][1]
            dz = world[i][2] - world[i - 1][2]
            lengths.append(lengths[-1] + math.sqrt(dx * dx + dy * dy + dz * dz))

        total = lengths[-1]
        if total <= self._DISTANCE_EPSILON:
            return world[0]

        target = max(0.0, min(1.0, u)) * total
        for i in range(1, len(world)):
            if target <= lengths[i]:
                t = (target - lengths[i - 1]) / max(
                    lengths[i] - lengths[i - 1], self._DISTANCE_EPSILON
                )
                return (
                    world[i - 1][0] + (world[i][0] - world[i - 1][0]) * t,
                    world[i - 1][1] + (world[i][1] - world[i - 1][1]) * t,
                    world[i - 1][2] + (world[i][2] - world[i - 1][2]) * t,
                )

        return world[-1]


    def get_wheels_summary(self) -> str:
        """
        Return a human-readable summary of assigned wheels.
        Used by the UI only.
        """
        wheel = self._wheel_settings()
        if not wheel:
            return "No wheels assigned"
        return wheel.summary()
    




    def _compute_auto_wheel_diameter_mm(self) -> float:
        """
        Compute an approximate wheel diameter from the assigned wheel prims.

        Returns:
            Diameter in millimeters.
        """
        stage = omni.usd.get_context().get_stage()
        if not stage:
            return 0.0

        wheel = self._wheel_settings()
        candidate_paths = [
            wheel.front_left_path,
            wheel.front_right_path,
            wheel.rear_left_path,
            wheel.rear_right_path,
        ]

        diameters_mm = []

        for prim_path in candidate_paths:
            if not prim_path:
                continue

            prim = stage.GetPrimAtPath(str(prim_path))
            if not prim or not prim.IsValid():
                continue

            diameter_scene_units = self._compute_prim_wheel_diameter_scene_units(prim)
            if diameter_scene_units <= self._DISTANCE_EPSILON:
                continue

            # Convert scene units -> meters -> mm
            diameter_mm = float(diameter_scene_units) * float(self._meters_per_unit) * 1000.0
            if diameter_mm > self._DISTANCE_EPSILON:
                diameters_mm.append(float(diameter_mm))

        if not diameters_mm:
            return 0.0

        # Robust choice: median to reduce outliers from odd controls / asymmetry
        diameters_mm.sort()
        mid = len(diameters_mm) // 2
        if len(diameters_mm) % 2 == 1:
            return float(diameters_mm[mid])

        return float(0.5 * (diameters_mm[mid - 1] + diameters_mm[mid]))


    def _compute_prim_wheel_diameter_scene_units(self, root_prim) -> float:
            """
            Estimate wheel diameter in scene units from the wheel prim or its mesh descendants.

            Uses the two dimensions perpendicular to the spin axis, because the spin axis
            corresponds to the wheel axle, not the diameter.
            """
            bbox_cache = UsdGeom.BBoxCache(
                Usd.TimeCode.Default(),
                [UsdGeom.Tokens.default_, UsdGeom.Tokens.render, UsdGeom.Tokens.proxy],
                useExtentsHint=True,
            )

            # Prefer mesh descendants if present; otherwise fall back to the root prim.
            mesh_prims = []
            try:
                for prim in Usd.PrimRange(root_prim):
                    if prim and prim.IsValid() and prim.IsA(UsdGeom.Mesh):
                        mesh_prims.append(prim)
            except Exception:
                mesh_prims = []

            if mesh_prims:
                min_x = min_y = min_z = None
                max_x = max_y = max_z = None

                for prim in mesh_prims:
                    try:
                        bbox = bbox_cache.ComputeWorldBound(prim).ComputeAlignedBox()
                    except Exception:
                        continue

                    pmin = bbox.GetMin()
                    pmax = bbox.GetMax()

                    if min_x is None:
                        min_x, min_y, min_z = float(pmin[0]), float(pmin[1]), float(pmin[2])
                        max_x, max_y, max_z = float(pmax[0]), float(pmax[1]), float(pmax[2])
                    else:
                        min_x = min(min_x, float(pmin[0]))
                        min_y = min(min_y, float(pmin[1]))
                        min_z = min(min_z, float(pmin[2]))
                        max_x = max(max_x, float(pmax[0]))
                        max_y = max(max_y, float(pmax[1]))
                        max_z = max(max_z, float(pmax[2]))

                if min_x is None:
                    return 0.0

                size_x = max_x - min_x
                size_y = max_y - min_y
                size_z = max_z - min_z
            else:
                try:
                    bbox = bbox_cache.ComputeWorldBound(root_prim).ComputeAlignedBox()
                except Exception:
                    return 0.0

                pmin = bbox.GetMin()
                pmax = bbox.GetMax()

                size_x = float(pmax[0] - pmin[0])
                size_y = float(pmax[1] - pmin[1])
                size_z = float(pmax[2] - pmin[2])

            axis = (self._wheel_settings().spin_axis or "Y").upper()

            # Spin axis is the axle axis.
            # Diameter is measured across the perpendicular plane.
            if axis == "X":
                diameter = max(size_y, size_z)
            elif axis == "Y":
                diameter = max(size_x, size_z)
            else:  # axis == "Z"
                diameter = max(size_x, size_y)

            return float(max(diameter, 0.0))

    

    
    
    

    

   

    

