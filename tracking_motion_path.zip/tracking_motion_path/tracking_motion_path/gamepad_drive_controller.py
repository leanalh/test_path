import logging
import carb.input
import omni.appwindow

LOGGER = logging.getLogger("tracking_motion_path.gamepad_drive")


class GamepadDriveController:
    """
    Manual drive controller.

    Final mapping:
      - LEFT_STICK_UP    -> accelerate forward
      - LEFT_STICK_DOWN  -> accelerate backward while held
      - DPAD_DOWN        -> brake

    IMPORTANT:
    This controller does NOT own the real gamepad subscription anymore.
    The camera controller owns the subscription and forwards events here.
    """

    FORWARD_ACCEL_INPUTS = (
        carb.input.GamepadInput.LEFT_STICK_UP,
    )

    BRAKE_INPUTS = (
        carb.input.GamepadInput.DPAD_DOWN,
    )

    REVERSE_ACCEL_INPUTS = (
        carb.input.GamepadInput.LEFT_STICK_DOWN,
    )

    BUTTON_PRESS_THRESHOLD = 0.5
    STICK_DEADZONE = 0.15

    def __init__(self, model, speed_controller):
        self._model = model
        self._speed_controller = speed_controller

        self._app_window = omni.appwindow.get_default_app_window()
        self._input = carb.input.acquire_input_interface()

        self._gamepad = None
        self._gamepad_event_sub = None

        self._forward_stick_value = 0.0
        self._reverse_stick_value = 0.0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def startup(self):
        if self._app_window is None:
            LOGGER.warning("No app window available; manual drive mode will not respond to gamepad.")
            self._publish_status("No app window available — manual drive mode will not respond.")
            return

        try:
            self._gamepad = self._app_window.get_gamepad(0)
        except Exception:
            LOGGER.exception("Failed to acquire gamepad 0 for drive controller.")
            self._gamepad = None
            self._publish_status("Failed to acquire gamepad 0.")
            return

        if self._gamepad is None:
            LOGGER.warning("No gamepad 0 connected; manual drive will not move the car.")
            self._publish_status("No gamepad detected — manual drive mode will not move the car.")
            return

        # Shared subscription mode:
        # camera controller owns the real subscription and forwards here.
        LOGGER.warning("Gamepad drive controller ready (shared subscription mode).")

    def shutdown(self):
        self._gamepad = None
        self._gamepad_event_sub = None

    def has_gamepad(self) -> bool:
        return self._gamepad is not None

    # ------------------------------------------------------------------
    # Public event handler (called from camera controller)
    # ------------------------------------------------------------------
    def handle_gamepad_event(self, event: "carb.input.GamepadEvent"):
        try:
            if not self._is_manual_drive_active():
                return

            value = float(event.value)

            # ----------------------------------------------------------
            # Forward stick (LEFT_STICK_UP)
            # ----------------------------------------------------------
            if event.input in self.FORWARD_ACCEL_INPUTS:
                self._forward_stick_value = self._stick_value(value)
                self._apply_stick_drive_state()
                return

            # ----------------------------------------------------------
            # Reverse stick (LEFT_STICK_DOWN)
            # ----------------------------------------------------------
            if event.input in self.REVERSE_ACCEL_INPUTS:
                self._reverse_stick_value = self._stick_value(value)
                self._apply_stick_drive_state()
                return

            # ----------------------------------------------------------
            # Brake (DPAD_DOWN)
            # ----------------------------------------------------------
            if event.input in self.BRAKE_INPUTS:
                action_value = 1.0 if value > self.BUTTON_PRESS_THRESHOLD else 0.0

                self._speed_controller.set_throttle(0.0)
                self._speed_controller.set_brake(action_value)

                if action_value > 0.0:
                    self._publish_status("Braking")
                return

        except Exception:
            LOGGER.exception("Gamepad drive event handling failed.")

    # Optional backward-compatible alias
    def _on_gamepad_event(self, event):
        self.handle_gamepad_event(event)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _stick_value(self, raw_value: float) -> float:
        if raw_value < self.STICK_DEADZONE:
            return 0.0
        if raw_value > 1.0:
            return 1.0
        return raw_value

    def _is_manual_drive_active(self) -> bool:
        if str(getattr(self._model, "scenario_mode", "auto")).lower() != "manual":
            return False

        runtime = getattr(self._model, "runtime", None)
        if runtime is None:
            return False

        return bool(getattr(runtime, "scenario_running", False))

    def _publish_status(self, text: str) -> None:
        runtime = getattr(self._model, "runtime", None)
        if runtime is not None:
            runtime.status_text = text


    def _apply_stick_drive_state(self) -> None:
        """
        Resolve the current stick-based drive intent from the latest UP/DOWN values.

        This avoids the bug where Omniverse emits the opposite stick direction with
        value 0.0, which would otherwise clear reverse or forward incorrectly.
        """
        # Reverse wins if the down command is active
        if self._reverse_stick_value > 0.0:
            self._speed_controller.set_reverse(True)
            self._speed_controller.set_brake(0.0)
            self._speed_controller.set_throttle(self._reverse_stick_value)
            self._publish_status("Accelerating in reverse")
            return

        # Otherwise forward if the up command is active
        if self._forward_stick_value > 0.0:
            self._speed_controller.set_reverse(False)
            self._speed_controller.set_brake(0.0)
            self._speed_controller.set_throttle(self._forward_stick_value)
            self._publish_status("Accelerating forward")
            return

        # Neither direction is active
        self._speed_controller.set_throttle(0.0)
        self._speed_controller.set_reverse(False)