import carb
import logging
from typing import List, Optional
import bisect

import omni.graph.core as og
import omni.kit.app
import omni.usd
from pxr import Sdf, Usd, UsdGeom, Gf

LOGGER = logging.getLogger("tracking_motion_path.motion_path_adapter")


class MotionPathAdapter:
    
 

    GRAPH_PATH = "/World/TrackingMotionPathGraph"
    CURVE_CONST_NODE_NAME = "Curve_ConstantTarget"
    CURVE_READ_NODE_NAME = "Curve_ReadPrimsBundle"
    MOTION_PATH_NODE_NAME = "MotionPath"
    LIFT_MAKE_TRANSFORM_NODE_NAME = "Vehicle_LiftMakeTransform"
    MATRIX_MULTIPLY_NODE_NAME = "Vehicle_TransformMultiply"
    SET_XFORM_NODE_NAME = "Vehicle_SetXform"

    CURVE_CONST_NODE_TYPE = "omni.graph.nodes.ConstantTarget"
    CURVE_READ_NODE_TYPE = "omni.graph.nodes.ReadPrimsBundle"
    MOTION_PATH_NODE_TYPE = "omni.genproc.core.MotionPath"
    LIFT_MAKE_TRANSFORM_NODE_TYPE = "omni.graph.nodes.MakeTransform"
    MATRIX_MULTIPLY_NODE_TYPE = "omni.graph.nodes.MatrixMultiply"
    SET_XFORM_NODE_TYPE = "omni.anim.SetXform"

    AXIS_ENUM = {
        "+X": 0,
        "+Y": 1,
        "+Z": 2,
        "-X": 3,
        "-Y": 4,
    }

    def __init__(self, model, vehicle_index: int = 0):
        self._model = model
        self._vehicle_index = int(vehicle_index)
        self._model.ensure_vehicle_count(self._vehicle_index + 1)

        self._route_graph = None
        self._route_nodes = {}

        self._controller = og.Controller(update_usd=True, undoable=True)

        self._cached_u_attr = None
        self._cached_vehicle_offset_key = None
        self._cached_vehicle_offset_value = None
        self._original_vehicle_xform_snapshot = None
        self._snapshot_vehicle_path = None

        
        self._cached_route_length_mm = 0.0
        self._distance_samples_mm = []
        self._u_samples = []


    # ------------------------------------------------------------------
    # Per-vehicle model helpers
    # ------------------------------------------------------------------
    def _is_leader(self) -> bool:
        return self._vehicle_index == 0

    def _vehicle_state(self):
        return self._model.get_vehicle(self._vehicle_index)

    def _get_vehicle_rig_path(self) -> Optional[str]:
        vehicle = self._vehicle_state()
        return str(vehicle.rig_path) if vehicle.rig_path else None

    def _set_vehicle_rig_path(self, value: Optional[str]):
        value = str(value) if value else None
        if self._is_leader():
            self._model.vehicle_rig_path = value
        else:
            self._vehicle_state().rig_path = value

    def _get_graph_path(self) -> Optional[str]:
        vehicle = self._vehicle_state()
        return str(vehicle.graph_path) if vehicle.graph_path else None

    def _set_graph_path(self, value: Optional[str]):
        value = str(value) if value else None
        if self._is_leader():
            self._model.graph_path = value
        else:
            self._vehicle_state().graph_path = value

    def _get_motion_path_node_path(self) -> Optional[str]:
        vehicle = self._vehicle_state()
        return str(vehicle.motion_path_node_path) if vehicle.motion_path_node_path else None

    def _set_motion_path_node_path(self, value: Optional[str]):
        value = str(value) if value else None
        if self._is_leader():
            self._model.motion_path_node_path = value
        else:
            self._vehicle_state().motion_path_node_path = value

    def _get_u_attr_path(self) -> Optional[str]:
        vehicle = self._vehicle_state()
        return str(vehicle.u_attr_path) if vehicle.u_attr_path else None

    def _set_u_attr_path(self, value: Optional[str]):
        value = str(value) if value else None
        if self._is_leader():
            self._model.u_attr_path = value
        else:
            self._vehicle_state().u_attr_path = value

    def _graph_root_path(self) -> str:
        if self._is_leader():
            return self.GRAPH_PATH
        return f"{self.GRAPH_PATH}_{self._vehicle_index + 1}"

    # ------------------------------------------------------------------
    # Selection helpers
    # ------------------------------------------------------------------
    def get_selected_prim_paths(self) -> List[str]:
        try:
            return list(
                omni.usd.get_context().get_selection().get_selected_prim_paths()
            )
        except Exception as exc:
            LOGGER.exception("Failed to read USD selection: %s", exc)
            return []

    def get_selected_prim_path(self) -> str:
        selected = self.get_selected_prim_paths()
        return str(selected[0]) if selected else ""

    def capture_vehicle_from_selection(self) -> str:
        vehicle_path = self.get_selected_prim_path()
        if not vehicle_path:
            raise RuntimeError("Select the vehicle prim first.")

        vehicle_path = self._resolve_vehicle_xformable_path(vehicle_path)
        self._set_vehicle_rig_path(vehicle_path)

        vehicle = self._vehicle_state()
        vehicle.clear_motion_graph()

        self._cached_u_attr = None
        self._cached_vehicle_offset_key = None
        self._cached_vehicle_offset_value = None

        self._capture_original_vehicle_xform_snapshot()

        # ✅ Distance-driven reset (THIS adapter only)
        if self.has_valid_motion_path():
            self._controller.set(
                f"{self._motion_path_node_path()}.inputs:uValue",
                u_value
            )
            self.evaluate_graph_now()

        self._model.runtime.status_text = (
            f"{vehicle.name} captured: {vehicle_path}"
            if getattr(vehicle, "name", None)
            else f"Vehicle captured: {vehicle_path}"
        )

        return str(vehicle_path)
    

  

    
 

    def capture_curve_from_selection(self) -> str:
        curve_path = self.get_selected_prim_path()
        if not curve_path:
            raise RuntimeError("Select the curve prim first.")

        # Resolve and validate
        curve_path = self._resolve_basis_curves_prim_path(curve_path)
        self._validate_curve_prim(curve_path)
        self._ensure_curve_wrap_authored(curve_path)

        stage = omni.usd.get_context().get_stage()
        curve_prim = stage.GetPrimAtPath(curve_path)
        if not curve_prim or not curve_prim.IsValid():
            raise RuntimeError(f"Invalid curve prim: {curve_path}")

    

        # Optional: explicitly mark curve as NOT reversed (informational only)
        curve_prim.CreateAttribute(
            "tracking:curveReversed",
            Sdf.ValueTypeNames.Bool,
        ).Set(False)

        # Store curve path
        self._model.curve_path = str(curve_path)

        self._model.runtime.status_text = (
            f"Curve captured: {curve_path}"
        )

        return str(curve_path)

    


    
    def clear_vehicle(self):
        vehicle = self._vehicle_state()
        vehicle.rig_path = None
        vehicle.clear_motion_graph()
        self._cached_u_attr = None
        self._cached_vehicle_offset_key = None
        self._cached_vehicle_offset_value = None
        self._original_vehicle_xform_snapshot = None
        self._snapshot_vehicle_path = None

    def clear_curve(self):
        self._model.curve_path = None
        self._cached_u_attr = None

    # ------------------------------------------------------------------
    # Public graph API
    # ------------------------------------------------------------------
    def apply_motion_path(self):
        """
        Build / update the per-vehicle Motion Path graph and snap the vehicle to U=0.
        """
        self._ensure_required_runtime_extensions()

        vehicle_path = self._get_vehicle_rig_path()
        if not vehicle_path:
            raise RuntimeError("Capture the vehicle first.")
        if not self._model.curve_path:
            raise RuntimeError("Capture the curve first.")

        vehicle_path = self._resolve_vehicle_xformable_path(vehicle_path)
        curve_path = self._resolve_basis_curves_prim_path(self._model.curve_path)
        self._validate_curve_prim(curve_path)
        self._ensure_curve_wrap_authored(curve_path)

        self._set_vehicle_rig_path(vehicle_path)
        self._model.curve_path = curve_path

        self._capture_original_vehicle_xform_snapshot()
        self._ensure_graph()
        self._ensure_nodes()
        self._configure_curve_source()
        self._resolve_vehicle_orientation()
        self._configure_set_xform_target_relationship()

        self._model.vehicle_path_height_offset = 0.0

        self._configure_lift_transform()
        self._connect_graph()
        self._cache_paths()
        self._cached_u_attr = None

        graph_path = self._get_graph_path() or self._graph_root_path()

        # Warm-up
        og.Controller.evaluate_sync(graph_path)

        
            

        motion_path_node = f"{self._graph_root_path()}/{self.MOTION_PATH_NODE_NAME}"

        points = self._controller.get(
            f"{self._adaptive_sampler_node_path()}.outputs:points"
        )
        u_values = self._controller.get(
            f"{self._adaptive_sampler_node_path()}.outputs:uValues"
        )

        # Build distance LUT
        self._distance_samples_mm = [0.0]
        for i in range(1, len(points)):
            p0 = Gf.Vec3d(*map(float, points[i-1]))
            p1 = Gf.Vec3d(*map(float, points[i]))
            self._distance_samples_mm.append(
                self._distance_samples_mm[-1] + (p1 - p0).GetLength()
            )

        self._u_samples = list(u_values)
        self._cached_route_length_mm = self._distance_samples_mm[-1]

        
        # Initialize motion at start
        self._controller.set(
            f"{motion_path_node}.inputs:uValue",
            0.0
        )

        vehicle = self._vehicle_state()

        # ✅ Detect axis once
        if not hasattr(vehicle, "forward_axis"):
            vehicle.forward_axis = self.detect_local_forward_axis()

        axis = vehicle.forward_axis

        # ✅ ALWAYS apply axis to MotionPath
        self._controller.set(
            f"{motion_path_node}.inputs:forwardAxis",
            int(self.AXIS_ENUM[axis]),
        )
        self._controller.set(
            f"{motion_path_node}.inputs:upAxis",
            int(self.AXIS_ENUM["+Z"]),
        )
        self._controller.set(
            f"{motion_path_node}.inputs:worldUpType",
            1,
        )
        self._controller.set(
            f"{motion_path_node}.inputs:worldUpVector",
            (0.0, 0.0, 1.0),
        )

        self.evaluate_graph_now()

        LOGGER.info(
            "MotionPath applied for %s (axis=%s, u=0)",
            vehicle.name,
            axis,
        )

        self._model.runtime.status_text = (
            f"Motion Path graph created for {vehicle.name} and snapped to start."
        )
    def resolve_u_attr_path(self) -> str:
        cached = self._get_u_attr_path()
        if cached:
            return cached

        motion_path_node_path = self._get_motion_path_node_path()
        if not motion_path_node_path:
            raise RuntimeError("Motion Path graph has not been created yet.")

        attr_path = f"{motion_path_node_path}.inputs:uValue"
        self._set_u_attr_path(attr_path)
        return str(attr_path)

    def get_motion_path_u_attr_path(
        self,
        selected_prim_path: Optional[str] = None,
    ) -> str:
        if selected_prim_path:
            self._set_vehicle_rig_path(str(selected_prim_path))
        return self.resolve_u_attr_path()

    def has_valid_motion_path(self) -> bool:
        try:
            if not self._get_vehicle_rig_path() or not self._model.curve_path:
                return False
            attr = self._get_u_attr(required=False)
            return bool(attr and attr.IsValid())
        except Exception:
            return False

    # ------------------------------------------------------------------
    # U-value API
    # ------------------------------------------------------------------
    def get_u_value(self) -> float:
        """
        Public API returns raw Motion Path uValue in [0..1].
        No LUT remapping.
        """
        attr = self._get_u_attr(required=False)
        if not attr:
            return 0.0

        try:
            value = attr.Get()
            value = 0.0 if value is None else float(value)
        except Exception:
            value = 0.0

        value = max(0.0, min(1.0, value))

        if self._is_leader():
            self._model.runtime.current_u_value = value

        return value

    def set_u_value(self, u: float):
        """
        The ONLY way to write MotionPath.inputs:uValue.
        """
        u = float(max(0.0, min(1.0, u)))
        self._controller.set(
            f"{self._motion_path_node_path()}.inputs:uValue",
            u,
        )

        if self._is_leader():
            self._model.runtime.current_u_value = u

    def snap_to_u(self, value: float = 0.0):
        """
        Force the Motion Path graph to evaluate immediately at the requested U.
        """
        if not self.has_valid_motion_path():
            raise RuntimeError("Motion Path graph has not been created yet.")

        value = max(0.0, min(1.0, float(value)))
        graph_path = self._get_graph_path() or self._graph_root_path()

        og.Controller.evaluate_sync(graph_path)

        epsilon = 1e-6
        dirty_value = epsilon if abs(value) < epsilon else max(0.0, value - epsilon)

        self.set_u_value(dirty_value)
        og.Controller.evaluate_sync(graph_path)

        self.set_u_value(value)
        og.Controller.evaluate_sync(graph_path)

        if self._is_leader():
            self._model.runtime.current_u_value = value

    def reset_motion_to_start(self):
        """
        Reset only the motion-path-driven pose back to the start of the curve.
        This does NOT remove the graph.
        """
        self.snap_to_u(0.0)
        if self._is_leader():
            self._model.runtime.current_u_value = 0.0

    # ------------------------------------------------------------------
    # Runtime refresh
    # ------------------------------------------------------------------
    def refresh_vehicle_transform_state(self):
        """
        Refresh transform-dependent settings without rebuilding the graph.
        Useful if scale / lift-related conditions changed.
        """
        if not self.has_valid_motion_path():
            return

        vehicle_path = self._get_vehicle_rig_path()
        if not vehicle_path:
            raise RuntimeError("No captured vehicle prim is available.")

        self._set_vehicle_rig_path(self._resolve_vehicle_xformable_path(vehicle_path))
        self._cached_vehicle_offset_key = None
        self._cached_vehicle_offset_value = None
        self._configure_lift_transform()

    # ------------------------------------------------------------------
    # Cleanup / full reset
    # ------------------------------------------------------------------
    def remove_motion_path_graph(self) -> int:
        stage = omni.usd.get_context().get_stage()
        vehicle = self._vehicle_state()

        if not stage:
            vehicle.clear_motion_graph()
            if self._is_leader():
                self._set_graph_path(None)
                self._set_motion_path_node_path(None)
                self._set_u_attr_path(None)
            self._cached_u_attr = None
            return 0

        graph_path = self._get_graph_path() or self._graph_root_path()
        prim = stage.GetPrimAtPath(str(graph_path))
        removed = 0
        if prim and prim.IsValid():
            stage.RemovePrim(str(graph_path))
            removed = 1

        vehicle.clear_motion_graph()
        if self._is_leader():
            self._set_graph_path(None)
            self._set_motion_path_node_path(None)
            self._set_u_attr_path(None)
        self._cached_u_attr = None
        return removed

    def reset_extension_state(self):
        try:
            if self.has_valid_motion_path():
                try:
                    self.reset_motion_to_start()
                except Exception:
                    LOGGER.debug(
                        "Could not reset U to 0 before graph removal.",
                        exc_info=True,
                    )

            self.remove_motion_path_graph()
            self._restore_original_vehicle_xform_snapshot()

        finally:
            # Clear only the adapter/model bookkeeping.
            # Do NOT clear xform ops here.
            self.clear_vehicle()

    # ------------------------------------------------------------------
    # Internal graph creation
    # ------------------------------------------------------------------
    def _ensure_required_runtime_extensions(self):
        app = omni.kit.app.get_app()
        ext_mgr = app.get_extension_manager()

        required = [
            "omni.graph.nodes",        
            "omni.genproc.core",     
            "omni.anim.shared.core",
        ]

        for ext_name in required:
            if not ext_mgr.is_extension_enabled(ext_name):
                LOGGER.info("Enabling extension: %s", ext_name)
                ext_mgr.set_extension_enabled(ext_name, True)

    def _ensure_graph(self):
        graph_path = self._graph_root_path()
        if self._safe_graph_exists(graph_path):
            self._set_graph_path(graph_path)
            return
        self._controller.create_graph(graph_path, evaluator_name="push")
        self._set_graph_path(graph_path)

    def _ensure_nodes(self):
        if not self._safe_node_exists(self._curve_const_node_path()):
            self._controller.create_node(
                self._curve_const_node_path(),
                self.CURVE_CONST_NODE_TYPE,
            )

        if not self._safe_node_exists(self._curve_read_node_path()):
            self._controller.create_node(
                self._curve_read_node_path(),
                self.CURVE_READ_NODE_TYPE,
            )

        # ✅ GetCurveData (built‑in, supported)
        if not self._safe_node_exists(self._adaptive_sampler_node_path()):
            self._controller.create_node(
                self._adaptive_sampler_node_path(),
                "omni.genproc.core.GetCurveData",
            )

            # Configure sampling quality
            self._controller.set(
                f"{self._adaptive_sampler_node_path()}.inputs:samplesPerSegment",
                64,
            )

       

        if not self._safe_node_exists(self._motion_path_node_path()):
            self._controller.create_node(
                self._motion_path_node_path(),
                self.MOTION_PATH_NODE_TYPE,
            )

        if not self._safe_node_exists(self._lift_make_transform_node_path()):
            self._controller.create_node(
                self._lift_make_transform_node_path(),
                self.LIFT_MAKE_TRANSFORM_NODE_TYPE,
            )

        if not self._safe_node_exists(self._matrix_multiply_node_path()):
            self._controller.create_node(
                self._matrix_multiply_node_path(),
                self.MATRIX_MULTIPLY_NODE_TYPE,
            )

        if not self._safe_node_exists(self._set_xform_node_path()):
            self._controller.create_node(
                self._set_xform_node_path(),
                self.SET_XFORM_NODE_TYPE,
            )

    # ------------------------------------------------------------------
    # Graph configuration
    # ------------------------------------------------------------------
    def _configure_curve_source(self):
        self._controller.set(
            f"{self._curve_const_node_path()}.inputs:value",
            [self._model.curve_path],
        )
        self._controller.set(
            f"{self._curve_read_node_path()}.inputs:usePaths",
            False,
        )
        self._controller.set(
            f"{self._curve_read_node_path()}.inputs:attrNamesToImport",
            "points curveVertexCounts basis wrap type widths normals",
        )

    def _configure_motion_path_orientation(self):
        motion_path = self._motion_path_node_path()
        
        vehicle = self._vehicle_state()
        forward_axis = getattr(vehicle, "forward_axis", self._model.vehicle_forward_axis)


        self._controller.set(
            f"{motion_path}.inputs:forwardAxis",
            int(self.AXIS_ENUM[forward_axis]),
        )
        self._controller.set(f"{motion_path}.inputs:upAxis", 2)
        LOGGER.info(
            "Configuring MotionPath for %s with forward axis: %s",
            vehicle.name,
            forward_axis,
        )

        try:
            self._controller.set(f"{motion_path}.inputs:worldUpType", 0)
        except Exception:
            LOGGER.debug("Failed to set worldUpType.", exc_info=True)

    def _configure_set_xform_target_relationship(self):
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        node_prim = stage.GetPrimAtPath(self._set_xform_node_path())
        if not node_prim or not node_prim.IsValid():
            raise RuntimeError(
                f"Invalid SetXform node prim: {self._set_xform_node_path()}"
            )

        vehicle_path = self._get_vehicle_rig_path()
        if not vehicle_path:
            raise RuntimeError("No captured vehicle prim is available.")

        rel = node_prim.GetRelationship("inputs:prim")
        if not rel:
            rel = node_prim.CreateRelationship("inputs:prim", custom=False)
        rel.SetTargets([Sdf.Path(vehicle_path)])

    def _configure_lift_transform(self):
        manual_value = getattr(self._model, "vehicle_path_height_offset", None)
        if manual_value is None:
            lift_value = self._get_cached_or_compute_auto_vehicle_offset()
        else:
            lift_value = float(manual_value)

        vehicle_scale = self._get_vehicle_local_scale()
        self._controller.set(
            f"{self._lift_make_transform_node_path()}.inputs:translation",
            [0.0, 0.0, float(lift_value)],
        )
        self._controller.set(
            f"{self._lift_make_transform_node_path()}.inputs:rotationXYZ",
            [0.0, 0.0, 0.0],
        )
        self._controller.set(
            f"{self._lift_make_transform_node_path()}.inputs:scale",
            vehicle_scale,
        )

    

    def _connect_graph(self):
        # --- Disconnect everything first ---
        self._disconnect_if_present(f"{self._curve_read_node_path()}.inputs:prims")
        self._disconnect_if_present(
            f"{self._motion_path_node_path()}.inputs:curveBundle"
        )
        self._disconnect_if_present(
            f"{self._motion_path_node_path()}.inputs:uValue"
        )

        self._disconnect_if_present(f"{self._matrix_multiply_node_path()}.inputs:a")
        self._disconnect_if_present(f"{self._matrix_multiply_node_path()}.inputs:b")
        self._disconnect_if_present(
            f"{self._set_xform_node_path()}.inputs:transform"
        )

        # --- Curve → Read ---
        self._controller.connect(
            f"{self._curve_const_node_path()}.inputs:value",
            f"{self._curve_read_node_path()}.inputs:prims",
        )

        # ✅ Read → GetCurveData (CORRECT PORT)
        self._controller.connect(
            f"{self._curve_read_node_path()}.outputs_primsBundle",
            f"{self._adaptive_sampler_node_path()}.inputs:curvesBundle",
        )

        # --- Read → MotionPath ---
        self._controller.connect(
            f"{self._curve_read_node_path()}.outputs_primsBundle",
            f"{self._motion_path_node_path()}.inputs:curveBundle",
        )

        # --- MotionPath → transform chain ---
        self._controller.connect(
            f"{self._lift_make_transform_node_path()}.outputs:transform",
            f"{self._matrix_multiply_node_path()}.inputs:a",
        )
        self._controller.connect(
            f"{self._motion_path_node_path()}.outputs:transform",
            f"{self._matrix_multiply_node_path()}.inputs:b",
        )
        self._controller.connect(
            f"{self._matrix_multiply_node_path()}.outputs:output",
            f"{self._set_xform_node_path()}.inputs:transform",
        )

    def _cache_paths(self):
        graph_path = self._graph_root_path()
        motion_path_node_path = self._motion_path_node_path()
        vehicle = self._vehicle_state()

        self._set_graph_path(graph_path)
        vehicle.read_prims_node_path = self._curve_read_node_path()
        self._set_motion_path_node_path(motion_path_node_path)
        vehicle.set_xform_node_path = self._set_xform_node_path()
        

    # ------------------------------------------------------------------
    # Prim / curve resolution
    # ------------------------------------------------------------------
    def _resolve_vehicle_xformable_path(self, selected_path: str) -> str:
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        prim = stage.GetPrimAtPath(selected_path)
        if not prim or not prim.IsValid():
            raise RuntimeError(f"Invalid vehicle prim: {selected_path}")

        if UsdGeom.Xformable(prim):
            return str(prim.GetPath())

        for child in Usd.PrimRange(prim):
            if child and child.IsValid() and UsdGeom.Xformable(child):
                return str(child.GetPath())

        raise RuntimeError(
            "Selected vehicle prim is not xformable and does not contain an "
            "xformable descendant."
        )

    def _resolve_basis_curves_prim_path(self, selected_path: str) -> str:
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        prim = stage.GetPrimAtPath(selected_path)
        if not prim or not prim.IsValid():
            raise RuntimeError(f"Invalid curve prim: {selected_path}")

        if prim.IsA(UsdGeom.BasisCurves):
            return str(prim.GetPath())

        candidates = []
        for child in Usd.PrimRange(prim):
            if child and child.IsValid() and child.IsA(UsdGeom.BasisCurves):
                candidates.append(child)

        if len(candidates) == 1:
            return str(candidates[0].GetPath())
        if len(candidates) == 0:
            raise RuntimeError(
                "Selected prim is not a BasisCurves prim and does not contain one."
            )
        raise RuntimeError(
            "Selected prim contains multiple BasisCurves descendants. "
            "Please select the exact curve prim."
        )

    def _validate_curve_prim(self, curve_path: str):
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        prim = stage.GetPrimAtPath(curve_path)
        if not prim or not prim.IsValid():
            raise RuntimeError(f"Invalid curve prim: {curve_path}")
        if not prim.IsA(UsdGeom.BasisCurves):
            raise RuntimeError(f"Prim is not a BasisCurves prim: {curve_path}")

        curve = UsdGeom.BasisCurves(prim)
        points = curve.GetPointsAttr().Get()
        counts = curve.GetCurveVertexCountsAttr().Get()
        if not points or len(points) < 2:
            raise RuntimeError("Curve must contain at least 2 authored points.")
        if not counts or len(counts) < 1:
            raise RuntimeError("Curve is missing curveVertexCounts.")
        if int(counts[0]) < 2:
            raise RuntimeError(
                "Curve must have at least 2 vertices in its first segment."
            )
        if int(counts[0]) > len(points):
            raise RuntimeError(
                f"curveVertexCounts[0]={int(counts[0])} exceeds available "
                f"point count={len(points)}."
            )

    def _ensure_curve_wrap_authored(self, curve_path: str):
        """
        Ensure 'wrap' is explicitly authored as 'nonperiodic' because the
        MotionPath node is sensitive to authored curve wrap state.
        """
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        prim = stage.GetPrimAtPath(curve_path)
        if not prim or not prim.IsValid():
            raise RuntimeError(f"Invalid curve prim: {curve_path}")
        if not prim.IsA(UsdGeom.BasisCurves):
            raise RuntimeError(f"Prim is not BasisCurves: {curve_path}")

        curve = UsdGeom.BasisCurves(prim)
        authored_names = {prop.GetName() for prop in prim.GetAuthoredProperties()}
        wrap_attr = curve.GetWrapAttr()
        wrap_value = wrap_attr.Get() if wrap_attr else None

        if "wrap" not in authored_names or wrap_value != "nonperiodic":
            wrap_attr = curve.CreateWrapAttr()
            wrap_attr.Set("nonperiodic")

    # ------------------------------------------------------------------
    # U-attribute access
    # ------------------------------------------------------------------
    def _get_u_attr(self, required: bool = False):
        if self._cached_u_attr and self._cached_u_attr.IsValid():
            return self._cached_u_attr

        stage = omni.usd.get_context().get_stage()
        if not stage:
            if required:
                raise RuntimeError("No USD stage is open.")
            return None

        attr_path = self.resolve_u_attr_path()
        attr = stage.GetAttributeAtPath(Sdf.Path(attr_path))
        if attr and attr.IsValid():
            self._cached_u_attr = attr
            return attr

        self._cached_u_attr = None
        if required:
            raise RuntimeError(f"Invalid Motion Path U-value path: {attr_path}")
        return None

    # ------------------------------------------------------------------
    # Orientation / lift helpers
    # ------------------------------------------------------------------
    def _resolve_vehicle_orientation(self):
        self._model.vehicle_up_axis = "Z"
        if not self._model.vehicle_forward_axis:
            self._model.vehicle_forward_axis = "+X"
        if getattr(self._model, "vehicle_forward_sign", 1) not in (-1, 1):
            self._model.vehicle_forward_sign = 1

    def _get_vehicle_local_scale(self) -> list[float]:
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        vehicle_path = self._get_vehicle_rig_path()
        if not vehicle_path:
            raise RuntimeError("No captured vehicle prim is available.")

        prim = stage.GetPrimAtPath(str(vehicle_path))
        if not prim or not prim.IsValid():
            raise RuntimeError(f"Invalid vehicle prim: {vehicle_path}")

        xformable = UsdGeom.Xformable(prim)
        if not xformable:
            return [1.0, 1.0, 1.0]

        scale_value = None
        for op in xformable.GetOrderedXformOps():
            try:
                if op.GetOpType() == UsdGeom.XformOp.TypeScale:
                    value = op.Get()
                    if value is not None:
                        scale_value = value
            except Exception:
                LOGGER.debug("Failed reading vehicle scale op.", exc_info=True)

        if scale_value is None:
            return [1.0, 1.0, 1.0]

        return [
            float(scale_value[0]),
            float(scale_value[1]),
            float(scale_value[2]),
        ]

    def _compute_bbox_based_vehicle_offset(self) -> float:
        """
        Legacy fallback:
        Compute a positive Z lift so the vehicle's lowest visible point sits on the
        path plane, using world bounds.
        """
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        vehicle_path = self._get_vehicle_rig_path()
        vehicle_prim = stage.GetPrimAtPath(str(vehicle_path))
        if not vehicle_prim or not vehicle_prim.IsValid():
            raise RuntimeError(f"Invalid vehicle prim: {vehicle_path}")

        bbox_cache = UsdGeom.BBoxCache(
            Usd.TimeCode.Default(),
            [UsdGeom.Tokens.default_, UsdGeom.Tokens.render, UsdGeom.Tokens.proxy],
            useExtentsHint=False,
        )
        world_bbox = bbox_cache.ComputeWorldBound(vehicle_prim).ComputeAlignedBox()
        min_pt = world_bbox.GetMin()

        xform_cache = UsdGeom.XformCache(Usd.TimeCode.Default())
        world_mtx = xform_cache.GetLocalToWorldTransform(vehicle_prim)
        world_origin = world_mtx.ExtractTranslation()

        lowest_world_z = float(min_pt[2])
        origin_world_z = float(world_origin[2])

        extra_clearance = float(
            getattr(self._model, "vehicle_ground_clearance_extra", 0.0)
        )

        return max(0.0, origin_world_z - lowest_world_z + extra_clearance)

    def _compute_auto_vehicle_offset(self) -> float:
        """
        Preferred behavior:
        If a vehicle-local ground reference prim exists (for example 'ground_ref'),
        compute the Z lift from that prim's transform relative to the driven vehicle
        root.

        Z-up convention:
            offset_z = -ground_ref_z_in_vehicle_root_space + extra_clearance

        Fallback:
            If no ground-ref prim is found, use the legacy bbox-based method.
        """
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        vehicle_path = self._get_vehicle_rig_path()
        vehicle_prim = stage.GetPrimAtPath(str(vehicle_path))
        if not vehicle_prim or not vehicle_prim.IsValid():
            raise RuntimeError(f"Invalid vehicle prim: {vehicle_path}")

        ground_ref_prim = self._find_ground_ref_prim()
        if not ground_ref_prim or not ground_ref_prim.IsValid():
            return self._compute_bbox_based_vehicle_offset()

        extra_clearance = float(
            getattr(self._model, "vehicle_ground_clearance_extra", 0.0)
        )

        xform_cache = UsdGeom.XformCache(Usd.TimeCode.Default())

        try:
            root_to_ref_mtx, _ = xform_cache.ComputeRelativeTransform(
                ground_ref_prim,
                vehicle_prim,
            )
        except TypeError:
            reset_xform_stack = False
            root_to_ref_mtx = xform_cache.ComputeRelativeTransform(
                ground_ref_prim,
                vehicle_prim,
                reset_xform_stack,
            )

        ref_rel_translation = root_to_ref_mtx.ExtractTranslation()
        offset_z = -float(ref_rel_translation[2]) + extra_clearance
        return offset_z

    def _get_cached_or_compute_auto_vehicle_offset(self) -> float:
        vehicle_path = self._get_vehicle_rig_path()
        extra_clearance = float(
            getattr(self._model, "vehicle_ground_clearance_extra", 0.0)
        )
        vehicle_scale = tuple(self._get_vehicle_local_scale())
        cache_key = (
            str(vehicle_path),
            extra_clearance,
            vehicle_scale,
        )

        if (
            self._cached_vehicle_offset_key == cache_key
            and self._cached_vehicle_offset_value is not None
        ):
            return float(self._cached_vehicle_offset_value)

        value = float(self._compute_auto_vehicle_offset())
        self._cached_vehicle_offset_key = cache_key
        self._cached_vehicle_offset_value = value
        return value

    # ------------------------------------------------------------------
    # Original transform snapshot / restore
    # ------------------------------------------------------------------
    def _capture_original_vehicle_xform_snapshot(self):
        """
        Capture the vehicle's original ordered xform ops and values once.
        """
        stage = omni.usd.get_context().get_stage()
        if not stage:
            return

        vehicle_path = self._get_vehicle_rig_path()
        if not vehicle_path:
            return

        vehicle_path = str(vehicle_path)
        if (
            self._original_vehicle_xform_snapshot is not None
            and self._snapshot_vehicle_path == vehicle_path
        ):
            return

        prim = stage.GetPrimAtPath(vehicle_path)
        if not prim or not prim.IsValid():
            return

        xformable = UsdGeom.Xformable(prim)
        if not xformable:
            return

        snapshot_ops = []
        for op in xformable.GetOrderedXformOps():
            try:
                snapshot_ops.append(
                    {
                        "name": op.GetOpName(),
                        "value": op.Get(),
                    }
                )
            except Exception:
                LOGGER.debug("Failed to snapshot vehicle xform op.", exc_info=True)

        self._original_vehicle_xform_snapshot = {
            "vehicle_path": vehicle_path,
            "reset_xform_stack": bool(xformable.GetResetXformStack()),
            "ops": snapshot_ops,
        }
        self._snapshot_vehicle_path = vehicle_path

    def _store_snapshot_on_vehicle_prim(self):
        stage = omni.usd.get_context().get_stage()
        if not stage:
            return
        snapshot = self._original_vehicle_xform_snapshot
        vehicle_path = self._get_vehicle_rig_path()
        if not snapshot or not vehicle_path:
            return

        prim = stage.GetPrimAtPath(str(vehicle_path))
        if not prim or not prim.IsValid():
            return

        prim.SetCustomDataByKey("trackingMotionPath:originalXformSnapshot", snapshot)

    def _restore_original_vehicle_xform_snapshot(self):
        """
        Restore the vehicle's original ordered xform ops and values.
        Also removes any extra ops not present in the snapshot.
        """
        snapshot = self._original_vehicle_xform_snapshot
        if not snapshot:
            return

        stage = omni.usd.get_context().get_stage()
        if not stage:
            return

        vehicle_path = snapshot.get("vehicle_path")
        prim = stage.GetPrimAtPath(str(vehicle_path))
        if not prim or not prim.IsValid():
            return

        xformable = UsdGeom.Xformable(prim)
        if not xformable:
            return

        current_ops = list(xformable.GetOrderedXformOps())
        current_ops_by_name = {}
        for op in current_ops:
            try:
                current_ops_by_name[op.GetOpName()] = op
            except Exception:
                pass

        restored_order = []
        snapshot_names = set()
        for op_info in snapshot.get("ops", []):
            name = op_info["name"]
            snapshot_names.add(name)
            op = current_ops_by_name.get(name)
            if op is None:
                LOGGER.warning("Original xform op missing during restore: %s", name)
                continue
            try:
                op.Set(op_info["value"])
                restored_order.append(op)
            except Exception:
                LOGGER.debug("Failed restoring op %s", name, exc_info=True)

        for op in current_ops:
            try:
                op_name = op.GetOpName()
            except Exception:
                continue
            if op_name not in snapshot_names:
                try:
                    prim.RemoveProperty(op_name)
                except Exception:
                    LOGGER.debug("Failed removing extra op %s", op_name, exc_info=True)

        try:
            xformable.SetXformOpOrder(
                restored_order,
                snapshot.get("reset_xform_stack", False),
            )
        except Exception:
            LOGGER.debug("Failed restoring xform op order.", exc_info=True)

    # ------------------------------------------------------------------
    # Misc graph helpers
    # ------------------------------------------------------------------
    def _curve_const_node_path(self) -> str:
        return f"{self._graph_root_path()}/{self.CURVE_CONST_NODE_NAME}"

    def _curve_read_node_path(self) -> str:
        return f"{self._graph_root_path()}/{self.CURVE_READ_NODE_NAME}"

    def _motion_path_node_path(self) -> str:
        return f"{self._graph_root_path()}/{self.MOTION_PATH_NODE_NAME}"

    def _lift_make_transform_node_path(self) -> str:
        return f"{self._graph_root_path()}/{self.LIFT_MAKE_TRANSFORM_NODE_NAME}"

    def _matrix_multiply_node_path(self) -> str:
        return f"{self._graph_root_path()}/{self.MATRIX_MULTIPLY_NODE_NAME}"

    def _set_xform_node_path(self) -> str:
        return f"{self._graph_root_path()}/{self.SET_XFORM_NODE_NAME}"

    def _safe_graph_exists(self, graph_path: str) -> bool:
        try:
            return bool(self._controller.graph(graph_path))
        except Exception:
            return False

    def _safe_node_exists(self, node_path: str) -> bool:
        try:
            return bool(self._controller.node(node_path))
        except Exception:
            return False

    def _disconnect_if_present(self, attr_path: str):
        try:
            attr = self._controller.attribute(attr_path)
            if attr:
                self._controller.disconnect_all(attr_path)
        except Exception:
            pass

    def get_graph_path_for_evaluation(self) -> str:
        """
        Return the graph path used by this vehicle's motion path graph.
        """
        return self._get_graph_path() or self._graph_root_path()

    def evaluate_graph_now(self):
        """
        Force this adapter's graph to evaluate immediately.
        """
        if not self.has_valid_motion_path():
            raise RuntimeError("Motion Path graph has not been created yet.")

        og.Controller.evaluate_sync(self.get_graph_path_for_evaluation())

    def _find_ground_ref_prim(self):
        stage = omni.usd.get_context().get_stage()
        if not stage:
            raise RuntimeError("No USD stage is open.")

        vehicle_path = self._get_vehicle_rig_path()
        if not vehicle_path:
            raise RuntimeError("No captured vehicle prim is available.")

        vehicle_prim = stage.GetPrimAtPath(str(vehicle_path))
        if not vehicle_prim or not vehicle_prim.IsValid():
            raise RuntimeError(f"Invalid vehicle prim: {vehicle_path}")

        # Optional explicit path from model
        explicit_ref_path = getattr(self._model, "vehicle_ground_ref_path", None)
        if explicit_ref_path:
            ref_prim = stage.GetPrimAtPath(str(explicit_ref_path))
            if ref_prim and ref_prim.IsValid():
                return ref_prim

        # Convention-based lookup
        ref_name = getattr(self._model, "vehicle_ground_ref_name", "ground_ref")
        for prim in Usd.PrimRange(vehicle_prim):
            if prim and prim.IsValid() and prim.GetName() == ref_name and UsdGeom.Xformable(prim):
                return prim

        return None



    def update_forward_axis(self, forward_axis: str):
        """
        Non-destructive forward axis update.
        Forces orientation to update immediately by re-evaluating
        the graph at a meaningful U.
        """
        if forward_axis not in self.AXIS_ENUM:
            raise ValueError(f"Invalid forward axis: {forward_axis}")

        motion_path_node = self._motion_path_node_path()
        u_attr = f"{motion_path_node}.inputs:uValue"

        try:
            # 1) Update forward axis
            self._controller.set(
                f"{motion_path_node}.inputs:forwardAxis",
                int(self.AXIS_ENUM[forward_axis]),
            )

            # 2) Read U and IMMEDIATELY convert to Python float
            raw_u = self._controller.get(u_attr)
            try:
                current_u = float(raw_u)
            except (TypeError, ValueError):
                current_u = 0.0

            # 3) Force MotionPath evaluation
            if abs(current_u) < 1e-6:
                # Nudge U to force evaluation at start
                nudge_u = 1e-4
                self._controller.set(u_attr, float(nudge_u))
                self.evaluate_graph_now()
                self._controller.set(u_attr, 0.0)
            else:
                # Normal case: reapply current U
                self._controller.set(u_attr, float(current_u))
                self.evaluate_graph_now()

        except Exception:
            LOGGER.exception(
                "Failed updating forward axis for vehicle %s",
                self._vehicle_index,
            )

    def get_current_u_value(self):
        try:
            motion_path_node_path = f"{self._graph_root_path()}/{self.MOTION_PATH_NODE_NAME}"
            return self._controller.get(
                f"{motion_path_node_path}.inputs:uValue"
            )
        except Exception:
            return None




    def _get_path_tangent_world(self) -> Gf.Vec3d | None:
        """
        Return a stable world-space tangent of the motion path.
        Uses the first segment of the curve, transformed to world space.
        """
        stage = omni.usd.get_context().get_stage()
        if not stage or not self._model.curve_path:
            return None

        curve_prim = stage.GetPrimAtPath(self._model.curve_path)
        if not curve_prim or not curve_prim.IsA(UsdGeom.BasisCurves):
            return None

        curve = UsdGeom.BasisCurves(curve_prim)
        points = curve.GetPointsAttr().Get()
        if not points or len(points) < 2:
            return None

        # Transform curve points to world space
        xf_cache = UsdGeom.XformCache(Usd.TimeCode.Default())
        xf = xf_cache.GetLocalToWorldTransform(curve_prim)

        p0 = xf.Transform(Gf.Vec3d(points[0]))
        p1 = xf.Transform(Gf.Vec3d(points[1]))

        tangent = p1 - p0
        if tangent.GetLength() < 1e-6:
            return None

        return tangent.GetNormalized()

   



    def detect_local_forward_axis(self) -> str:
        stage = omni.usd.get_context().get_stage()
        root = stage.GetPrimAtPath(self._get_vehicle_rig_path())
        if not root:
            return "+X"

        bbox_cache = UsdGeom.BBoxCache(
            Usd.TimeCode.Default(),
            [UsdGeom.Tokens.default_],
            useExtentsHint=True,
        )

        combined_min = None
        combined_max = None

        for prim in Usd.PrimRange(root):
            if not prim.IsA(UsdGeom.Mesh):
                continue

            # ✅ WORLD-space bound (important)
            bbox = bbox_cache.ComputeWorldBound(prim)
            rng = bbox.GetRange()
            if rng.IsEmpty():
                continue

            if combined_min is None:
                combined_min = rng.GetMin()
                combined_max = rng.GetMax()
            else:
                combined_min = Gf.Vec3d(
                    min(combined_min[0], rng.GetMin()[0]),
                    min(combined_min[1], rng.GetMin()[1]),
                    min(combined_min[2], rng.GetMin()[2]),
                )
                combined_max = Gf.Vec3d(
                    max(combined_max[0], rng.GetMax()[0]),
                    max(combined_max[1], rng.GetMax()[1]),
                    max(combined_max[2], rng.GetMax()[2]),
                )

        # ✅ Guard: no meshes found
        if combined_min is None or combined_max is None:
            LOGGER.warning(
                "No mesh bounds found for vehicle %s, defaulting to +X",
                root.GetPath(),
            )
            return "+X"

        size_x = abs(combined_max[0] - combined_min[0])
        size_y = abs(combined_max[1] - combined_min[1])

        LOGGER.info(
            "Aggregated vehicle bbox %s: sizeX=%.2f sizeY=%.2f",
            root.GetPath(),
            size_x,
            size_y,
        )

        if size_x > size_y * 1.1:
            return "+X"
        elif size_y > size_x * 1.1:
            return "+Y"
        else:
            return "+X"

    


    
    def _is_curve_reversed(points) -> bool:
        """
        Decide whether the curve runs 'backwards' in world space.
        This heuristic can be tuned later if needed.
        """
        p0 = Gf.Vec3d(points[0])
        p1 = Gf.Vec3d(points[-1])

        direction = p1 - p0
        if direction.GetLength() < 1e-6:
            return False

        # Example heuristic: road generally increases in X or Y
        dominant = max(abs(direction[0]), abs(direction[1]))
        if abs(direction[0]) == dominant:
            return direction[0] < 0
        else:
            return direction[1] < 0
        

        

    
    def _normalize_curve_direction(self, curve_path: str) -> bool:
        """
        Safely normalize curve direction.
        Returns True if curve was reversed.
        """
        stage = omni.usd.get_context().get_stage()
        curve_prim = stage.GetPrimAtPath(curve_path)
        if not curve_prim or not curve_prim.IsA(UsdGeom.BasisCurves):
            return False

        curve = UsdGeom.BasisCurves(curve_prim)
        points = curve.GetPointsAttr().Get()
        if not points or len(points) < 2:
            return False

        p0 = Gf.Vec3d(points[0])
        p1 = Gf.Vec3d(points[-1])
        direction = p1 - p0
        if direction.GetLength() < 1e-6:
            return False

        # Heuristic: dominant world axis
        if abs(direction[0]) >= abs(direction[1]):
            reverse_curve = direction[0] < 0
        else:
            reverse_curve = direction[1] < 0

        if not reverse_curve:
            return False

        # ✅ SAFE USD CHANGE BLOCK
        with Usd.EditContext(stage, stage.GetSessionLayer()):
            curve.GetPointsAttr().Set(list(reversed(points)))

            curve_prim.CreateAttribute(
                "tracking:curveReversed",
                Sdf.ValueTypeNames.Bool,
            ).Set(True)

        return True


   
    

    def update_actor_motion(
        self,
        actor,
        route,
        distance_node,
        dt: float,
    ):
        # Advance distance in mm
        actor.distance_mm += actor.speed_mm_per_s * dt

        # Clamp
        actor.distance_mm = max(0.0, actor.distance_mm)

        total_len = route["sampler"].outputs.total_length_mm

        # Direction handling (NO curve reversal)
        if actor.direction > 0:
            effective_distance = actor.distance_mm
        else:
            effective_distance = max(0.0, total_len - actor.distance_mm)

        # Feed OmniGraph
        distance_node.inputs.distance_mm = effective_distance


    def _adaptive_sampler_node_path(self):
        return f"{self._graph_root_path()}/adaptive_sampler"




    def _ensure_vehicle_motion_state(self):
        vehicle = self._vehicle_state()

        # Distance along route (mm)
        if not hasattr(vehicle, "distance_mm"):
            vehicle.distance_mm = 0.0

        # Direction: +1 forward, -1 reverse
        if not hasattr(vehicle, "direction"):
            vehicle.direction = 1

        # Speed (mm/s) – use what you already have if it exists
        if not hasattr(vehicle, "speed_mm_per_s"):
            vehicle.speed_mm_per_s = 0.0

        return vehicle
    


    def update_motion(self, dt: float):
        vehicle = self._ensure_vehicle_motion_state()

        vehicle.distance_mm += vehicle.speed_mm_per_s * dt
        vehicle.distance_mm = max(0.0, vehicle.distance_mm)

        if vehicle.direction > 0:
            effective_distance = vehicle.distance_mm
        else:
            effective_distance = (
                self._cached_route_length_mm - vehicle.distance_mm
            )

        u = self._distance_to_u(effective_distance)

        self._controller.set(
            f"{self._motion_path_node_path()}.inputs:uValue",
            float(u)
        )


    def _distance_to_u(self, distance_mm: float) -> float:
   
        d = max(0.0, min(distance_mm, self._cached_route_length_mm))
        i = bisect.bisect_right(self._distance_samples_mm, d) - 1

        if i <= 0:
            return self._u_samples[0]
        if i >= len(self._u_samples) - 1:
            return self._u_samples[-1]

        d0 = self._distance_samples_mm[i]
        d1 = self._distance_samples_mm[i + 1]
        u0 = self._u_samples[i]
        u1 = self._u_samples[i + 1]

        t = (d - d0) / max(d1 - d0, 1e-6)
        return u0 + t * (u1 - u0)
    
    def distance_to_u(self, distance_mm: float) -> float:
        """
        Public wrapper for distance → U conversion.
        """
        return self._distance_to_u(distance_mm)

    def get_total_distance_mm(self) -> float:
        """
        Total curve length in millimeters, derived from the LUT.
        """
        if not hasattr(self, "_distance_samples_mm") or not self._distance_samples_mm:
            return 0.0
        return float(self._distance_samples_mm[-1])
   
