from __future__ import annotations

import bisect
import csv
import logging
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

LOGGER = logging.getLogger("tracking_motion_path.trajectory_importer")


@dataclass
class TrajectoryImportResult:
    times_s: List[float] = field(default_factory=list)

    # Raw imported positions in meters
    positions_m: List[Tuple[float, float, float]] = field(default_factory=list)

    # Playback-ready positions in stage units
    positions_stage: List[Tuple[float, float, float]] = field(default_factory=list)

    # (pitch, roll, yaw) in degrees
    rotations_deg: List[Tuple[float, float, float]] = field(default_factory=list)

    translation_units: Dict[str, str] = field(default_factory=dict)
    orientation_units: Dict[str, str] = field(default_factory=dict)

    source_row_count_translation: int = 0
    source_row_count_orientation: int = 0

    warnings: List[str] = field(default_factory=list)

    @property
    def duration_s(self) -> float:
        if not self.times_s:
            return 0.0
        return float(self.times_s[-1] - self.times_s[0])

    @property
    def sample_count(self) -> int:
        return len(self.times_s)

    def is_valid(self) -> bool:
        n = len(self.times_s)
        return (
            n >= 2
            and len(self.positions_m) == n
            and len(self.positions_stage) == n
            and len(self.rotations_deg) == n
        )

    def to_model_payload(self) -> dict:
        return {
            "trajectory_times_s": list(self.times_s),
            "trajectory_positions_m": list(self.positions_m),
            "trajectory_positions_stage": list(self.positions_stage),
            "trajectory_rotations_deg": list(self.rotations_deg),
            "trajectory_duration_s": float(self.duration_s),
            "trajectory_loaded": bool(self.is_valid()),
        }


class TrajectoryImporter:
    """
    No-pandas importer for recorded trajectory files.

    Supported formats:
      - .csv
      - .xls   (requires xlrd)
      - .xlsx  (requires openpyxl)

    Expected file shape (matches your uploaded CarMaker exports):
      - row 0: normal headers
      - row 1: marker row like C1
      - row 2: units row
      - row 3+: numeric samples
    """

    TRANSLATION_COLUMN_ALIASES = {
        "time": ("Time", "time", "t"),
        "tx": ("Car.Road.tx", "tx", "x", "pos_x"),
        "ty": ("Car.Road.ty", "ty", "y", "pos_y"),
        "tz": ("Car.Road.tz", "tz", "z", "pos_z"),
    }

    ORIENTATION_COLUMN_ALIASES = {
        "time": ("Time", "time", "t"),
        "pitch": ("Car.Pitch", "pitch", "Pitch"),
        "roll": ("Car.Roll", "roll", "Roll"),
        "yaw": ("Car.Yaw", "yaw", "Yaw", "heading"),
    }

    def load_recorded_pose(
        self,
        translation_file: str,
        orientation_file: str,
        *,
        translation_sheet: int | str = 0,
        orientation_sheet: int | str = 0,
        time_tolerance_s: float = 0.006,
        meters_per_unit: Optional[float] = None,
        axis_remap: Optional[dict] = None,
        translation_offset_xyz: Tuple[float, float, float] = (0.0, 0.0, 0.0),
        rotation_offset_xyz: Tuple[float, float, float] = (0.0, 0.0, 0.0),
        drop_duplicate_times: bool = True,
        drop_repeated_tail_samples: bool = True,
        unwrap_yaw: bool = True,
    ) -> TrajectoryImportResult:
        result = TrajectoryImportResult()

        translation_rows, translation_units = self._read_pose_rows(
            path=translation_file,
            sheet=translation_sheet,
            alias_map=self.TRANSLATION_COLUMN_ALIASES,
            required_keys=("time", "tx", "ty", "tz"),
        )
        orientation_rows, orientation_units = self._read_pose_rows(
            path=orientation_file,
            sheet=orientation_sheet,
            alias_map=self.ORIENTATION_COLUMN_ALIASES,
            required_keys=("time", "pitch", "roll", "yaw"),
        )

        result.translation_units = translation_units
        result.orientation_units = orientation_units
        result.source_row_count_translation = len(translation_rows)
        result.source_row_count_orientation = len(orientation_rows)

        if drop_duplicate_times:
            translation_rows = self._drop_duplicate_times(translation_rows)
            orientation_rows = self._drop_duplicate_times(orientation_rows)

        translation_rows.sort(key=lambda r: r["time"])
        orientation_rows.sort(key=lambda r: r["time"])

        merged_rows = self._merge_pose_rows_by_time(
            translation_rows=translation_rows,
            orientation_rows=orientation_rows,
            tolerance_s=float(time_tolerance_s),
            warnings=result.warnings,
        )

        if len(merged_rows) < 2:
            raise RuntimeError("Merged trajectory is empty or too short after time alignment.")

        if unwrap_yaw:
            self._unwrap_yaw_in_place(merged_rows)

        self._apply_axis_remap_and_offsets_in_place(
            merged_rows,
            axis_remap=axis_remap or {},
            translation_offset_xyz=translation_offset_xyz,
            rotation_offset_xyz=rotation_offset_xyz,
        )

        if drop_repeated_tail_samples:
            merged_rows = self._drop_repeated_tail_samples(merged_rows)

        if len(merged_rows) < 2:
            raise RuntimeError("Trajectory became too short after cleanup.")

        if meters_per_unit is None:
            mpu = None
        else:
            mpu = float(meters_per_unit)
            if mpu <= 0.0:
                raise ValueError(f"Invalid meters_per_unit: {meters_per_unit}")

        times_s: List[float] = []
        positions_m: List[Tuple[float, float, float]] = []
        positions_stage: List[Tuple[float, float, float]] = []
        rotations_deg: List[Tuple[float, float, float]] = []

        for row in merged_rows:
            t = float(row["time"])
            pos_m = (float(row["tx"]), float(row["ty"]), float(row["tz"]))
            rot_deg = (
                float(row["pitch"]),
                float(row["roll"]),
                float(row["yaw"]),
            )

            if mpu is None:
                pos_stage = pos_m
            else:
                pos_stage = (
                    pos_m[0] / mpu,
                    pos_m[1] / mpu,
                    pos_m[2] / mpu,
                )

            times_s.append(t)
            positions_m.append(pos_m)
            positions_stage.append(pos_stage)
            rotations_deg.append(rot_deg)

        # Monotonicity check
        for i in range(1, len(times_s)):
            if times_s[i] < times_s[i - 1]:
                raise RuntimeError("Imported trajectory timestamps are not monotonic.")

        result.times_s = times_s
        result.positions_m = positions_m
        result.positions_stage = positions_stage
        result.rotations_deg = rotations_deg

        return result

    # ------------------------------------------------------------------
    # File readers
    # ------------------------------------------------------------------

    def _read_pose_rows(
        self,
        *,
        path: str,
        sheet: int | str,
        alias_map: dict,
        required_keys: Sequence[str],
    ) -> Tuple[List[dict], Dict[str, str]]:
        raw_table = self._read_raw_table(path=path, sheet=sheet)
        if not raw_table or len(raw_table) < 2:
            raise RuntimeError(f"Input file is empty or malformed: {path}")

        headers = [str(h).strip() for h in raw_table[0]]
        if not headers:
            raise RuntimeError(f"Could not read headers from file: {path}")

        units: Dict[str, str] = {}
        if len(raw_table) >= 3:
            unit_row = raw_table[2]
            for i, header in enumerate(headers):
                if i < len(unit_row):
                    text = str(unit_row[i]).strip()
                    if text:
                        units[header] = text

        source_columns = {}
        for canonical_name, aliases in alias_map.items():
            source_col = self._find_source_column(headers, aliases)
            if source_col is None and canonical_name in required_keys:
                raise RuntimeError(
                    f"Missing required column '{canonical_name}' in '{path}'. "
                    f"Accepted names: {aliases}"
                )
            source_columns[canonical_name] = source_col

        rows: List[dict] = []

        # Numeric data starts after:
        # row 0 = headers
        # row 1 = C1 markers
        # row 2 = units
        for raw_row in raw_table[3:]:
            if not raw_row:
                continue

            parsed = {}
            valid = True

            for canonical_name in required_keys:
                source_col = source_columns.get(canonical_name)
                if source_col is None:
                    valid = False
                    break

                idx = headers.index(source_col)
                if idx >= len(raw_row):
                    valid = False
                    break

                value = self._to_float(raw_row[idx])
                if value is None:
                    valid = False
                    break

                parsed[canonical_name] = value

            if valid:
                rows.append(parsed)

        if not rows:
            raise RuntimeError(f"No valid numeric samples found in: {path}")

        return rows, units

    def _read_raw_table(self, *, path: str, sheet: int | str = 0) -> List[List[object]]:
        file_path = Path(path)
        if not file_path.exists():
            raise FileNotFoundError(f"Trajectory file not found: {path}")

        suffix = file_path.suffix.lower()

        if suffix == ".csv":
            return self._read_csv_table(file_path)

        if suffix == ".xls":
            return self._read_xls_table(file_path, sheet)

        if suffix == ".xlsx":
            return self._read_xlsx_table(file_path, sheet)

        raise RuntimeError(f"Unsupported trajectory file format '{suffix}' for file: {path}")

    def _read_csv_table(self, path: Path) -> List[List[object]]:
        rows: List[List[object]] = []
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            for row in reader:
                rows.append(list(row))
        return rows

    def _read_xls_table(self, path: Path, sheet: int | str) -> List[List[object]]:
        try:
            import xlrd
        except Exception as exc:
            raise RuntimeError(
                "Reading .xls trajectory files requires 'xlrd' in the Kit environment."
            ) from exc

        book = xlrd.open_workbook(str(path))
        if isinstance(sheet, int):
            ws = book.sheet_by_index(sheet)
        else:
            ws = book.sheet_by_name(str(sheet))

        rows: List[List[object]] = []
        for r in range(ws.nrows):
            rows.append(ws.row_values(r))
        return rows

    def _read_xlsx_table(self, path: Path, sheet: int | str) -> List[List[object]]:
        try:
            import openpyxl
        except Exception as exc:
            raise RuntimeError(
                "Reading .xlsx trajectory files requires 'openpyxl' in the Kit environment."
            ) from exc

        wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
        if isinstance(sheet, int):
            ws = wb[wb.sheetnames[sheet]]
        else:
            ws = wb[str(sheet)]

        rows: List[List[object]] = []
        for row in ws.iter_rows(values_only=True):
            rows.append(list(row))
        return rows

    # ------------------------------------------------------------------
    # Merge / cleanup
    # ------------------------------------------------------------------

    def _drop_duplicate_times(self, rows: List[dict]) -> List[dict]:
        out: List[dict] = []
        seen = set()
        for row in rows:
            t = float(row["time"])
            if t in seen:
                continue
            seen.add(t)
            out.append(row)
        return out

    def _merge_pose_rows_by_time(
        self,
        *,
        translation_rows: List[dict],
        orientation_rows: List[dict],
        tolerance_s: float,
        warnings: List[str],
    ) -> List[dict]:
        if not translation_rows or not orientation_rows:
            return []

        orientation_times = [float(r["time"]) for r in orientation_rows]
        merged: List[dict] = []
        unmatched = 0

        for trow in translation_rows:
            t = float(trow["time"])
            idx = bisect.bisect_left(orientation_times, t)

            candidates = []
            if idx < len(orientation_rows):
                candidates.append(orientation_rows[idx])
            if idx > 0:
                candidates.append(orientation_rows[idx - 1])

            best = None
            best_dt = None

            for orow in candidates:
                dt = abs(float(orow["time"]) - t)
                if best is None or dt < best_dt:
                    best = orow
                    best_dt = dt

            if best is None or best_dt is None or best_dt > tolerance_s:
                unmatched += 1
                continue

            merged.append(
                {
                    "time": t,
                    "tx": float(trow["tx"]),
                    "ty": float(trow["ty"]),
                    "tz": float(trow["tz"]),
                    "pitch": float(best["pitch"]),
                    "roll": float(best["roll"]),
                    "yaw": float(best["yaw"]),
                }
            )

        if unmatched > 0:
            warnings.append(
                f"{unmatched} translation samples were not matched to orientation "
                f"within {tolerance_s:.6f}s."
            )

        return merged

    def _unwrap_yaw_in_place(self, rows: List[dict]) -> None:
        if not rows:
            return

        prev = float(rows[0]["yaw"])
        rows[0]["yaw"] = prev

        for i in range(1, len(rows)):
            current = float(rows[i]["yaw"])
            delta = current - prev

            while delta > 180.0:
                current -= 360.0
                delta = current - prev

            while delta < -180.0:
                current += 360.0
                delta = current - prev

            rows[i]["yaw"] = current
            prev = current

    def _drop_repeated_tail_samples(self, rows: List[dict]) -> List[dict]:
        if len(rows) < 2:
            return rows

        trimmed = list(rows)
        while len(trimmed) >= 2 and self._same_pose_row(trimmed[-1], trimmed[-2]):
            trimmed.pop()

        return trimmed

    def _same_pose_row(self, a: dict, b: dict) -> bool:
        keys = ("time", "tx", "ty", "tz", "pitch", "roll", "yaw")
        for key in keys:
            if not math.isclose(float(a[key]), float(b[key]), rel_tol=0.0, abs_tol=1e-12):
                return False
        return True

    # ------------------------------------------------------------------
    # Axis remap / offsets
    # ------------------------------------------------------------------

    def _apply_axis_remap_and_offsets_in_place(
        self,
        rows: List[dict],
        *,
        axis_remap: dict,
        translation_offset_xyz: Tuple[float, float, float],
        rotation_offset_xyz: Tuple[float, float, float],
    ) -> None:
        t_order = tuple(axis_remap.get("translation_order", (0, 1, 2)))
        t_sign = tuple(axis_remap.get("translation_sign", (1.0, 1.0, 1.0)))

        r_order = tuple(axis_remap.get("rotation_order", (0, 1, 2)))
        r_sign = tuple(axis_remap.get("rotation_sign", (1.0, 1.0, 1.0)))

        if len(t_order) != 3 or len(t_sign) != 3:
            raise ValueError("translation_order and translation_sign must each contain 3 values")
        if len(r_order) != 3 or len(r_sign) != 3:
            raise ValueError("rotation_order and rotation_sign must each contain 3 values")

        t_offset = tuple(float(v) for v in translation_offset_xyz)
        r_offset = tuple(float(v) for v in rotation_offset_xyz)

        for row in rows:
            pos = [float(row["tx"]), float(row["ty"]), float(row["tz"])]
            rot = [float(row["pitch"]), float(row["roll"]), float(row["yaw"])]

            pos = [
                pos[t_order[0]] * float(t_sign[0]) + t_offset[0],
                pos[t_order[1]] * float(t_sign[1]) + t_offset[1],
                pos[t_order[2]] * float(t_sign[2]) + t_offset[2],
            ]

            rot = [
                rot[r_order[0]] * float(r_sign[0]) + r_offset[0],
                rot[r_order[1]] * float(r_sign[1]) + r_offset[1],
                rot[r_order[2]] * float(r_sign[2]) + r_offset[2],
            ]

            row["tx"], row["ty"], row["tz"] = pos
            row["pitch"], row["roll"], row["yaw"] = rot

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _find_source_column(
        self,
        headers: Sequence[str],
        aliases: Sequence[str],
    ) -> Optional[str]:
        header_list = [str(h).strip() for h in headers]
        alias_list = [str(a).strip() for a in aliases]

        # Exact match first
        for alias in alias_list:
            if alias in header_list:
                return alias

        # Case-insensitive second
        lowered = {h.lower(): h for h in header_list}
        for alias in alias_list:
            hit = lowered.get(alias.lower())
            if hit is not None:
                return hit

        return None

    def _to_float(self, value) -> Optional[float]:
        if value is None:
            return None

        if isinstance(value, (int, float)):
            try:
                return float(value)
            except Exception:
                return None

        text = str(value).strip()
        if not text:
            return None

        try:
            return float(text)
        except Exception:
            return None