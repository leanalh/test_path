import logging
from typing import Optional, Callable
import os

import omni.kit.app
import omni.ui as ui
import omni.usd
from omni.ui import color as cl
import omni.kit.window.filepicker as filepicker


LOGGER = logging.getLogger("tracking_motion_path.ui")

# -----------------------------------------------------------------------------
# Layout constants
# -----------------------------------------------------------------------------
LABEL_WIDTH = 120
FIELD_WIDTH = 280
BUTTON_WIDTH = 150
ROW_HEIGHT = 24
GROUP_SPACING = 4

STYLE = {
    "Window": {
        "background_color": cl("#1F1F1F"),
    },
    "ScrollingFrame": {
        "background_color": cl("#1F1F1F"),
        "secondary_color": cl("#444444"),
        "scrollbar_size": 6,
    },
    "Label": {
        "color": cl("#C8C8C8"),
        "font_size": 16,
    },
    "Label::attribute_name": {
        "color": cl("#C8C8C8"),
        "font_size": 14,
    },
    "Label::muted": {
        "color": cl("#9C9C9C"),
        "font_size": 14,
    },
    "Label::group_title": {
        "color": cl("#D0D0D0"),
        "font_size": 16,
    },
    "Label::header_title": {
        "color": cl("#D0D0D0"),
        "font_size": 18,
    },
    "Button": {
        "background_color": cl("#243782"),
        "border_radius": 4,
        "border_width": 0,
        "padding": 4,
        "margin": 0,
    },
    "Button.Label": {
        "color": cl("#C8C8C8"),
        "font_size": 14,
    },
    "Button:hovered": {
        "background_color": cl("#2E469D"),
    },
    "Button:pressed": {
        "background_color": cl("#1B2A63"),
    },
    "Field": {
        "color": cl("#E0E0E0"),
        "background_color": cl("#2C2C2C"),
        "background_selected_color": cl("#2E2E2E"),
        "padding": 4,
        "font_size": 14,
    },
    "Field:hovered": {
        "background_color": cl("#383838"),
    },
    "Field:pressed": {
        "background_color": cl("#2E2E2E"),
    },
    "IntField": {
        "color": cl("#E0E0E0"),
        "background_color": cl("#444444"),
        "padding": 4,
        "font_size": 14,
    },
    "FloatField": {
        "color": cl("#E0E0E0"),
        "background_color": cl("#444444"),
        "padding": 4,
        "font_size": 14,
    },
    "ComboBox": {
        "color": cl("#C8C8C8"),
        "background_color": cl("#2C2C2C"),
        "secondary_color": cl("#383838"),
        "selected_color": cl("#444444"),
        "secondary_selected_color": cl("#C8C8C8"),
        "padding": 4,
        "font_size": 14,
    },
    "ComboBox:hovered": {
        "background_color": cl("#2C2C2C"),
    },
    "CollapsableFrame": {
        "background_color": cl("#252525"),
        "secondary_color": cl("#2C2C2C"),
        "border_color": cl("#3A3A3A"),
        "border_radius": 4,
        "padding": 8,
        "margin": 0,
    },
    "CollapsableFrame:hovered": {
        "secondary_color": cl("#333333"),
    },
    "CollapsableFrame.Header": {
        "color": cl("#D0D0D0"),
        "font_size": 14,
    },
    "TopBar": {
        "background_color": cl("#2C2C2C"),
    },
    "SectionBody": {
        "background_color": cl("#252525"),
    },
    "InfoBlock": {
        "background_color": cl("#2C2C2C"),
        "border_radius": 2,
    },
    "Divider": {
        "background_color": cl("#3A3A3A"),
    },
}

VIDEO_OUTPUT_PROFILES = {
    0: {
        "label": "720p / 24fps",
        "width": 1280,
        "height": 720,
        "fps": 24,
    },
    1: {
        "label": "720p / 60fps",
        "width": 1280,
        "height": 720,
        "fps": 60,
    },
    2: {
        "label": "1080p / 24fps",
        "width": 1920,
        "height": 1080,
        "fps": 24,
    },
    3: {
        "label": "1080p / 60fps",
        "width": 1920,
        "height": 1080,
        "fps": 60,
    },
}


RENDER_PRESET_KEYS = [
    "default_realtime",
    "default_pathtracing",
    "custom",
]

RENDER_PRESET_LABELS = {
    "default_realtime": "Default Real-Time",
    "default_pathtracing": "Default Path Tracing",
    "custom": "Custom USD Preset",
}

VIDEO_CAPTURE_FILE_TYPE = ".mp4"


class TrackingMotionPathWindow:
    """
    Compact Omniverse UI for:
    - capturing vehicle(s), curve, wheels, steering wheel
    - building motion path graph(s)
    - configuring playback and cameras
    - driving a convoy scenario
    """

    def __init__(
        self,
        title: str,
        width: int,
        height: int,
        model,
        motion_path_adapters,
        ensure_adapters_match_model_fn: Callable,
        scenario_controller,
        wheel_sync_controllers,
        driver_camera_controller,
        steering_wheel_controller,
        movie_capture_controller=None,
        extension=None,
        
        on_record_movie=None,
        on_pause_movie=None,
        on_stop_movie=None,
        on_open_movie_capture_advanced=None,

    ):
        self._model = model
        self._adapters = motion_path_adapters
        self._ensure_adapters_match_model = ensure_adapters_match_model_fn
        self._scenario = scenario_controller
        self._wheel_sync_controllers = wheel_sync_controllers
        self._driver_camera = driver_camera_controller
        self._steering_wheel = steering_wheel_controller
        self._movie_capture_controller = movie_capture_controller
        self._title = title
        self._extension = extension


        self._on_open_movie_capture_advanced_fn = on_open_movie_capture_advanced
 
        self._on_record_movie_fn = on_record_movie
        self._on_pause_movie_fn = on_pause_movie
        self._on_stop_movie_fn = on_stop_movie


        # Movie capture UI subscriptions
        self._movie_capture_output_sub = None
        self._movie_capture_name_sub = None
        
        self._movie_capture_resolution_sub = None
        self._movie_capture_render_preset_sub = None

        self._movie_capture_start_seconds_sub = None
        self._movie_capture_end_seconds_sub = None

        # Movie capture UI models (wired directly to AppModel)
        self._movie_capture_output_model = ui.SimpleStringModel(
            str(getattr(self._model, "movie_capture_output_dir", "") or "")
        )
        self._movie_capture_name_model = ui.SimpleStringModel(
            str(getattr(self._model, "movie_capture_file_name", "tracking_motion_path") or "tracking_motion_path")
        )
        self._movie_capture_start_seconds_model = ui.SimpleFloatModel(
            float(getattr(self._model, "movie_capture_start_seconds", 0.0) or 0.0)
        )
        self._movie_capture_end_seconds_model = ui.SimpleFloatModel(
            float(getattr(self._model, "movie_capture_end_seconds", 10.0) or 10.0)
        )

        if not hasattr(self._model, "movie_capture_render_preset"):
            self._model.movie_capture_render_preset = "default_realtime"

        if not hasattr(self._model, "movie_capture_user_render_preset_path"):
            self._model.movie_capture_user_render_preset_path = ""

        self._movie_capture_user_preset_model = ui.SimpleStringModel(
            str(getattr(self._model, "movie_capture_user_render_preset_path", "") or "")
        )

        self._movie_capture_resolution_items = [
            VIDEO_OUTPUT_PROFILES[index]["label"]
            for index in sorted(VIDEO_OUTPUT_PROFILES.keys())
        ]
        self._movie_capture_resolution_combo = None
        self._movie_capture_resolution_default_index = (
            self._get_movie_capture_resolution_index_from_model()
        )

        self._movie_capture_render_preset_items = [
            RENDER_PRESET_LABELS[key] for key in RENDER_PRESET_KEYS
        ]
        self._movie_capture_render_preset_combo = None
        self._movie_capture_render_preset_default_index = (
            self._get_movie_capture_render_preset_index_from_model()
        )

        self._preset_picker_dialog = None

        # Keep movie format fixed
        self._model.movie_capture_format = VIDEO_CAPTURE_FILE_TYPE

        # Normalize current model values to one of the supported output profiles
        self._apply_movie_capture_output_profile(
            self._movie_capture_resolution_default_index,
            update_status=False,
        )



        if not hasattr(self._model, "movie_capture_user_render_preset_path"):
            self._model.movie_capture_user_render_preset_path = ""

        self._movie_capture_user_preset_model = ui.SimpleStringModel(
            str(getattr(self._model, "movie_capture_user_render_preset_path", "") or "")
        )


        self._window = ui.Window(title, width=width, height=height, visible=True)
        self._window.frame.style = STYLE
        self._window.frame.set_build_fn(self._build_ui)

        # Labels
        self._vehicle_label: Optional[ui.Label] = None
        self._curve_label: Optional[ui.Label] = None
        self._wheels_label: Optional[ui.Label] = None
        self._status_label: Optional[ui.Label] = None
        self._runtime_u_label: Optional[ui.Label] = None
        self._runtime_angle_label: Optional[ui.Label] = None
        self._runtime_distance_label: Optional[ui.Label] = None
        self._driver_camera_label: Optional[ui.Label] = None
        self._spectator_camera_label: Optional[ui.Label] = None
        self._steering_wheel_label: Optional[ui.Label] = None


        

        # Persistent field subscriptions
        self._start_frame_sub = None
        self._end_frame_sub = None
        self._wheel_diameter_sub = None
        self._duration_sub = None
        self._forward_axis_sub = None
        

        self._driver_cam_x_sub = None
        self._driver_cam_y_sub = None
        self._driver_cam_z_sub = None
        self._driver_cam_rx_sub = None
        self._driver_cam_ry_sub = None
        self._driver_cam_rz_sub = None

        self._spectator_cam_x_sub = None
        self._spectator_cam_y_sub = None
        self._spectator_cam_z_sub = None
        self._spectator_cam_rx_sub = None
        self._spectator_cam_ry_sub = None
        self._spectator_cam_rz_sub = None

        self._spectator_above_x_sub = None
        self._spectator_above_y_sub = None
        self._spectator_above_z_sub = None
        self._spectator_above_rx_sub = None
        self._spectator_above_ry_sub = None
        self._spectator_above_rz_sub = None

        # Dynamic per-vehicle UI bindings
        self._vehicle_offset_subs = []
        self._vehicle_enabled_subs = []
        self._vehicle_labels = []
        self._vehicle_label_indices = []
        self._vehicle_wheels_labels = []
        self._vehicle_wheels_label_indices = []
        self._vehicle_offset_models = []
        self._vehicle_enabled_models = []

        # Gap unit combo
        self._gap_unit_items = ["m", "cm", "mm"]
        current_gap_unit = getattr(self._model, "gap_display_unit", "m")
        if current_gap_unit not in self._gap_unit_items:
            current_gap_unit = "m"
        self._model.gap_display_unit = current_gap_unit
        self._gap_unit_default_index = self._gap_unit_items.index(current_gap_unit)
        self._gap_unit_combo = None

        # Forward axis combo
        self._forward_axis_items = ["+X", "+Y", "-X", "-Y"]
        current_forward_axis = getattr(self._model, "vehicle_forward_axis", None) or "+X"
        if current_forward_axis not in self._forward_axis_items:
            current_forward_axis = "+X"
        self._model.vehicle_forward_axis = current_forward_axis
        self._forward_axis_default_index = self._forward_axis_items.index(current_forward_axis)
        self._forward_axis_combo = None

        # Core playback models
        self._start_frame_model = ui.SimpleIntModel(
            int(getattr(self._model, "start_frame", 0))
        )
        self._end_frame_model = ui.SimpleIntModel(
            int(getattr(self._model, "end_frame", 100))
        )
        
        self._has_duration = hasattr(self._model, "duration_seconds")
        self._duration_model = None
        if self._has_duration:
            self._duration_model = ui.SimpleFloatModel(
                float(getattr(self._model, "duration_seconds", 10.0))
            )

        # Camera models
        (
            self._driver_cam_x_model,
            self._driver_cam_y_model,
            self._driver_cam_z_model,
        ) = self._make_vec3_models(
            getattr(self._model, "driver_camera_offset_xyz", (1337.0, -355.0, 1027.3))
        )
        (
            self._driver_cam_rx_model,
            self._driver_cam_ry_model,
            self._driver_cam_rz_model,
        ) = self._make_vec3_models(
            getattr(self._model, "driver_camera_rotation_xyz", (90.0, 0.0, 90.0))
        )

        (
            self._spectator_cam_x_model,
            self._spectator_cam_y_model,
            self._spectator_cam_z_model,
        ) = self._make_vec3_models(
            getattr(self._model, "spectator_camera_offset_xyz", (-6000.0, 2000.0, 1800.0))
        )
        (
            self._spectator_cam_rx_model,
            self._spectator_cam_ry_model,
            self._spectator_cam_rz_model,
        ) = self._make_vec3_models(
            getattr(self._model, "spectator_camera_rotation_xyz", (0.0, 0.0, 0.0))
        )

        (
            self._spectator_above_x_model,
            self._spectator_above_y_model,
            self._spectator_above_z_model,
        ) = self._make_vec3_models(
            getattr(self._model, "spectator_above_camera_offset_xyz", (1400.0, 0.0, 12700.0))
        )
        (
            self._spectator_above_rx_model,
            self._spectator_above_ry_model,
            self._spectator_above_rz_model,
        ) = self._make_vec3_models(
            getattr(self._model, "spectator_above_camera_rotation_xyz", (180, 0.0, -90))
        )

        self._stage_sub = None
        self._update_sub = None
        self._callbacks_connected = False

        self._install_stage_subscription()
        self._install_update_subscription()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _make_vec3_models(self, value):
        return (
            ui.SimpleFloatModel(float(value[0])),
            ui.SimpleFloatModel(float(value[1])),
            ui.SimpleFloatModel(float(value[2])),
        )

    def _reset_dynamic_vehicle_ui_state(self):
        self._vehicle_offset_subs = []
        self._vehicle_enabled_subs = []
        self._vehicle_labels = []
        self._vehicle_label_indices = []
        self._vehicle_wheels_labels = []
        self._vehicle_wheels_label_indices = []
        self._vehicle_offset_models = []
        self._vehicle_enabled_models = []

    # ------------------------------------------------------------------
    # Window proxy API
    # ------------------------------------------------------------------
    @property
    def visible(self):
        return self._window.visible if self._window else False

    @visible.setter
    def visible(self, value: bool):
        if self._window:
            self._window.visible = value

    
    def destroy(self):
        self._release_subscriptions()
        self._callbacks_connected = False

        # Break references back into the extension / controller callbacks
        self._ensure_adapters_match_model = None
        self._on_record_movie_fn = None
        self._on_pause_movie_fn = None
        self._on_stop_movie_fn = None
        self._on_open_movie_capture_advanced_fn = None

        self._extension = None

        if self._window:
            try:
                self._window.set_visibility_changed_fn(None)
            except Exception:
                LOGGER.debug("Failed clearing visibility callback.", exc_info=True)

            self._window.destroy()
            self._window = None


    # ------------------------------------------------------------------
    # UI build
    # ------------------------------------------------------------------
    def _build_ui(self):
        with ui.ScrollingFrame(
            horizontal_scrollbar_policy=ui.ScrollBarPolicy.SCROLLBAR_ALWAYS_OFF
        ):
            with ui.VStack(height=0, spacing=6):
                ui.Spacer(height=4)
                self._build_top_bar()
                self._build_status_group()
                self._build_playback_group()
                self._build_viewport_group()
                self._build_capture_group()
                self._build_camera_settings()
                
                self._build_video_capture_group()
                
                self._build_motion_path_group()
                self._build_help_group()
                ui.Spacer(height=12)
                self._refresh_labels()
                self._connect_model_callbacks()

    def _build_top_bar(self):
        ui.Label("Tracking Motion Path", name="header_title")
        ui.Spacer(height=6)

    def _build_status_group(self):
        self._status_label = ui.Label("Ready", name="muted", word_wrap=True)
        ui.Spacer(height=4)

    def _build_capture_group(self):
        with ui.CollapsableFrame("Capture Assets", collapsed=False):
            with self._section_body():
                ui.Label(
                    "Capture the main vehicle first (vehicle, wheels, steering wheel), then the path. "
                    "Optionally add extra vehicles for a convoy, then apply Motion Path.",
                    name="muted",
                    word_wrap=True,
                )
                ui.Spacer(height=12)

                # Main vehicle
                ui.Label("Main Vehicle", name="group_title")
                ui.Spacer(height=4)

                self._action_row("Vehicle", "Capture Vehicle", self._on_capture_vehicle)
                self._vehicle_label = ui.Label("", name="muted", word_wrap=True)
                self._divider()

                self._action_row("Wheels", "Capture Wheels", self._on_capture_wheels)
                self._wheels_label = ui.Label("", name="muted", word_wrap=True)
                self._divider()

                self._action_row(
                    "Steering Wheel",
                    "Capture Steering Wheel",
                    self._on_capture_steering_wheel,
                )
                self._steering_wheel_label = ui.Label("", name="muted", word_wrap=True)
                self._divider()

                # Path
                ui.Label("Path", name="group_title")
                ui.Spacer(height=4)

                self._action_row("Curve", "Capture Path", self._on_capture_path)
                self._curve_label = ui.Label("", name="muted", word_wrap=True)
                self._divider()

                # Convoy
                ui.Label("Extra Vehicles (Optional)", name="group_title")
                ui.Spacer(height=4)

                extra_vehicle_count = max(len(getattr(self._model, "vehicles", [])) - 1, 0)
                ui.Label(
                    f"{extra_vehicle_count} extra vehicle(s) currently configured. Add more only when needed.",
                    name="muted",
                    word_wrap=True,
                )
                ui.Spacer(height=8)

                with ui.HStack(height=24, spacing=8):
                    ui.Button("Add Vehicle", width=150, clicked_fn=self._on_add_vehicle)
                    ui.Button(
                        "Remove Last Vehicle",
                        width=150,
                        clicked_fn=self._on_remove_last_vehicle,
                    )

                ui.Spacer(height=10)

                

                self._reset_dynamic_vehicle_ui_state()

                extra_vehicles = list(enumerate(getattr(self._model, "vehicles", [])))[1:]
                if extra_vehicles:
                    for index, vehicle in extra_vehicles:
                        self._build_single_vehicle_row(index, vehicle)
                        self._divider()
                else:
                    ui.Label("No extra vehicles added.", name="muted", word_wrap=True)
                    self._divider()


    def _build_video_capture_group(self):
        with ui.CollapsableFrame("Movie Capture", collapsed=True, height=0):
            with ui.VStack(spacing=GROUP_SPACING):

                # ------------------------------------------------------------------
                # Output folder
                # ------------------------------------------------------------------
                
                with ui.HStack(height=ROW_HEIGHT, spacing=6):
                        ui.Label("Output folder", width=LABEL_WIDTH)
                        ui.StringField(
                            model=self._movie_capture_output_model,
                            width=FIELD_WIDTH,
                            read_only=True,
                        )

                        ui.Button(
                            "Browse",
                            width=80,
                            clicked_fn=self._on_browse_movie_capture_output,
                        )
                      



                # ------------------------------------------------------------------
                # File name
                # ------------------------------------------------------------------
                with ui.HStack(height=ROW_HEIGHT, spacing=6):
                    ui.Label("Name", width=LABEL_WIDTH)
                    field = ui.StringField(
                        model=self._movie_capture_name_model,
                        width=FIELD_WIDTH,
                    )
                    _ = field

                
                ui.Spacer(height=12)



                # ------------------------------------------------------------------
                # Seconds-only range
                # ------------------------------------------------------------------
                with ui.HStack(height=ROW_HEIGHT, spacing=6):
                    ui.Label("Start (s)", width=LABEL_WIDTH)
                    ui.FloatDrag(
                        model=self._movie_capture_start_seconds_model,
                        min=0.0,
                        width=FIELD_WIDTH,
                    )

                with ui.HStack(height=ROW_HEIGHT, spacing=6):
                    ui.Label("End (s)", width=LABEL_WIDTH)
                    ui.FloatDrag(
                        model=self._movie_capture_end_seconds_model,
                        min=0.0,
                        width=FIELD_WIDTH,
                    )

                ui.Spacer(height=12)


                # ------------------------------------------------------------------
                # Output profile (resolution + fps)
                # ------------------------------------------------------------------
                with ui.HStack(height=ROW_HEIGHT, spacing=6):
                    ui.Label("Select resolution", width=LABEL_WIDTH)
                    self._build_movie_capture_resolution_combo()

                ui.Spacer(height=8)

                # ------------------------------------------------------------------
                # Render preset
                # ------------------------------------------------------------------
                with ui.HStack(height=ROW_HEIGHT, spacing=6):
                    ui.Label("Render preset", width=LABEL_WIDTH)
                    self._build_movie_capture_render_preset_combo()

                ui.Spacer(height=8)

                # ------------------------------------------------------------------
                # Custom render preset (.usd / .usda)
                # ------------------------------------------------------------------
                with ui.HStack(height=ROW_HEIGHT, spacing=6):
                    ui.Label("Load custom preset", width=LABEL_WIDTH)
                    ui.StringField(
                        model=self._movie_capture_user_preset_model,
                        width=FIELD_WIDTH,
                        read_only=True,
                    )
                    ui.Button(
                        "Load Preset",
                        width=120,
                        clicked_fn=self._on_load_movie_capture_preset,
                    )

                ui.Spacer(height=8)

                # ------------------------------------------------------------------
                # Preset summary
                # ------------------------------------------------------------------
                ui.Label(
                    self._get_movie_capture_preset_summary_text(),
                    name="muted",
                    height=ROW_HEIGHT,
                )

              

                



                ui.Spacer(height=12)

                

                # ------------------------------------------------------------------
                # Actions
                # ------------------------------------------------------------------
                output_dir = (self._model.movie_capture_output_dir or "").strip()
                record_enabled = bool(output_dir)
                if not record_enabled:
                                ui.Spacer(height=4)
                                ui.Label(
                                    "Select an output folder to enable recording.",
                                    name="muted",
                                )
                ui.Spacer(height=4)
                with ui.HStack(height=ROW_HEIGHT, spacing=6):
                    ui.Button(
                        "Record",
                        width=BUTTON_WIDTH,
                        enabled=record_enabled,
                        clicked_fn=self._on_record_movie,
                        
                    )
                    
                    ui.Button(
                        "Pause / Resume",
                        width=BUTTON_WIDTH,
                        clicked_fn=self._on_pause_movie,
                    )
                    ui.Button(
                        "Stop",
                        width=BUTTON_WIDTH,
                        clicked_fn=self._on_stop_movie,
                    )

                ui.Spacer(height=12)
                

                # ------------------------------------------------------------------
                # Advanced hand-off to the original Omniverse window
                # ------------------------------------------------------------------
                with ui.HStack(height=ROW_HEIGHT, spacing=6):
                    ui.Button(
                        "Advanced Settings",
                        width=BUTTON_WIDTH,
                        clicked_fn=self._on_open_movie_capture_advanced,
                    )
                ui.Spacer(height=12)

    

    


    

    def _build_video_capture_request(self):
        profile = self._get_video_output_profile()

        start_s = float(getattr(self._model, "movie_capture_start_seconds", 0.0) or 0.0)
        end_s = float(getattr(self._model, "movie_capture_end_seconds", 10.0) or 10.0)
        if end_s <= start_s:
            end_s = start_s + 1.0

        output_folder = self._get_string_model_value(self._movie_capture_output_model).strip()
        file_name = self._get_string_model_value(self._movie_capture_name_model).strip() or "tracking_motion_path"

        render_preset_key = str(
            getattr(self._model, "movie_capture_render_preset", "default_realtime") or "default_realtime"
        ).strip().lower()

        custom_render_preset_path = str(
            getattr(self._model, "movie_capture_user_render_preset_path", "") or ""
        ).strip()

        if render_preset_key == "custom" and not custom_render_preset_path:
            self._set_status("Load a custom .usd / .usda preset or switch back to a default render preset.")
            return None

        return {
            "output_folder": output_folder,
            "file_name": file_name,
            "file_type": VIDEO_CAPTURE_FILE_TYPE,
            "range_mode": "SECONDS",
            "start_time": start_s,
            "end_time": end_s,
            "res_width": int(profile["width"]),
            "res_height": int(profile["height"]),
            "fps": int(profile["fps"]),
            "render_preset": render_preset_key,
            "custom_render_preset_path": custom_render_preset_path,
            "resolution_label": profile["label"],
        }



    
    def _on_browse_movie_capture_output(self):

        def _on_apply(filename: str, dirname: str):
            # dirname is the selected directory (with trailing slash)
            if not dirname:
                return

            # Normalize path (optional but recommended)
            output_dir = dirname.rstrip("/\\")

            # Update UI model
            self._movie_capture_output_model.set_value(output_dir)

            # Update AppModel
            self._model.movie_capture_output_dir = output_dir

            # User feedback
            self._model.runtime.status_text = f"Movie capture output set to: {output_dir}"

            # Close dialog
            if self._output_picker_dialog:
                self._output_picker_dialog.hide()
                self._output_picker_dialog = None

            # Rebuild UI (enables Record button)
            self._window.frame.rebuild()

        # ✅ KEEP A STRONG REFERENCE
        self._output_picker_dialog = filepicker.FilePickerDialog(
            title="Select Movie Capture Output Folder",
            width=1000,
            height=600,
            select_directory=True,              # ✅ folder mode
            allow_multi_selection=False,
            show_file_extensions=False,
            click_apply_handler=_on_apply,      # ✅ CORRECT PARAM NAME
        )

        self._output_picker_dialog.show()

    def _on_load_movie_capture_preset(self):
        def _on_apply(filename: str, dirname: str):
            # Debug first - check what the picker is actually returning
            LOGGER.warning(
                "Preset picker apply clicked: filename=%r dirname=%r",
                filename,
                dirname,
            )

            if not filename:
                return

            # Build the full path from dirname + filename
            base_dir = str(dirname or "").rstrip("/\\")
            if base_dir:
                selected_path = f"{base_dir}/{filename}"
            else:
                selected_path = str(filename)

            selected_path = selected_path.replace("\\", "/")

            LOGGER.warning("Resolved preset path: %s", selected_path)

            # Validate through the controller
            result = self._movie_capture_controller.validate_render_preset_file(selected_path)
            if not result.is_valid:
                self._model.runtime.status_text = (
                    "Invalid render preset: " + "; ".join(result.errors)
                )
                LOGGER.error("Preset validation failed: %s", result.errors)
                return

            # Save into model
            self._model.movie_capture_user_render_preset_path = selected_path
            self._model.movie_capture_preset = "custom"

            # Update UI field
            self._movie_capture_user_preset_model.set_value(selected_path)

            # User feedback
            status = f"Loaded custom preset: {result.applied_key_count} setting(s)"
            if result.warnings:
                status += f" ({len(result.warnings)} warning(s))"
            self._model.runtime.status_text = status

            # Close dialog
            if self._preset_picker_dialog:
                self._preset_picker_dialog.hide()
                self._preset_picker_dialog = None

            # Refresh UI if needed
            self._window.frame.rebuild()

        # KEEP A STRONG REFERENCE
        self._preset_picker_dialog = filepicker.FilePickerDialog(
            title="Select Render Preset (.usd / .usda)",
            width=1000,
            height=600,
            click_apply_handler=_on_apply,
            file_extension_types=[(".usd", ".usda")],
            allow_multi_selection=False,
        )
        self._preset_picker_dialog.show()


    def _get_movie_capture_preset_summary_text(self) -> str:
        preset_name = str(
            getattr(self._model, "movie_capture_preset", "fast") or "fast"
        ).strip().lower()

        if preset_name == "custom":
            preset_path = str(
                getattr(self._model, "movie_capture_user_render_preset_path", "") or ""
            ).strip()

            if preset_path:
                return f"Custom preset / {os.path.basename(preset_path)} / MP4"
            return "Custom preset / no file selected / MP4"

        preset = self._get_video_capture_preset()
        return (
            f"{preset['label']} / {preset['width']}x{preset['height']} / "
            f"{preset['fps']} fps / MP4"
        )


    def _build_gap_unit_combo(self):
        self._gap_unit_combo = ui.ComboBox(
            self._gap_unit_default_index,
            *self._gap_unit_items,
            width=FIELD_WIDTH,
        )
        self._gap_unit_sub = self._gap_unit_combo.model.subscribe_item_changed_fn(
            self._on_gap_unit_changed
        )

    def _build_single_vehicle_row(self, index, vehicle):
        ui.Label(f"{vehicle.name}", name="group_title")
        ui.Spacer(height=4)

        offset_model = ui.SimpleFloatModel(
            self._meters_to_display_unit(float(getattr(vehicle, "offset_distance_m", 0.0)))
        )
        enabled_model = ui.SimpleBoolModel(bool(vehicle.enabled))

        self._vehicle_offset_models.append(offset_model)
        self._vehicle_enabled_models.append(enabled_model)

        with ui.HStack(height=24, spacing=8):
            ui.Label("Captured", width=100, name="attribute_name")
            vehicle_label = ui.Label(vehicle.rig_path or "-", name="muted", word_wrap=True)
            self._vehicle_labels.append(vehicle_label)
            self._vehicle_label_indices.append(index)

        with ui.HStack(height=24, spacing=8):
            ui.Label("Wheels", width=100, name="attribute_name")
            wheels_label = ui.Label(vehicle.wheel.summary(), name="muted", word_wrap=True)
            self._vehicle_wheels_labels.append(wheels_label)
            self._vehicle_wheels_label_indices.append(index)

        with ui.HStack(height=24, spacing=8):
            ui.Label("Gap", width=100, name="attribute_name")
            ui.FloatField(offset_model, width=180)

            ui.Label("Enabled", width=80, name="attribute_name")
            ui.CheckBox(model=enabled_model, width=30)

        with ui.HStack(height=24, spacing=8):
            ui.Spacer(width=108)
            ui.Button(
                f"Capture {vehicle.name}",
                width=180,
                clicked_fn=lambda i=index: self._on_capture_vehicle_index(i),
            )
            ui.Button(
                f"Capture Wheels {index + 1}",
                width=180,
                clicked_fn=lambda i=index: self._on_capture_vehicle_wheels_index(i),
            )

        # Single subscription per model
        offset_sub = offset_model.subscribe_value_changed_fn(
            lambda m, i=index: self._on_vehicle_offset_changed(i, m)
        )
        enabled_sub = enabled_model.subscribe_value_changed_fn(
            lambda m, i=index: self._on_vehicle_enabled_changed(i, m)
        )

        self._vehicle_offset_subs.append(offset_sub)
        self._vehicle_enabled_subs.append(enabled_sub)

    def _build_motion_path_group(self):
        with ui.CollapsableFrame("Motion Path Settings", collapsed=False):
            with self._section_body():
                ui.Label(
                    "These settings control how the vehicle is animated along the captured curve.",
                    name="muted",
                    word_wrap=True,
                )
                ui.Spacer(height=12)

                self._property_row("Forward Axis", self._build_forward_axis_combo)
                self._property_row(
                    "Start Frame",
                    lambda: ui.IntField(self._start_frame_model, width=FIELD_WIDTH),
                )
                self._property_row(
                    "End Frame",
                    lambda: ui.IntField(self._end_frame_model, width=FIELD_WIDTH),
                )

                if self._has_duration and self._duration_model is not None:
                    self._property_row(
                        "Duration (s)",
                        lambda: ui.FloatField(self._duration_model, width=FIELD_WIDTH),
                    )

               

    def _build_playback_group(self):
        with ui.VStack(height=ROW_HEIGHT, spacing=8):
            ui.Label("Scenario", width=80, name="attribute_name")
            with ui.HStack(height=ROW_HEIGHT, spacing=8):
                ui.Button("Start", width=150, height=20, clicked_fn=self._on_start)
                ui.Button("Pause / Resume", width=150, height=20, clicked_fn=self._on_pause)
                ui.Button("Stop / Reset", width=150, height=20, clicked_fn=self._on_stop)

        ui.Spacer(height=12)
        self._divider()

        with ui.VStack(height=ROW_HEIGHT, spacing=8):
            ui.Label("Motion path", width=80, name="attribute_name")
            with ui.HStack(height=ROW_HEIGHT, spacing=8):
                ui.Button(
                    "Create motion path",
                    width=BUTTON_WIDTH,
                    height=20,
                    clicked_fn=self._on_apply_motion_path_to_all,
                )
                ui.Button(
                    "Global Reset",
                    width=BUTTON_WIDTH,
                    height=20,
                    clicked_fn=self._on_global_reset,
                )

        ui.Spacer(height=12)

    def _build_viewport_group(self):
        with ui.CollapsableFrame("Cameras", collapsed=False):
            with self._section_body():
                with ui.VStack(height=ROW_HEIGHT, spacing=8):
                    ui.Label("Create / activate cameras", width=80, name="attribute_name")

                    with ui.HStack(height=ROW_HEIGHT, spacing=8):
                        ui.Button(
                            "Driver Camera",
                            width=BUTTON_WIDTH,
                            height=20,
                            clicked_fn=self._on_driver_camera_button,
                        )
                        ui.Button(
                            "Spectator Camera",
                            width=BUTTON_WIDTH,
                            height=20,
                            clicked_fn=self._on_spectator_camera_button,
                        )
                        ui.Button(
                            "Spectator Above",
                            width=BUTTON_WIDTH,
                            height=20,
                            clicked_fn=self._on_spectator_above_camera_button,
                        )

                    ui.Spacer(height=2)

                    ui.Button(
                        "Reset Cameras",
                        width=BUTTON_WIDTH,
                        height=20,
                        clicked_fn=self._on_reset_cameras,
                    )

    def _build_camera_settings(self):
        with ui.CollapsableFrame("Camera Settings", collapsed=True):
            with self._section_body():
                ui.Spacer(height=12)
                ui.Label("Spectator Camera Settings", name="group_title")
                ui.Spacer(height=4)

                self._property_row("Spectator X", lambda: self._float_drag(self._spectator_cam_x_model, 100.0))
                self._property_row("Spectator Y", lambda: self._float_drag(self._spectator_cam_y_model, 100.0))
                self._property_row("Spectator Z", lambda: self._float_drag(self._spectator_cam_z_model, 100.0))
                self._property_row("Spectator Rot X", lambda: self._float_drag(self._spectator_cam_rx_model, 1.0))
                self._property_row("Spectator Rot Y", lambda: self._float_drag(self._spectator_cam_ry_model, 1.0))
                self._property_row("Spectator Rot Z", lambda: self._float_drag(self._spectator_cam_rz_model, 1.0))

                ui.Spacer(height=12)
                ui.Label("Spectator Above Settings", name="group_title")
                ui.Spacer(height=4)

                self._property_row("Above X", lambda: self._float_drag(self._spectator_above_x_model, 100.0))
                self._property_row("Above Y", lambda: self._float_drag(self._spectator_above_y_model, 100.0))
                self._property_row("Above Z", lambda: self._float_drag(self._spectator_above_z_model, 100.0))
                self._property_row("Above Rot X", lambda: self._float_drag(self._spectator_above_rx_model, 1.0))
                self._property_row("Above Rot Y", lambda: self._float_drag(self._spectator_above_ry_model, 1.0))
                self._property_row("Above Rot Z", lambda: self._float_drag(self._spectator_above_rz_model, 1.0))

                ui.Spacer(height=24)
                ui.Label("Driver Camera Settings", name="group_title")
                ui.Spacer(height=4)

                self._property_row("Driver Cam X", lambda: self._float_drag(self._driver_cam_x_model, 10.0))
                self._property_row("Driver Cam Y", lambda: self._float_drag(self._driver_cam_y_model, 10.0))
                self._property_row("Driver Cam Z", lambda: self._float_drag(self._driver_cam_z_model, 10.0))
                self._property_row("Driver Rot X", lambda: self._float_drag(self._driver_cam_rx_model, 1.0))
                self._property_row("Driver Rot Y", lambda: self._float_drag(self._driver_cam_ry_model, 1.0))
                self._property_row("Driver Rot Z", lambda: self._float_drag(self._driver_cam_rz_model, 1.0))

                ui.Spacer(height=12)

    def _float_drag(self, model, step):
        return ui.FloatDrag(
            model,
            width=FIELD_WIDTH,
            step=step,
            precision=0,
            format="%.0f",
        )

    # ------------------------------------------------------------------
    # Help
    # ------------------------------------------------------------------
    def _help_info_block(self, title: str, lines: list[str], height: int = 120):
        with ui.ZStack(height=height):
            ui.Rectangle(style_type_name_override="InfoBlock")
            with ui.VStack(height=0, spacing=2):
                ui.Spacer(height=6)
                with ui.HStack(height=0):
                    ui.Spacer(width=8)
                    ui.Label(title, name="group_title", word_wrap=True)
                    ui.Spacer(width=8)
                ui.Spacer(height=2)

                for line in lines:
                    with ui.HStack(height=0):
                        ui.Spacer(width=8)
                        ui.Label(line, name="muted", word_wrap=True)
                        ui.Spacer(width=8)

                ui.Spacer(height=6)

    def _build_help_group(self):
        with ui.CollapsableFrame("How to Use", collapsed=True):
            with self._section_body():
                self._help_info_block(
                    "Step 1: Capture Objects",
                    [
                        "Use the UI buttons to capture:",
                        "1. Vehicle: Select a vehicle prim -> Capture Vehicle",
                        "2. Curve: Select a BasisCurves prim -> Capture Path",
                        "3. Wheels (optional): Select exactly 4 wheel prims -> Capture Wheels",
                    ],
                    height=110,
                )

                ui.Spacer(width=4)

                self._help_info_block(
                    "Step 2: Build Motion Path Graph",
                    [
                        "Click Apply Motion Path.",
                        "The extension will build/update one graph per enabled captured vehicle.",
                        "Each graph reads the curve, evaluates MotionPath, composes the transform, and drives SetXform.",
                        "The animation driver is MotionPath.inputs:uValue in [0, 1].",
                    ],
                    height=130,
                )

                ui.Spacer(width=2)

                self._help_info_block(
                    "Step 3: Configure Motion Path Settings",
                    [
                        "You can adjust:",
                        "1. Forward axis (+X / +Y / -X / -Y)",
                        "2. Start frame / End frame",
                        "3. Optional: Duration in seconds (overrides end frame)",
                    ],
                    height=100,
                )

                ui.Spacer(width=2)

                self._help_info_block(
                    "Step 4: Play the Scenario",
                    [
                        "Use the Scenario controls:",
                        "1. Start -> begins playback",
                        "2. Pause / Resume -> toggles playback",
                        "3. Stop / Reset -> returns U-value and wheels to 0",
                    ],
                    height=110,
                )

                ui.Spacer(width=2)

                self._help_info_block(
                    "Wheel Sync (Optional)",
                    [
                        "Wheel spinning is visual-only:",
                        "- Driven by motion path progress",
                        "- Applies continuous rotation using a dedicated rotateXYZ Op",
                        "- Uses user-specified wheel diameter",
                        "- Does not simulate physics or lateral slip",
                    ],
                    height=140,
                )

    # ------------------------------------------------------------------
    # Reusable layout helpers
    # ------------------------------------------------------------------
    class _section_body:
        def __enter__(self):
            self._z = ui.ZStack(height=0)
            self._z.__enter__()
            ui.Rectangle(style_type_name_override="SectionBody")
            self._v = ui.VStack(height=0, spacing=GROUP_SPACING)
            self._v.__enter__()
            ui.Spacer(height=6)

        def __exit__(self, exc_type, exc_val, exc_tb):
            ui.Spacer(height=6)
            self._v.__exit__(exc_type, exc_val, exc_tb)
            self._z.__exit__(exc_type, exc_val, exc_tb)

    def _divider(self):
        with ui.ZStack(height=6):
            with ui.VStack():
                ui.Spacer(height=2)
                ui.Rectangle(style_type_name_override="Divider", height=1)

    def _property_row(self, label: str, control_builder):
        with ui.HStack(height=ROW_HEIGHT, spacing=8):
            ui.Label(label, width=LABEL_WIDTH, name="attribute_name")
            control_builder()

    def _action_row(self, label: str, button_text: str, clicked_fn):
        with ui.HStack(height=ROW_HEIGHT, spacing=8):
            ui.Label(label, width=LABEL_WIDTH, name="attribute_name")
            ui.Button(button_text, width=BUTTON_WIDTH, height=20, clicked_fn=clicked_fn)

    def _build_forward_axis_combo(self):
        self._forward_axis_combo = ui.ComboBox(
            self._forward_axis_default_index,
            *self._forward_axis_items,
            width=FIELD_WIDTH,
        )
        self._forward_axis_sub = self._forward_axis_combo.model.subscribe_item_changed_fn(
            self._on_forward_axis_changed
        )

    

    def _get_capture_duration_seconds(self) -> float:
        start_s = float(getattr(self._model, "movie_capture_start_seconds", 0.0) or 0.0)
        end_s = float(getattr(self._model, "movie_capture_end_seconds", 10.0) or 10.0)
        return max(0.0, end_s - start_s)
        
    @staticmethod
    def _get_string_model_value(model) -> str:
        try:
            return model.get_value_as_string()
        except Exception:
            try:
                return model.as_string
            except Exception:
                return ""
            


    
    def _connect_model_callbacks(self):
        if self._callbacks_connected:
            return

        self._callbacks_connected = True

        self._start_frame_sub = self._start_frame_model.subscribe_value_changed_fn(
            self._on_frame_range_changed
        )
        self._end_frame_sub = self._end_frame_model.subscribe_value_changed_fn(
            self._on_frame_range_changed
        )
        

        if self._has_duration and self._duration_model is not None:
            self._duration_sub = self._duration_model.subscribe_value_changed_fn(
                self._on_duration_changed
            )



        self._movie_capture_output_sub = self._movie_capture_output_model.add_value_changed_fn(
            self._on_movie_capture_output_changed
        )
        self._movie_capture_name_sub = self._movie_capture_name_model.add_value_changed_fn(
            self._on_movie_capture_name_changed
        )
        self._movie_capture_start_seconds_sub = self._movie_capture_start_seconds_model.add_value_changed_fn(
            self._on_movie_capture_start_seconds_changed
        )
        self._movie_capture_end_seconds_sub = self._movie_capture_end_seconds_model.add_value_changed_fn(
            self._on_movie_capture_end_seconds_changed
        )



        self._driver_cam_x_sub = self._driver_cam_x_model.subscribe_value_changed_fn(
            self._on_driver_camera_transform_changed
        )
        self._driver_cam_y_sub = self._driver_cam_y_model.subscribe_value_changed_fn(
            self._on_driver_camera_transform_changed
        )
        self._driver_cam_z_sub = self._driver_cam_z_model.subscribe_value_changed_fn(
            self._on_driver_camera_transform_changed
        )
        self._driver_cam_rx_sub = self._driver_cam_rx_model.subscribe_value_changed_fn(
            self._on_driver_camera_transform_changed
        )
        self._driver_cam_ry_sub = self._driver_cam_ry_model.subscribe_value_changed_fn(
            self._on_driver_camera_transform_changed
        )
        self._driver_cam_rz_sub = self._driver_cam_rz_model.subscribe_value_changed_fn(
            self._on_driver_camera_transform_changed
        )

        self._spectator_cam_x_sub = self._spectator_cam_x_model.subscribe_value_changed_fn(
            self._on_spectator_camera_transform_changed
        )
        self._spectator_cam_y_sub = self._spectator_cam_y_model.subscribe_value_changed_fn(
            self._on_spectator_camera_transform_changed
        )
        self._spectator_cam_z_sub = self._spectator_cam_z_model.subscribe_value_changed_fn(
            self._on_spectator_camera_transform_changed
        )
        self._spectator_cam_rx_sub = self._spectator_cam_rx_model.subscribe_value_changed_fn(
            self._on_spectator_camera_transform_changed
        )
        self._spectator_cam_ry_sub = self._spectator_cam_ry_model.subscribe_value_changed_fn(
            self._on_spectator_camera_transform_changed
        )
        self._spectator_cam_rz_sub = self._spectator_cam_rz_model.subscribe_value_changed_fn(
            self._on_spectator_camera_transform_changed
        )

        self._spectator_above_x_sub = self._spectator_above_x_model.subscribe_value_changed_fn(
            self._on_spectator_above_transform_changed
        )
        self._spectator_above_y_sub = self._spectator_above_y_model.subscribe_value_changed_fn(
            self._on_spectator_above_transform_changed
        )
        self._spectator_above_z_sub = self._spectator_above_z_model.subscribe_value_changed_fn(
            self._on_spectator_above_transform_changed
        )
        self._spectator_above_rx_sub = self._spectator_above_rx_model.subscribe_value_changed_fn(
            self._on_spectator_above_transform_changed
        )
        self._spectator_above_ry_sub = self._spectator_above_ry_model.subscribe_value_changed_fn(
            self._on_spectator_above_transform_changed
        )
        self._spectator_above_rz_sub = self._spectator_above_rz_model.subscribe_value_changed_fn(
            self._on_spectator_above_transform_changed
        )

    # ------------------------------------------------------------------
    # Camera callbacks
    # ------------------------------------------------------------------
    def _on_driver_camera_button(self):
        try:
            if not getattr(self._model, "driver_camera_path", None):
                self._on_create_driver_camera()
            else:
                self._on_activate_driver_camera()
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_spectator_camera_button(self):
        try:
            if not getattr(self._model, "spectator_camera_path", None):
                self._on_create_spectator_camera()
            else:
                self._on_activate_spectator_camera()
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_spectator_above_camera_button(self):
        try:
            if not getattr(self._model, "spectator_above_camera_path", None):
                self._on_create_spectator_above_camera()
            else:
                self._on_activate_spectator_above_camera()
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_create_driver_camera(self):
        try:
            camera_path = self._driver_camera.create_or_update_driver_camera()
            self._set_status(f"Driver camera ready: {camera_path}")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_activate_driver_camera(self):
        try:
            self._driver_camera.activate_driver_camera()
            self._set_status(self._model.runtime.status_text or "Driver camera activated.")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_create_spectator_camera(self):
        try:
            camera_path = self._driver_camera.create_or_update_spectator_camera()
            self._set_status(f"Spectator camera ready: {camera_path}")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_activate_spectator_camera(self):
        try:
            self._driver_camera.activate_spectator_camera()
            self._set_status(self._model.runtime.status_text or "Spectator camera activated.")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_create_spectator_above_camera(self):
        try:
            camera_path = self._driver_camera.create_or_update_spectator_above_camera()
            self._set_status(f"Spectator Above camera ready: {camera_path}")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_activate_spectator_above_camera(self):
        try:
            self._driver_camera.activate_spectator_above_camera()
            self._set_status(self._model.runtime.status_text or "Spectator Above camera activated.")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_reset_cameras(self):
        try:
            removed = self._driver_camera.reset_cameras()
            self._set_status(f"Reset cameras: removed {removed} prim(s).")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_driver_camera_transform_changed(self, _model):
        try:
            self._model.driver_camera_offset_xyz = (
                float(self._driver_cam_x_model.get_value_as_float()),
                float(self._driver_cam_y_model.get_value_as_float()),
                float(self._driver_cam_z_model.get_value_as_float()),
            )
            self._model.driver_camera_rotation_xyz = (
                float(self._driver_cam_rx_model.get_value_as_float()),
                float(self._driver_cam_ry_model.get_value_as_float()),
                float(self._driver_cam_rz_model.get_value_as_float()),
            )
            self._set_status("Driver camera transform updated in UI.")
        except Exception as exc:
            self._set_status(str(exc))

        if getattr(self._model, "driver_camera_path", None):
            self._driver_camera.create_or_update_driver_camera(
                offset_xyz=self._model.driver_camera_offset_xyz,
                rotation_xyz=self._model.driver_camera_rotation_xyz,
            )

    def _on_spectator_camera_transform_changed(self, _model):
        try:
            self._model.spectator_camera_offset_xyz = (
                int(round(self._spectator_cam_x_model.get_value_as_float())),
                int(round(self._spectator_cam_y_model.get_value_as_float())),
                int(round(self._spectator_cam_z_model.get_value_as_float())),
            )
            self._model.spectator_camera_rotation_xyz = (
                int(round(self._spectator_cam_rx_model.get_value_as_float())),
                int(round(self._spectator_cam_ry_model.get_value_as_float())),
                int(round(self._spectator_cam_rz_model.get_value_as_float())),
            )

            if getattr(self._model, "spectator_camera_path", None):
                self._driver_camera.create_or_update_spectator_camera()

            self._set_status("Spectator camera transform updated.")
        except Exception as exc:
            self._set_status(str(exc))

    def _on_spectator_above_transform_changed(self, _model):
        try:
            self._model.spectator_above_camera_offset_xyz = (
                int(round(self._spectator_above_x_model.get_value_as_float())),
                int(round(self._spectator_above_y_model.get_value_as_float())),
                int(round(self._spectator_above_z_model.get_value_as_float())),
            )
            self._model.spectator_above_camera_rotation_xyz = (
                int(round(self._spectator_above_rx_model.get_value_as_float())),
                int(round(self._spectator_above_ry_model.get_value_as_float())),
                int(round(self._spectator_above_rz_model.get_value_as_float())),
            )

            if getattr(self._model, "spectator_above_camera_path", None):
                self._driver_camera.create_or_update_spectator_above_camera()

            self._set_status("Spectator Above transform updated.")
        except Exception as exc:
            self._set_status(str(exc))

    # ------------------------------------------------------------------
    # Convoy callbacks
    # ------------------------------------------------------------------
    def _on_add_vehicle(self):
        try:
            self._model.add_vehicle()
            self._ensure_adapters_match_model()
            self._set_status("Vehicle slot added.")
            self._window.frame.rebuild()
        except Exception as exc:
            self._set_status(str(exc))

    def _on_remove_last_vehicle(self):
        try:
            if not self._model.vehicles:
                self._set_status("No vehicles to remove.")
                return

            last_index = len(self._model.vehicles) - 1
            if last_index < len(self._adapters):
                try:
                    self._adapters[last_index].reset_extension_state()
                except Exception:
                    LOGGER.debug("Failed to cleanup last adapter during remove.", exc_info=True)

            self._model.remove_vehicle(last_index)
            self._ensure_adapters_match_model()
            self._set_status("Last vehicle removed.")
            self._window.frame.rebuild()
        except Exception as exc:
            self._set_status(str(exc))

    def _on_vehicle_offset_changed(self, index: int, model):
        try:
            value_display = float(model.get_value_as_float())
            if value_display < 0.0:
                self._set_status("Vehicle gap distance must be >= 0.")
                return

            value_m = self._display_unit_to_meters(value_display)

            vehicle = self._model.get_vehicle(index)
            vehicle.offset_distance_m = value_m

            unit = getattr(self._model, "gap_display_unit", "m")
            self._set_status(f"{vehicle.name} gap set to {value_display:.3f} {unit}.")
        except Exception as exc:
            self._set_status(str(exc))

    def _on_vehicle_enabled_changed(self, index: int, model):
        try:
            self._model.get_vehicle(index).enabled = bool(model.get_value_as_bool())
            state = "enabled" if self._model.get_vehicle(index).enabled else "disabled"
            self._set_status(f"{self._model.get_vehicle(index).name} {state}.")
        except Exception as exc:
            self._set_status(str(exc))

    def _on_gap_unit_changed(self, item_model=None, item=None):
        try:
            if self._gap_unit_combo is None:
                self._set_status("Gap unit ComboBox is not available.")
                return

            combo_model = self._gap_unit_combo.model
            value_model = combo_model.get_item_value_model()
            selected_index = int(value_model.as_int)

            if not (0 <= selected_index < len(self._gap_unit_items)):
                self._set_status(f"Invalid gap unit selection index: {selected_index}")
                return

            unit = self._gap_unit_items[selected_index]
            self._model.gap_display_unit = unit
            self._gap_unit_default_index = selected_index

            if self._window and self._window.frame:
                self._window.frame.rebuild()

            self._set_status(f"Gap unit set to {unit}.")
        except Exception as exc:
            self._set_status(str(exc))

    def _display_unit_to_meters(self, value: float) -> float:
        unit = getattr(self._model, "gap_display_unit", "m")
        value = float(value)
        if unit == "cm":
            return value * 0.01
        if unit == "mm":
            return value * 0.001
        return value

    def _meters_to_display_unit(self, value_m: float) -> float:
        unit = getattr(self._model, "gap_display_unit", "m")
        value_m = float(value_m)
        if unit == "cm":
            return value_m / 0.01
        if unit == "mm":
            return value_m / 0.001
        return value_m


    # ------------------------------------------------------------------
    # Record callbacks
    # ------------------------------------------------------------------
 

    def _on_record_movie(self):
        callback = getattr(self, "_on_record_movie_fn", None)
        if not callback:
            LOGGER.warning("Record movie callback is not wired.")
            return

        request = self._build_video_capture_request()
        if not request:
            return

        try:
            callback(request)
        except TypeError:
            # Backward compatibility if an older callback signature is still wired
            callback()


    def _on_pause_movie(self):
        callback = getattr(self, "_on_pause_movie_fn", None)
        if callback:
            callback()
        else:
            LOGGER.warning("Pause movie callback is not wired.")

    def _on_stop_movie(self):
        callback = getattr(self, "_on_stop_movie_fn", None)
        if callback:
            callback()
        else:
            LOGGER.warning("Stop movie callback is not wired.")


    
    def _apply_movie_capture_preset(self, index: int, update_status: bool = True):
        if index == 1:
            index = 1
            label = "HD"
            width = 1920
            height = 1080
            fps = 30
        else:
            index = 0
            label = "Fast"
            width = 1280
            height = 720
            fps = 24

        self._movie_capture_quality_default_index = index
        self._model.movie_capture_width = width
        self._model.movie_capture_height = height
        self._model.movie_capture_fps = fps
        self._model.movie_capture_format = ".mp4"

        if update_status:
            self._set_status(
                f"Video quality preset: {label} ({width}x{height} @ {fps} fps)."
            )

    def _on_movie_capture_output_changed(self, model):
        try:
            self._model.movie_capture_output_dir = model.get_value_as_string().strip()
        except Exception:
            self._model.movie_capture_output_dir = ""

    def _on_movie_capture_name_changed(self, model):
        try:
            value = model.get_value_as_string().strip()
        except Exception:
            value = ""

        self._model.movie_capture_file_name = value or "tracking_motion_path"

    def _build_movie_capture_resolution_combo(self):
        self._movie_capture_resolution_combo = ui.ComboBox(
            self._movie_capture_resolution_default_index,
            *self._movie_capture_resolution_items,
            width=FIELD_WIDTH,
        )
        self._movie_capture_resolution_sub = (
            self._movie_capture_resolution_combo.model.subscribe_item_changed_fn(
                self._on_movie_capture_resolution_changed
            )
        )

    def _build_movie_capture_render_preset_combo(self):
        self._movie_capture_render_preset_combo = ui.ComboBox(
            self._movie_capture_render_preset_default_index,
            *self._movie_capture_render_preset_items,
            width=FIELD_WIDTH,
        )
        self._movie_capture_render_preset_sub = (
            self._movie_capture_render_preset_combo.model.subscribe_item_changed_fn(
                self._on_movie_capture_render_preset_changed
            )
        )

    def _on_movie_capture_resolution_changed(self, model, _item):
        try:
            index = model.get_item_value_model().get_value_as_int()
        except Exception:
            index = 0

        self._apply_movie_capture_output_profile(index)

    def _on_movie_capture_render_preset_changed(self, model, _item):
        try:
            index = model.get_item_value_model().get_value_as_int()
        except Exception:
            index = 0

        key = RENDER_PRESET_KEYS[index] if 0 <= index < len(RENDER_PRESET_KEYS) else "default_realtime"
        self._apply_movie_capture_render_preset_selection(key)

    def _on_load_movie_capture_preset(self):
        def _on_apply(filename: str, dirname: str):
            if not filename:
                return

            base_dir = str(dirname or "").rstrip("/\\")
            selected_path = f"{base_dir}/{filename}" if base_dir else str(filename)
            selected_path = selected_path.replace("\\", "/")

            validation_result = None
            if self._movie_capture_controller is not None:
                validation_result = self._movie_capture_controller.validate_render_preset_file(selected_path)
                if not validation_result.is_valid:
                    self._set_status(
                        "Invalid render preset: " + "; ".join(validation_result.errors)
                    )
                    return

            self._model.movie_capture_user_render_preset_path = selected_path
            self._movie_capture_user_preset_model.set_value(selected_path)

            self._apply_movie_capture_render_preset_selection("custom", update_status=False)

            if validation_result and validation_result.is_valid:
                warning_count = len(validation_result.warnings)
                self._set_status(
                    f"Loaded custom preset: {os.path.basename(selected_path)} "
                    f"({validation_result.applied_key_count} settings, {warning_count} warning(s))."
                )
            else:
                self._set_status(f"Loaded custom preset: {os.path.basename(selected_path)}")

            if self._preset_picker_dialog:
                self._preset_picker_dialog.hide()
                self._preset_picker_dialog = None

            self._window.frame.rebuild()

        self._preset_picker_dialog = filepicker.FilePickerDialog(
            title="Select Render Preset (.usd / .usda)",
            width=1000,
            height=600,
            click_apply_handler=_on_apply,
            file_extension_types=[(".usd", ".usda")],
            allow_multi_selection=False,
        )
        self._preset_picker_dialog.show()

    def _get_movie_capture_resolution_index_from_model(self) -> int:
        width = int(getattr(self._model, "movie_capture_width", 1280) or 1280)
        height = int(getattr(self._model, "movie_capture_height", 720) or 720)
        fps = int(getattr(self._model, "movie_capture_fps", 24) or 24)

        for index, profile in VIDEO_OUTPUT_PROFILES.items():
            if (
                int(profile["width"]) == width
                and int(profile["height"]) == height
                and int(profile["fps"]) == fps
            ):
                return index

        return 0

    def _apply_movie_capture_output_profile(self, index: int, update_status: bool = True):
        profile = VIDEO_OUTPUT_PROFILES.get(index, VIDEO_OUTPUT_PROFILES[0])

        self._movie_capture_resolution_default_index = index
        self._model.movie_capture_width = int(profile["width"])
        self._model.movie_capture_height = int(profile["height"])
        self._model.movie_capture_fps = int(profile["fps"])
        self._model.movie_capture_format = VIDEO_CAPTURE_FILE_TYPE

        if update_status:
            self._set_status(
                f"Output profile: {profile['label']} "
                f"({profile['width']}x{profile['height']} @ {profile['fps']} fps)."
            )

    def _get_movie_capture_render_preset_index_from_model(self) -> int:
        key = str(
            getattr(self._model, "movie_capture_render_preset", "default_realtime") or "default_realtime"
        ).strip().lower()

        try:
            return RENDER_PRESET_KEYS.index(key)
        except ValueError:
            return 0

    def _apply_movie_capture_render_preset_selection(self, key: str, update_status: bool = True):
        normalized = str(key or "default_realtime").strip().lower()
        if normalized not in RENDER_PRESET_LABELS:
            normalized = "default_realtime"

        self._model.movie_capture_render_preset = normalized
        self._movie_capture_render_preset_default_index = self._get_movie_capture_render_preset_index_from_model()

        if update_status:
            if normalized == "custom":
                preset_path = str(
                    getattr(self._model, "movie_capture_user_render_preset_path", "") or ""
                ).strip()
                if preset_path:
                    self._set_status(f"Render preset: Custom USD Preset ({os.path.basename(preset_path)}).")
                else:
                    self._set_status("Render preset: Custom USD Preset. Load a .usd / .usda file to use it.")
            else:
                self._set_status(f"Render preset: {RENDER_PRESET_LABELS[normalized]}.")

    def _get_video_output_profile(self):
        index = int(getattr(self, "_movie_capture_resolution_default_index", 0) or 0)
        return VIDEO_OUTPUT_PROFILES.get(index, VIDEO_OUTPUT_PROFILES[0])

    def _get_movie_capture_preset_summary_text(self) -> str:
        profile = self._get_video_output_profile()

        render_key = str(
            getattr(self._model, "movie_capture_render_preset", "default_realtime") or "default_realtime"
        ).strip().lower()

        if render_key == "custom":
            preset_path = str(
                getattr(self._model, "movie_capture_user_render_preset_path", "") or ""
            ).strip()
            render_label = f"Custom: {os.path.basename(preset_path)}" if preset_path else "Custom: no preset selected"
        else:
            render_label = RENDER_PRESET_LABELS.get(render_key, "Default Real-Time")

        return (
            f"{profile['width']}x{profile['height']} / "
            f"{profile['fps']} fps / "
            f"{render_label} / MP4"
        )

    def _on_movie_capture_start_seconds_changed(self, model):
            try:
                value = float(model.get_value_as_float())
            except Exception:
                try:
                    value = float(model.as_float)
                except Exception:
                    value = 0.0

            value = max(0.0, value)
            self._model.movie_capture_start_seconds = value

            # Keep end strictly after start
            current_end = float(getattr(self._model, "movie_capture_end_seconds", 10.0) or 10.0)
            if current_end <= value:
                new_end = value + 1.0
                self._model.movie_capture_end_seconds = new_end
                try:
                    self._movie_capture_end_seconds_model.set_value(new_end)
                except Exception:
                    pass

    def _on_movie_capture_end_seconds_changed(self, model):
        try:
            value = float(model.get_value_as_float())
        except Exception:
            try:
                value = float(model.as_float)
            except Exception:
                value = 10.0

        start_value = float(getattr(self._model, "movie_capture_start_seconds", 0.0) or 0.0)
        value = max(start_value + 1.0, value)

        self._model.movie_capture_end_seconds = value

        # If user typed something smaller than start+1, snap UI back
        try:
            current_ui_value = float(model.get_value_as_float())
        except Exception:
            current_ui_value = value

        if abs(current_ui_value - value) > 1e-6:
            try:
                self._movie_capture_end_seconds_model.set_value(value)
            except Exception:
                pass

    def _on_open_movie_capture_advanced(self):
        callback = getattr(self, "_on_open_movie_capture_advanced_fn", None)
        if callback:
            callback()
        else:
            LOGGER.warning("Open advanced movie capture callback is not wired.")
    # ------------------------------------------------------------------
    # Core callbacks
    # ------------------------------------------------------------------
    def _on_frame_range_changed(self, _model):
        try:
            start_frame = int(self._start_frame_model.get_value_as_int())
            end_frame = int(self._end_frame_model.get_value_as_int())
            if end_frame <= start_frame:
                self._set_status("End frame must be greater than start frame.")
                return

            if hasattr(self._scenario, "set_frame_range"):
                self._scenario.set_frame_range(start_frame, end_frame)
            else:
                self._model.start_frame = start_frame
                self._model.end_frame = end_frame

            self._set_status(f"Frame range set to {start_frame} -> {end_frame}.")
        except Exception as exc:
            self._set_status(str(exc))

    def _on_wheel_diameter_changed(self, model):
        try:
            value = float(model.get_value_as_float())
            if value <= 0.0:
                self._set_status("Wheel diameter must be greater than 0.")
                return

            for vehicle in self._model.vehicles:
                vehicle.wheel.wheel_diameter = value

            self._set_status(f"Wheel diameter set to {value:.3f} m for all vehicles.")
        except Exception as exc:
            self._set_status(str(exc))

    def _on_duration_changed(self, model):
        try:
            value = float(model.get_value_as_float())
            if value <= 0.0:
                self._set_status("Duration must be greater than 0.")
                return
            self._model.duration_seconds = value
            self._set_status(f"Duration set to {value:.2f} s.")
        except Exception as exc:
            self._set_status(str(exc))

    def _on_forward_axis_changed(self, item_model=None, item=None):
        try:
            if self._forward_axis_combo is None:
                return

            combo_model = self._forward_axis_combo.model
            value_model = combo_model.get_item_value_model()
            selected_index = int(value_model.as_int)

            if not (0 <= selected_index < len(self._forward_axis_items)):
                return

            axis = self._forward_axis_items[selected_index]

            # ✅ Update all vehicles non-destructively
            for index, adapter in enumerate(self._adapters):
                vehicle = self._model.get_vehicle(index)

                if not vehicle.enabled:
                    continue
                if not adapter.has_valid_motion_path():
                    continue

                # 1️⃣ Update forward axis (already correct)
                vehicle.forward_axis = axis
                adapter.update_forward_axis(axis)

                # 2️⃣ ✅ NEW: auto re-detect wheels using NEW axis
                try:
                    wheel_sync = self._wheel_sync_controllers[index]
                    selection = omni.usd.get_context().get_selection().get_selected_prim_paths()

                    LOGGER.info(
                            "Axis changed with no wheel selection — keeping existing wheel assignment."
                        )
                except Exception as exc:
                    LOGGER.warning(
                        "Wheel auto-detection failed after axis change: %s", exc
                    )

            self._set_status(
                f"Forward axis updated to {axis} and wheels re-evaluated."
            )
            self._refresh_labels()

        except Exception:
            LOGGER.exception("Forward axis update failed")
            self._set_status("Forward axis update failed.")

    # ------------------------------------------------------------------
    # Capture / graph actions
    # ------------------------------------------------------------------
    def _on_capture_vehicle(self):
        try:
            self._model.ensure_vehicle_count(1)
            self._ensure_adapters_match_model()
            vehicle_path = self._adapters[0].capture_vehicle_from_selection()
            self._set_status(f"Vehicle captured: {vehicle_path}")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_capture_path(self):
        try:
            self._model.ensure_vehicle_count(1)
            self._ensure_adapters_match_model()
            curve_path = self._adapters[0].capture_curve_from_selection()
            self._set_status(f"Curve captured: {curve_path}")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    # Backward-compatible alias if something else still calls it
    def _on_capture_curve(self):
        self._on_capture_path()

    def _on_capture_vehicle_index(self, index: int):
        try:
            self._model.ensure_vehicle_count(index + 1)
            self._ensure_adapters_match_model()
            vehicle_path = self._adapters[index].capture_vehicle_from_selection()
            self._set_status(f"{self._model.get_vehicle(index).name} captured: {vehicle_path}")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

   

    def _on_capture_vehicle_wheels_index(self, index: int):
        try:
            self._model.ensure_vehicle_count(index + 1)
            self._ensure_adapters_match_model()

            if index >= len(self._wheel_sync_controllers):
                raise RuntimeError(
                    f"No wheel controller available for vehicle index {index}"
                )

            app = omni.kit.app.get_app()

            # one subscription per vehicle index
            if not hasattr(self, "_wheel_capture_subs"):
                self._wheel_capture_subs = {}

            # prevent double-fire
            if index in self._wheel_capture_subs:
                return

            def do_capture(e=None, vehicle_index=index):
                try:
                    wheel_sync = self._wheel_sync_controllers[vehicle_index]
                    wheel = wheel_sync._wheel_settings()

                    wheel_sync.assign_wheels_from_selection()

                    if not wheel.all_paths():
                        raise RuntimeError(
                            f"{self._model.get_vehicle(vehicle_index).name}: "
                            "could not determine FL/FR/RL/RR."
                        )

                    self._set_status(
                        f"{self._model.get_vehicle(vehicle_index).name} wheels captured."
                    )

                finally:
                    # ✅ unsubscribe after one execution
                    sub = self._wheel_capture_subs.pop(vehicle_index, None)
                    if sub:
                        sub.unsubscribe()

                    self._refresh_labels()

            self._wheel_capture_subs[index] = (
                app.get_post_update_event_stream()
                .create_subscription_to_pop(do_capture)
            )

        except Exception as exc:
            self._set_status(str(exc))
            self._refresh_labels()

    def _on_apply_motion_path(self):
        try:
            self._model.ensure_vehicle_count(1)
            self._ensure_adapters_match_model()
            self._adapters[0].apply_motion_path()
            self._set_status("Motion Path graph created.")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_apply_motion_path_to_all(self):
        try:
            self._ensure_adapters_match_model()

            any_applied = False
            for index, adapter in enumerate(self._adapters):
                vehicle = self._model.get_vehicle(index)
                if not vehicle.enabled or not vehicle.rig_path:
                    continue

                adapter.apply_motion_path()
                any_applied = True

            if not any_applied:
                raise RuntimeError("No enabled captured vehicles available.")

            # ✅ CRITICAL: warm up ALL graphs once
            for adapter in self._adapters:
                if adapter.has_valid_motion_path():
                    adapter.evaluate_graph_now()

            # ✅ restore convoy spacing
            self._scenario._position_vehicles_at_scenario_start()

            self._set_status("Motion Path graph(s) created and initialized.")

        except Exception as exc:
            self._set_status(str(exc))

        self._refresh_labels()
 

    def _on_capture_wheels(self):
        try:
            self._model.ensure_vehicle_count(1)
            self._ensure_adapters_match_model()

            app = omni.kit.app.get_app()

            # Keep reference on self
            self._wheel_capture_sub = None

            def do_capture(e=None):
                try:
                    wheel_sync = self._wheel_sync_controllers[0]
                    wheel = wheel_sync._wheel_settings()

                    wheel_sync.assign_wheels_from_selection()

                    if not wheel.all_paths():
                        raise RuntimeError(
                            "Wheel capture failed: could not determine FL/FR/RL/RR."
                        )

                    self._set_status("Wheel pivots captured successfully.")
                    self._refresh_labels()

                finally:
                    # ✅ Unsubscribe after one execution
                    if self._wheel_capture_sub:
                        self._wheel_capture_sub.unsubscribe()
                        self._wheel_capture_sub = None

            self._wheel_capture_sub = (
                app.get_post_update_event_stream()
                .create_subscription_to_pop(do_capture)
            )

        except Exception as exc:
            self._set_status(str(exc))
            LOGGER.warning("Wheel capture failed: %s", exc)


    def _on_capture_steering_wheel(self):
        try:
            app = omni.kit.app.get_app()

            # prevent double subscriptions
            if getattr(self, "_steering_capture_sub", None):
                return

            def do_capture(e=None):
                try:
                    self._steering_wheel.assign_steering_wheel_from_selection()
                    self._set_status(
                        self._model.runtime.status_text
                        or "Steering wheel captured."
                    )
                    self._refresh_labels()
                finally:
                    # ✅ unsubscribe after one execution
                    if self._steering_capture_sub:
                        self._steering_capture_sub.unsubscribe()
                        self._steering_capture_sub = None

            self._steering_capture_sub = (
                app.get_post_update_event_stream()
                .create_subscription_to_pop(do_capture)
            )

        except Exception as exc:
            self._set_status(str(exc))
            self._refresh_labels()


    # ------------------------------------------------------------------
    # Scenario playback
    # ------------------------------------------------------------------
    def _on_start(self):
        try:
            self._scenario.start_scenario()
            self._set_status("Scenario running.")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_pause(self):
        try:
            self._scenario.pause_scenario()
            self._set_status(self._model.runtime.status_text or "Pause / Resume toggled.")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    def _on_stop(self):
        try:
            self._scenario.stop_and_reset()
            self._set_status("Scenario stopped and reset.")
        except Exception as exc:
            self._set_status(str(exc))
        self._refresh_labels()

    
    def _on_movie_capture_output_changed(self, model):
        self._model.movie_capture_output_dir = model.get_value_as_string().strip()
        self._window.frame.rebuild()

   

    

    # ------------------------------------------------------------------
    # Labels / runtime refresh
    # ------------------------------------------------------------------
    def _refresh_labels(self):
        if self._vehicle_label:
            self._vehicle_label.text = f"{getattr(self._model, 'vehicle_rig_path', None) or '-'}"

        if self._curve_label:
            self._curve_label.text = f"{getattr(self._model, 'curve_path', None) or '-'}"

        if self._wheels_label:
            if self._wheel_sync_controllers:
                self._wheels_label.text = self._wheel_sync_controllers[0].get_wheels_summary()
            else:
                self._wheels_label.text = self._model.wheel.summary()

        if self._driver_camera_label:
            self._driver_camera_label.text = f"{getattr(self._model, 'driver_camera_path', None) or '-'}"

        if self._spectator_camera_label:
            self._spectator_camera_label.text = f"{getattr(self._model, 'spectator_camera_path', None) or '-'}"

        if self._steering_wheel_label:
            self._steering_wheel_label.text = (
                self._steering_wheel.get_steering_wheel_summary()
                if self._steering_wheel
                else "-"
            )

        for vehicle_index, label in zip(self._vehicle_label_indices, self._vehicle_labels):
            vehicle = self._model.get_vehicle(vehicle_index)
            label.text = vehicle.rig_path or "-"

        for vehicle_index, label in zip(self._vehicle_wheels_label_indices, self._vehicle_wheels_labels):
            vehicle = self._model.get_vehicle(vehicle_index)
            label.text = vehicle.wheel.summary()

        if self._status_label:
            self._status_label.text = self._model.runtime.status_text

        self._refresh_runtime_labels()

    def _refresh_runtime_labels(self):
        if self._runtime_u_label:
            self._runtime_u_label.text = (
                f"U Value: {float(getattr(self._model.runtime, 'current_u_value', 0.0)):.3f}"
            )
        if self._runtime_angle_label:
            self._runtime_angle_label.text = (
                f"Wheel Angle: {float(getattr(self._model.runtime, 'current_wheel_angle', 0.0)):.3f}°"
            )
        if self._runtime_distance_label:
            self._runtime_distance_label.text = (
                f"Distance: {float(getattr(self._model.runtime, 'accumulated_distance', 0.0)):.3f}"
            )

    def _set_status(self, text: str):
        LOGGER.info(text)
        self._model.runtime.status_text = text
        if self._status_label:
            self._status_label.text = text

    def _get_current_selection_summary(self) -> str:
        try:
            selection = omni.usd.get_context().get_selection().get_selected_prim_paths()
            if selection:
                return ", ".join(selection)
        except Exception:
            LOGGER.debug("Failed to read selection.", exc_info=True)
        return "-"

    # ------------------------------------------------------------------
    # Stage / app update subscriptions
    # ------------------------------------------------------------------
    def _install_stage_subscription(self):
        try:
            ctx = omni.usd.get_context()
            stream = ctx.get_stage_event_stream()
            self._stage_sub = stream.create_subscription_to_pop(
                self._on_stage_event,
                name="tracking_motion_path.selection",
            )
        except Exception:
            LOGGER.debug("Stage event subscription not available.", exc_info=True)

    def _install_update_subscription(self):
        try:
            app = omni.kit.app.get_app()
            stream = app.get_update_event_stream()
            self._update_sub = stream.create_subscription_to_pop(
                self._on_app_update,
                name="tracking_motion_path.ui_refresh",
            )
        except Exception:
            LOGGER.debug("App update subscription not available.", exc_info=True)

    def _on_stage_event(self, event):
        try:
            if event.type == int(omni.usd.StageEventType.SELECTION_CHANGED):
                self._refresh_labels()
        except Exception:
            LOGGER.debug("Ignoring stage event.", exc_info=True)

    def _on_app_update(self, _event):
        try:
            if not self._window or not self._window.visible:
                return
            self._refresh_runtime_labels()
            if self._status_label:
                self._status_label.text = self._model.runtime.status_text
        except Exception:
            LOGGER.debug("Ignoring UI update tick.", exc_info=True)

    # ------------------------------------------------------------------
    # Global reset
    # ------------------------------------------------------------------
    def _on_global_reset(self):
        try:
            try:
                self._scenario.stop_and_reset()
            except Exception:
                LOGGER.debug("Scenario stop/reset failed during global reset.", exc_info=True)

            try:
                for controller in getattr(self, "_wheel_sync_controllers", []):
                    try:
                        controller.clear_wheels()
                    except Exception:
                        LOGGER.debug("Wheel cleanup failed for one controller during global reset.", exc_info=True)
            except Exception:
                LOGGER.debug("Wheel cleanup failed during global reset.", exc_info=True)

            try:
                if hasattr(self._steering_wheel, "clear_steering_wheel"):
                    self._steering_wheel.clear_steering_wheel()
            except Exception:
                LOGGER.debug("Steering wheel cleanup failed during global reset.", exc_info=True)

            try:
                if self._driver_camera:
                    self._driver_camera.reset_cameras()
            except Exception:
                LOGGER.debug("Camera cleanup failed during global reset.", exc_info=True)

            try:
                for adapter in getattr(self, "_adapters", []):
                    try:
                        adapter.reset_extension_state()
                    except Exception:
                        LOGGER.debug(
                            "Motion path cleanup failed for one adapter during global reset.",
                            exc_info=True,
                        )
            except Exception:
                LOGGER.debug("Motion path cleanup failed during global reset.", exc_info=True)

            self._model.reset_all()

            try:
                self._model.ensure_vehicle_count(1)
            except Exception:
                LOGGER.debug("Failed to restore default vehicle slot.", exc_info=True)

            self._start_frame_model.set_value(int(getattr(self._model, "start_frame", 0)))
            self._end_frame_model.set_value(int(getattr(self._model, "end_frame", 100)))
            

            if self._has_duration and self._duration_model is not None:
                self._duration_model.set_value(
                    float(getattr(self._model, "duration_seconds", 10.0))
                )

            current_axis = getattr(self._model, "vehicle_forward_axis", None) or "+X"
            if current_axis not in self._forward_axis_items:
                current_axis = "+X"
            self._model.vehicle_forward_axis = current_axis
            self._forward_axis_default_index = self._forward_axis_items.index(current_axis)

            try:
                self._ensure_adapters_match_model()
                if self._window and self._window.frame:
                    self._window.frame.rebuild()
            except Exception:
                LOGGER.debug("Failed to rebuild UI after global reset.", exc_info=True)

            self._set_status(
                "Global reset complete. All captures cleared and authored extension state removed."
            )
        except Exception as exc:
            self._set_status(f"Global reset failed: {exc}")

        try:
            orphan_removed = self._remove_orphan_tracking_graphs()
            if orphan_removed:
                LOGGER.warning("Removed %s orphan TrackingMotionPath graph(s).", orphan_removed)
        except Exception:
            LOGGER.debug("Failed removing orphan TrackingMotionPath graphs.", exc_info=True)

        self._refresh_labels()

    def _remove_orphan_tracking_graphs(self) -> int:
        stage = omni.usd.get_context().get_stage()
        if not stage:
            return 0

        graph_paths = []
        for prim in stage.Traverse():
            if not prim or not prim.IsValid():
                continue
            path = str(prim.GetPath())
            if prim.GetTypeName() == "OmniGraph" and path.startswith("/World/TrackingMotionPathGraph"):
                graph_paths.append(path)

        removed = 0
        for path in sorted(graph_paths, key=len, reverse=True):
            prim = stage.GetPrimAtPath(path)
            if prim and prim.IsValid():
                try:
                    stage.RemovePrim(path)
                    removed += 1
                except Exception:
                    LOGGER.exception("Failed removing orphan graph: %s", path)

        return removed

    # ------------------------------------------------------------------
    # Subscription
    # ------------------------------------------------------------------
    def _release_subscriptions(self):
        self._stage_sub = None
        self._update_sub = None
        self._forward_axis_sub = None
        self._gap_unit_sub = None

        self._start_frame_sub = None
        self._end_frame_sub = None
        self._wheel_diameter_sub = None
        self._duration_sub = None

        self._vehicle_offset_subs = []
        self._vehicle_enabled_subs = []

        self._driver_cam_x_sub = None
        self._driver_cam_y_sub = None
        self._driver_cam_z_sub = None
        self._driver_cam_rx_sub = None
        self._driver_cam_ry_sub = None
        self._driver_cam_rz_sub = None

        self._spectator_cam_x_sub = None
        self._spectator_cam_y_sub = None
        self._spectator_cam_z_sub = None
        self._spectator_cam_rx_sub = None
        self._spectator_cam_ry_sub = None
        self._spectator_cam_rz_sub = None

        self._spectator_above_x_sub = None
        self._spectator_above_y_sub = None
        self._spectator_above_z_sub = None
        self._spectator_above_rx_sub = None
        self._spectator_above_ry_sub = None
        self._spectator_above_rz_sub = None