import logging

import carb.input
import omni.appwindow

LOGGER = logging.getLogger("tracking_motion_path.gamepad_camera")


class GamepadCameraController:
    """
    Gamepad control for camera switching + driver camera Z rotation.

    Final mapping

        Physical button 1 -> X -> Driver camera
        Physical button 2 -> A -> Follow camera
        Physical button 3 -> B -> Above camera

        
        Physical button 5 -> RB / RIGHT_SHOULDER -> Stop
        Physical button 7 -> RT / RIGHT_TRIGGER  -> Pause / Resume
        Physical button 6 -> LT / LEFT_TRIGGER   -> Stop / Reset


    Right stick horizontal:
        RIGHT_STICK_LEFT / RIGHT_STICK_RIGHT -> adjust driver camera Z rotation
    """

    # ------------------------------------------------------------------
    # Final logical button mapping (based on your controller layout)
    # ------------------------------------------------------------------
    DRIVER_CAMERA_BUTTON = carb.input.GamepadInput.X
    FOLLOW_CAMERA_BUTTON = carb.input.GamepadInput.A
    ABOVE_CAMERA_BUTTON = carb.input.GamepadInput.B

    ROTATE_LEFT_INPUT = carb.input.GamepadInput.RIGHT_STICK_LEFT
    ROTATE_RIGHT_INPUT = carb.input.GamepadInput.RIGHT_STICK_RIGHT

    
    
    START_BUTTON = carb.input.GamepadInput.LEFT_SHOULDER     
    STOP_RESET_BUTTON = carb.input.GamepadInput.RIGHT_SHOULDER  
    PAUSE_RESUME_BUTTON = carb.input.GamepadInput.LEFT_TRIGGER

    SCENARIO_MODE_BUTTON = carb.input.GamepadInput.RIGHT_TRIGGER
  


    BUTTON_PRESS_THRESHOLD = 0.5
    STICK_DEADZONE = 0.15
    ROTATION_SPEED_DEG_PER_SEC = 90.0

    
    def __init__(
        self,
        model,
        driver_camera_controller,
        drive_controller=None,
        
        start_callback=None,
        pause_resume_callback=None,
        stop_reset_callback=None,

        scenario_mode_toggle_callback=None,

    ):
        self._model = model
        self._driver_camera_controller = driver_camera_controller
        self._drive_controller = drive_controller

        
        
        self._start_callback = start_callback
        self._pause_resume_callback = pause_resume_callback
        self._stop_reset_callback = stop_reset_callback
        self._scenario_mode_toggle_callback =scenario_mode_toggle_callback



        self._app_window = omni.appwindow.get_default_app_window()
        self._input = carb.input.acquire_input_interface()

        self._gamepad = None
        self._gamepad_event_sub = None

        self._right_stick_left_value = 0.0
        self._right_stick_right_value = 0.0


    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def startup(self):
        if self._app_window is None:
            LOGGER.warning("No app window available, cannot bind gamepad.")
            return

        try:
            self._gamepad = self._app_window.get_gamepad(0)
        except Exception:
            LOGGER.exception("Failed to acquire gamepad 0.")
            self._gamepad = None
            return

        if self._gamepad is None:
            LOGGER.warning("No gamepad 0 available.")
            return

        if self._gamepad_event_sub is None:
            self._gamepad_event_sub = self._input.subscribe_to_gamepad_events(
                self._gamepad,
                self._on_gamepad_event,
            )

        LOGGER.info("Gamepad camera controller subscribed.")
        
        self._driver_camera_controller.start_driver_look_updates()
        self._driver_camera_controller.set_driver_camera_z_input(0.0)


    def shutdown(self):
        if self._gamepad is not None and self._gamepad_event_sub is not None:
            try:
                self._input.unsubscribe_to_gamepad_events(
                    self._gamepad,
                    self._gamepad_event_sub,
                )
            except Exception:
                LOGGER.debug("Gamepad unsubscribe failed.", exc_info=True)

        self._gamepad_event_sub = None
        self._gamepad = None

        self._driver_camera_controller.set_driver_camera_z_input(0.0)
        self._driver_camera_controller.stop_driver_look_updates()

        self._right_stick_left_value = 0.0
        self._right_stick_right_value = 0.0


    # ------------------------------------------------------------------
    # Input callback
    # ------------------------------------------------------------------
    def _on_gamepad_event(self, event: carb.input.GamepadEvent):
        
        try:
            # Useful while validating the Logitech mapping in Kit logs
            LOGGER.debug(
                "Gamepad event: input=%s value=%.4f",
                event.input,
                float(event.value),
            )

            value = float(event.value)

            
            
            if (
                event.input == self.START_BUTTON
                and value > self.BUTTON_PRESS_THRESHOLD
            ):
                self._invoke_callback(self._start_callback, "start")
                return

            if (
                event.input == self.PAUSE_RESUME_BUTTON
                and value > self.BUTTON_PRESS_THRESHOLD
            ):
                self._invoke_callback(self._pause_resume_callback, "pause/resume")
                return

            if (
                event.input == self.STOP_RESET_BUTTON
                and value > self.BUTTON_PRESS_THRESHOLD
            ):
                self._invoke_callback(self._stop_reset_callback, "stop/reset")
                return
            

            
            if event.input == self.SCENARIO_MODE_BUTTON and value > self.BUTTON_PRESS_THRESHOLD:
                self._invoke_callback(
                    self._scenario_mode_toggle_callback,
                    "scenario mode toggle",
                )
                return




            
            if self._drive_controller is not None:
               self._drive_controller.handle_gamepad_event(event)


            # ----------------------------------------------------------
            # Camera switching
            # 1 (X) -> driver
            # 2 (A) -> follow
            # 3 (B) -> above
            # ----------------------------------------------------------
            if (
                event.input == self.DRIVER_CAMERA_BUTTON
                and float(event.value) > self.BUTTON_PRESS_THRESHOLD
            ):
                self._activate_driver_camera()
                return

            if (
                event.input == self.FOLLOW_CAMERA_BUTTON
                and float(event.value) > self.BUTTON_PRESS_THRESHOLD
            ):
                self._activate_follow_camera()
                return

            if (
                event.input == self.ABOVE_CAMERA_BUTTON
                and float(event.value) > self.BUTTON_PRESS_THRESHOLD
            ):
                self._activate_above_camera()
                return

            # ----------------------------------------------------------
            # Driver camera Z rotation only
            # Right stick horizontal controls the driver's camera yaw/Z
            # ----------------------------------------------------------
            
            if event.input == self.ROTATE_LEFT_INPUT:
                self._right_stick_left_value = float(event.value)
                self._push_driver_camera_input()
                return

            if event.input == self.ROTATE_RIGHT_INPUT:
                self._right_stick_right_value = float(event.value)
                self._push_driver_camera_input()
                return


        except Exception:
            LOGGER.exception("Gamepad camera event handling failed.")

    
    
    def _invoke_callback(self, callback, label: str):
        if callback is None:
            LOGGER.warning("No callback wired for gamepad action: %s", label)
            return
        try:
            callback()
            LOGGER.info("Gamepad action executed: %s", label)
        except Exception:
            LOGGER.exception("Failed to execute gamepad action: %s", label)


    # ------------------------------------------------------------------
    # Camera actions
    # ------------------------------------------------------------------
    def _activate_driver_camera(self):
        camera_path = getattr(self._model, "driver_camera_path", None)
        if not camera_path:
            self._driver_camera_controller.create_or_update_driver_camera()
        self._driver_camera_controller.activate_driver_camera()

    def _activate_follow_camera(self):
        camera_path = getattr(self._model, "spectator_camera_path", None)
        if not camera_path:
            self._driver_camera_controller.create_or_update_spectator_camera()
        self._driver_camera_controller.activate_spectator_camera()

    def _activate_above_camera(self):
        camera_path = getattr(self._model, "spectator_above_camera_path", None)
        if not camera_path:
            self._driver_camera_controller.create_or_update_spectator_above_camera()
        self._driver_camera_controller.activate_spectator_above_camera()



    def _push_driver_camera_input(self):
        raw = float(self._right_stick_left_value) - float(self._right_stick_right_value)
        raw = max(-1.0, min(1.0, raw))
        self._driver_camera_controller.set_driver_camera_z_input(raw)

