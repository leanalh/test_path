import logging

import carb.input
import omni.appwindow

LOGGER = logging.getLogger("tracking_motion_path.gamepad_camera")


class GamepadCameraController:
    """
    Gamepad control for camera switching + driver camera Z rotation.

    Final mapping

        Physical button 1 -> X -> Driver camera
        Physical button 2 -> A -> Follow camera
        Physical button 3 -> B -> Above camera

    Right stick horizontal:
        RIGHT_STICK_LEFT / RIGHT_STICK_RIGHT -> adjust driver camera Z rotation
    """

    # ------------------------------------------------------------------
    # Final logical button mapping (based on your controller layout)
    # ------------------------------------------------------------------
    DRIVER_CAMERA_BUTTON = carb.input.GamepadInput.X
    FOLLOW_CAMERA_BUTTON = carb.input.GamepadInput.A
    ABOVE_CAMERA_BUTTON = carb.input.GamepadInput.B

    ROTATE_LEFT_INPUT = carb.input.GamepadInput.RIGHT_STICK_LEFT
    ROTATE_RIGHT_INPUT = carb.input.GamepadInput.RIGHT_STICK_RIGHT

    BUTTON_PRESS_THRESHOLD = 0.5
    STICK_DEADZONE = 0.15
    ROTATION_SPEED_DEG_PER_EVENT = 2.0

    def __init__(self, model, driver_camera_controller):
        self._model = model
        self._driver_camera_controller = driver_camera_controller

        self._app_window = omni.appwindow.get_default_app_window()
        self._input = carb.input.acquire_input_interface()

        self._gamepad = None
        self._gamepad_event_sub = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def startup(self):
        if self._app_window is None:
            LOGGER.warning("No app window available, cannot bind gamepad.")
            return

        try:
            self._gamepad = self._app_window.get_gamepad(0)
        except Exception:
            LOGGER.exception("Failed to acquire gamepad 0.")
            self._gamepad = None
            return

        if self._gamepad is None:
            LOGGER.warning("No gamepad 0 available.")
            return

        if self._gamepad_event_sub is None:
            self._gamepad_event_sub = self._input.subscribe_to_gamepad_events(
                self._gamepad,
                self._on_gamepad_event,
            )
            LOGGER.info("Gamepad camera controller subscribed.")

    def shutdown(self):
        if self._gamepad is not None and self._gamepad_event_sub is not None:
            try:
                self._input.unsubscribe_to_gamepad_events(
                    self._gamepad,
                    self._gamepad_event_sub,
                )
            except Exception:
                LOGGER.debug("Gamepad unsubscribe failed.", exc_info=True)

        self._gamepad_event_sub = None
        self._gamepad = None

    # ------------------------------------------------------------------
    # Input callback
    # ------------------------------------------------------------------
    def _on_gamepad_event(self, event: carb.input.GamepadEvent):
        """
        event.input -> logical gamepad control (A/B/X/Y, stick direction, etc.)
        event.value -> float state / analog magnitude
        """
        try:
            # Useful while validating the Logitech mapping in Kit logs
            LOGGER.info(
                "Gamepad event: input=%s value=%.4f",
                event.input,
                float(event.value),
            )

            # ----------------------------------------------------------
            # Camera switching
            # 1 (X) -> driver
            # 2 (A) -> follow
            # 3 (B) -> above
            # ----------------------------------------------------------
            if (
                event.input == self.DRIVER_CAMERA_BUTTON
                and float(event.value) > self.BUTTON_PRESS_THRESHOLD
            ):
                self._activate_driver_camera()
                return

            if (
                event.input == self.FOLLOW_CAMERA_BUTTON
                and float(event.value) > self.BUTTON_PRESS_THRESHOLD
            ):
                self._activate_follow_camera()
                return

            if (
                event.input == self.ABOVE_CAMERA_BUTTON
                and float(event.value) > self.BUTTON_PRESS_THRESHOLD
            ):
                self._activate_above_camera()
                return

            # ----------------------------------------------------------
            # Driver camera Z rotation only
            # Right stick horizontal controls the driver's camera yaw/Z
            # ----------------------------------------------------------
            if event.input == self.ROTATE_LEFT_INPUT:
                val = float(event.value)
                if abs(val) >= self.STICK_DEADZONE:
                    self._driver_camera_controller.adjust_driver_camera_z(
                        val * self.ROTATION_SPEED_DEG_PER_EVENT
                    )
                return

            if event.input == self.ROTATE_RIGHT_INPUT:
                val = float(event.value)
                if abs(val) >= self.STICK_DEADZONE:
                    self._driver_camera_controller.adjust_driver_camera_z(
                        -val * self.ROTATION_SPEED_DEG_PER_EVENT
                    )
                return

        except Exception:
            LOGGER.exception("Gamepad camera event handling failed.")

    # ------------------------------------------------------------------
    # Camera actions
    # ------------------------------------------------------------------
    def _activate_driver_camera(self):
        camera_path = getattr(self._model, "driver_camera_path", None)
        if not camera_path:
            self._driver_camera_controller.create_or_update_driver_camera()
        self._driver_camera_controller.activate_driver_camera()

    def _activate_follow_camera(self):
        camera_path = getattr(self._model, "spectator_camera_path", None)
        if not camera_path:
            self._driver_camera_controller.create_or_update_spectator_camera()
        self._driver_camera_controller.activate_spectator_camera()

    def _activate_above_camera(self):
        camera_path = getattr(self._model, "spectator_above_camera_path", None)
        if not camera_path:
            self._driver_camera_controller.create_or_update_spectator_above_camera()
        self._driver_camera_controller.activate_spectator_above_camera()
