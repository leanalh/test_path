import logging

import carb.input
import omni.appwindow

LOGGER = logging.getLogger("tracking_motion_path.gamepad_drive")


class GamepadDriveController:
    """
    Routes gamepad throttle / brake / reverse events into a
    VehicleSpeedController. Parallel to GamepadCameraController so the two
    concerns (camera switching vs. drive input) stay independent.

    Mapping:
        RIGHT_TRIGGER -> throttle (0..1)
        LEFT_TRIGGER  -> brake    (0..1)
        Y button      -> toggle reverse on press
    """

    THROTTLE_INPUT = carb.input.GamepadInput.RIGHT_TRIGGER
    BRAKE_INPUT = carb.input.GamepadInput.LEFT_TRIGGER
    REVERSE_TOGGLE_BUTTON = carb.input.GamepadInput.Y

    BUTTON_PRESS_THRESHOLD = 0.5
    TRIGGER_DEADZONE = 0.05

    def __init__(self, model, speed_controller):
        self._model = model
        self._speed_controller = speed_controller

        self._app_window = omni.appwindow.get_default_app_window()
        self._input = carb.input.acquire_input_interface()

        self._gamepad = None
        self._gamepad_event_sub = None

        # Track the previous reverse-button value so we only act on
        # press-down edges (release events also fire with value=0).
        self._prev_reverse_value = 0.0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def startup(self):
        if self._app_window is None:
            LOGGER.warning(
                "No app window available; manual drive mode will not respond to gamepad."
            )
            self._publish_no_gamepad_warning()
            return

        try:
            self._gamepad = self._app_window.get_gamepad(0)
        except Exception:
            LOGGER.exception("Failed to acquire gamepad 0 for drive controller.")
            self._gamepad = None
            self._publish_no_gamepad_warning()
            return

        if self._gamepad is None:
            LOGGER.warning("No gamepad 0 connected; manual drive will not move the car.")
            self._publish_no_gamepad_warning()
            return

        if self._gamepad_event_sub is None:
            self._gamepad_event_sub = self._input.subscribe_to_gamepad_events(
                self._gamepad,
                self._on_gamepad_event,
            )
            LOGGER.info("Gamepad drive controller subscribed.")

    def shutdown(self):
        if self._gamepad is not None and self._gamepad_event_sub is not None:
            try:
                self._input.unsubscribe_to_gamepad_events(
                    self._gamepad,
                    self._gamepad_event_sub,
                )
            except Exception:
                LOGGER.debug("Drive gamepad unsubscribe failed.", exc_info=True)

        self._gamepad_event_sub = None
        self._gamepad = None

    def has_gamepad(self) -> bool:
        return self._gamepad is not None

    # ------------------------------------------------------------------
    # Input callback
    # ------------------------------------------------------------------
    def _on_gamepad_event(self, event: "carb.input.GamepadEvent"):
        # Drive input is meaningful only while a manual scenario is running.
        # In auto mode we silently drop everything so input doesn't leak into
        # the speed integrator next time the user switches modes.
        try:
            if not self._is_manual_drive_active():
                return

            value = float(event.value)

            if event.input == self.THROTTLE_INPUT:
                if value < self.TRIGGER_DEADZONE:
                    value = 0.0
                self._speed_controller.set_throttle(value)
                return

            if event.input == self.BRAKE_INPUT:
                if value < self.TRIGGER_DEADZONE:
                    value = 0.0
                self._speed_controller.set_brake(value)
                return

            if event.input == self.REVERSE_TOGGLE_BUTTON:
                # Edge-trigger on press, ignore release.
                if (
                    value > self.BUTTON_PRESS_THRESHOLD
                    and self._prev_reverse_value <= self.BUTTON_PRESS_THRESHOLD
                ):
                    new_state = self._speed_controller.toggle_reverse()
                    runtime = getattr(self._model, "runtime", None)
                    if runtime is not None:
                        runtime.status_text = (
                            "Reverse: ON" if new_state else "Reverse: OFF"
                        )
                self._prev_reverse_value = value
                return

        except Exception:
            LOGGER.exception("Gamepad drive event handling failed.")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _is_manual_drive_active(self) -> bool:
        if str(getattr(self._model, "scenario_mode", "auto")).lower() != "manual":
            return False
        runtime = getattr(self._model, "runtime", None)
        if runtime is None:
            return False
        return bool(getattr(runtime, "scenario_running", False))

    def _publish_no_gamepad_warning(self) -> None:
        runtime = getattr(self._model, "runtime", None)
        if runtime is not None:
            runtime.status_text = (
                "No gamepad detected — manual drive mode will not move the car."
            )
