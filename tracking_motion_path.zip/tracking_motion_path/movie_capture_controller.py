import logging
import os
from typing import Any, Dict, Optional

import omni.kit.app
import omni.timeline
import omni.ui as ui

from .render_preset_manager import RenderPresetManager

LOGGER = logging.getLogger("tracking_motion_path.movie_capture")



DEFAULT_REALTIME_RENDER_PRESET = {
    "render_preset_name": "RAY_TRACE",
    "ptmb_subframes_per_frame": 1,
    "path_trace_spp": 1,
    "spp_per_iteration": 1,
    "ptmb_fso": 0.0,
    "ptmb_fsc": 1.0,
    "real_time_settle_latency_frames": 0,
    "rt_wait_for_render_resolve_in_seconds": 0,
}

DEFAULT_PATHTRACE_RENDER_PRESET = {
    "render_preset_name": "PATH_TRACE",
    "ptmb_subframes_per_frame": 32,
    "path_trace_spp": 32,
    "spp_per_iteration": 1,
    "ptmb_fso": 0.0,
    "ptmb_fsc": 1.0,
    "real_time_settle_latency_frames": 0,
    "rt_wait_for_render_resolve_in_seconds": 0,
}


_BUILTIN_RENDER_PRESETS = {
    "default_realtime": DEFAULT_REALTIME_RENDER_PRESET,
    "default_pathtracing": DEFAULT_PATHTRACE_RENDER_PRESET,
}


# carb /rtx/rendermode value the viewport reads to switch RTX engines. Confirmed
# against omni.rtx.window.settings.rtx_settings_widget.engine_to_mode (Kit 109/110).
_BUILTIN_RENDER_MODE = {
    "default_realtime": "RaytracedLighting",
    "default_pathtracing": "PathTracing",
}


# Maps the internal builtin-preset field names to the carb.settings keys the
# viewport (and the capture backend) read. Keys without a true viewport-side
# equivalent (mb/*, sppPerIteration) are still pushed — they're harmless live
# and keep parity with what the capture path will set.
_BUILTIN_FIELD_TO_CARB_KEY = {
    "path_trace_spp": "/rtx/pathtracing/totalSpp",
    "spp_per_iteration": "/rtx/pathtracing/spp",
    "ptmb_subframes_per_frame": "/rtx/pathtracing/mb/subframes",
    "ptmb_fso": "/rtx/pathtracing/mb/fso",
    "ptmb_fsc": "/rtx/pathtracing/mb/fsc",
}


# Maps USD renderSettings keys (as they appear in customLayerData) to the
# CaptureOptions field that controls the same quantity in movie capture.
_USD_KEY_TO_CAPTURE_FIELD = {
    "rtx:pathtracing:spp": "path_trace_spp",
    "rtx:pathtracing:totalSpp": "path_trace_spp",
    "rtx:pathtracing:mb:subframes": "ptmb_subframes_per_frame",
    "rtx:pathtracing:mb:fso": "ptmb_fso",
    "rtx:pathtracing:mb:fsc": "ptmb_fsc",
    "rtx:pathtracing:sppPerIteration": "spp_per_iteration",
}


def get_builtin_render_preset(name: Optional[str]) -> Dict[str, Any]:
    key = str(name or "default_realtime").strip().lower()

    if key in {"default_pathtracing", "pathtracing", "path_trace", "hd"}:
        return DEFAULT_PATHTRACE_RENDER_PRESET

    return DEFAULT_REALTIME_RENDER_PRESET


class MovieCaptureController:


    def __init__(self, model, driver_camera_controller=None):
        self._model = model
        self._driver_camera_controller = driver_camera_controller
        self._timeline = omni.timeline.get_timeline_interface()
        self._app = omni.kit.app.get_app()

        self._capture_backend = None
        self._capture = None
        self._paused = False

        self._render_preset_manager = RenderPresetManager(
            schema=getattr(self._model, "movie_capture_render_preset_schema", None)
        )
        self._render_preset_restore_token: Optional[Dict[str, Any]] = None
        # Separate token for live-preview overrides (built-in defaults applied
        # via the dropdown). Capture-time custom presets use the token above.
        self._live_preset_restore_token: Optional[Dict[str, Any]] = None
        self._live_preset_key: Optional[str] = None

        if not hasattr(self._model, "movie_capture_render_preset"):
            self._model.movie_capture_render_preset = "default_realtime"

        if not hasattr(self._model, "movie_capture_user_render_preset_path"):
            self._model.movie_capture_user_render_preset_path = ""




    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def startup(self):
        self._ensure_capture_extensions()

        import omni.kit.capture.viewport as capture_viewport

        self._capture_backend = capture_viewport
        self._capture = capture_viewport.CaptureExtension.get_instance()
        self._bind_callbacks()

    def shutdown(self):
        try:
            self.stop()
        except Exception:
            LOGGER.debug("Movie capture shutdown stop failed.", exc_info=True)

        try:
            self.clear_live_preset()
        except Exception:
            LOGGER.debug("clear_live_preset failed during shutdown.", exc_info=True)

        self._capture = None
        self._capture_backend = None

    def _bind_callbacks(self):
        if self._capture is None:
            return

        try:
            self._capture.capture_finished_fn = self._on_capture_finished
        except Exception:
            LOGGER.debug("capture_finished_fn is not assignable on this Kit build.", exc_info=True)

        try:
            self._capture.progress_update_fn = self._on_capture_progress
        except Exception:
            LOGGER.debug("progress_update_fn is not assignable on this Kit build.", exc_info=True)

    # ------------------------------------------------------------------
    # Public UI callbacks
    # ------------------------------------------------------------------
    def record(self, request: Optional[Dict[str, Any]] = None):

        try:
            self._ensure_ready()

            if request:
                self._apply_request_to_model(request)

            custom_result = self._validate_custom_render_preset_if_needed()

            if self._capture and not self._capture.done and self._model.movie_capture_is_recording:
                LOGGER.warning("Movie capture is already running.")
                self._model.runtime.status_text = "Movie capture is already running."
                return

            # Push the custom preset's rtx:*/renderer:* entries into carb.settings
            # BEFORE building CaptureOptions so that any capture-backend code that
            # samples carb.settings during option construction sees the new values.
            if custom_result is not None:
                self._apply_custom_render_preset(custom_result)

            camera_path = self._resolve_camera_path()
            options = self._build_capture_options(
                camera_path,
                custom_result=custom_result,
            )
            if not options.is_valid():
                raise RuntimeError("Movie capture options are invalid.")

            self._capture = self._capture_backend.CaptureExtension.get_instance()
            self._bind_callbacks()
            self._capture.options = options

            # Use the stock Omniverse progress window.
            self._capture.show_default_progress_window = bool(
                getattr(self._model, "movie_capture_show_default_progress_window", True)
            )

            started = self._capture.start()
            if not started:
                raise RuntimeError(
                    "Capture failed to start. Check output path permissions, active camera, "
                    "and that omni.videoencoding is enabled."
                )

            self._paused = False
            self._model.movie_capture_is_recording = True
            self._model.movie_capture_is_paused = False
            self._model.runtime.movie_capture_progress_fraction = 0.0
            self._model.runtime.movie_capture_progress_text = "Starting movie capture..."
            self._model.runtime.status_text = f"Movie capture started: {options.get_full_path()}"
            LOGGER.info("Movie capture started: %s", options.get_full_path())

        except Exception as exc:
            self._restore_render_preset_settings()
            self._model.movie_capture_is_recording = False
            self._model.movie_capture_is_paused = False
            self._model.runtime.last_error = str(exc)
            self._model.runtime.status_text = f"Movie capture failed: {exc}"
            LOGGER.exception("Movie capture failed to start.")


    def pause_or_resume(self):
        # CaptureExtension.pause() in omni.kit.capture.viewport references
        # self._ui_pause_button, an attribute that only exists on the bundled
        # CaptureProgressWindow — so calling _capture.pause() directly raises
        # AttributeError on this Kit build. The bundled Movie Capture window
        # works around it by toggling _progress.capture_status itself; we do
        # the same. The capture loop drives the timeline only while status ==
        # CAPTURING, so flipping the status is what actually pauses a SEQUENCE
        # capture — do NOT also pause the timeline (it's under set_auto_update
        # (False) for the duration of the capture and would desync).
        try:
            self._ensure_ready()

            if not self._model.movie_capture_is_recording or self._capture is None:
                self._model.runtime.status_text = "No active movie capture to pause or resume."
                return

            CaptureStatus = self._capture_backend.CaptureStatus
            progress = getattr(self._capture, "_progress", None)
            if progress is None:
                raise RuntimeError("CaptureExtension has no _progress object on this Kit build.")

            is_pathtracing = (
                str(getattr(self._model, "movie_capture_render_preset", "") or "")
                .strip().lower() in {"default_pathtracing", "pathtracing", "path_trace"}
            )

            if self._paused:
                if progress.capture_status != CaptureStatus.PAUSED:
                    self._model.runtime.status_text = (
                        "Capture is no longer paused; ignoring resume."
                    )
                    self._paused = False
                    self._model.movie_capture_is_paused = False
                    return
                progress.capture_status = CaptureStatus.CAPTURING
                self._paused = False
                self._model.movie_capture_is_paused = False
                self._model.runtime.status_text = "Movie capture resumed."
                LOGGER.info("Movie capture resumed (status -> CAPTURING).")
            else:
                if progress.capture_status != CaptureStatus.CAPTURING:
                    # Encoding / finishing / cancelled — no longer pausable.
                    self._model.runtime.status_text = (
                        "Capture is past the pausable phase (encoding or finishing)."
                    )
                    return
                progress.capture_status = CaptureStatus.PAUSED
                self._paused = True
                self._model.movie_capture_is_paused = True
                if is_pathtracing:
                    # PT sequence captures pause at the next frame boundary,
                    # not mid-iteration. The status flip still takes effect.
                    self._model.runtime.status_text = (
                        "Movie capture paused (path-traced: pauses at next frame)."
                    )
                else:
                    self._model.runtime.status_text = "Movie capture paused."
                LOGGER.info("Movie capture paused (status -> PAUSED, pathtracing=%s).", is_pathtracing)

        except Exception as exc:
            self._model.runtime.last_error = str(exc)
            self._model.runtime.status_text = f"Pause / Resume failed: {exc}"
            LOGGER.exception("Movie capture pause/resume failed.")

    def stop(self):
        try:
            self._ensure_ready()

            if not self._model.movie_capture_is_recording or self._capture is None:
                # Even if the model thinks nothing is recording, make sure we
                # do not leave behind preset settings from a failed start.
                self._restore_render_preset_settings()
                self._model.runtime.status_text = "No active movie capture to stop."
                return

            self._capture.cancel()
            self._restore_render_preset_settings()
            self._paused = False
            self._model.movie_capture_is_recording = False
            self._model.movie_capture_is_paused = False
            self._model.runtime.movie_capture_progress_fraction = 0.0
            self._model.runtime.movie_capture_progress_text = "Movie capture cancelled."
            self._model.runtime.status_text = "Movie capture stopped."
            LOGGER.info("Movie capture stopped.")

        except Exception as exc:
            self._model.runtime.last_error = str(exc)
            self._model.runtime.status_text = f"Stop failed: {exc}"
            LOGGER.exception("Movie capture stop failed.")

    def open_advanced_settings(self):
        """
        Best-effort: enable and show the original Omniverse Movie Capture window.
        """
        try:
            self._ensure_capture_extensions()
            ui.Workspace.show_window("Movie Capture")
            self._model.runtime.status_text = "Opened Omniverse Movie Capture window."
        except Exception as exc:
            self._model.runtime.last_error = str(exc)
            self._model.runtime.status_text = f"Could not open advanced Movie Capture window: {exc}"
            LOGGER.exception("Failed opening advanced Movie Capture window.")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _ensure_capture_extensions(self):
        ext_mgr = self._app.get_extension_manager()
        required = [
            "omni.kit.capture.viewport",
            "omni.kit.window.movie_capture",
            "omni.videoencoding",
        ]

        for ext_name in required:
            try:
                if not ext_mgr.is_extension_enabled(ext_name):
                    ext_mgr.set_extension_enabled(ext_name, True)
            except Exception:
                LOGGER.debug("Failed enabling extension: %s", ext_name, exc_info=True)

    def _ensure_ready(self):
        if self._capture_backend is None:
            self.startup()

    def _apply_request_to_model(self, request: Dict[str, Any]):
        if "output_folder" in request:
            self._model.movie_capture_output_dir = str(request["output_folder"] or "")
        if "file_name" in request:
            self._model.movie_capture_file_name = str(request["file_name"] or "tracking_motion_path")
        if "res_width" in request:
            self._model.movie_capture_width = int(request["res_width"])
        if "res_height" in request:
            self._model.movie_capture_height = int(request["res_height"])
        if "fps" in request:
            self._model.movie_capture_fps = int(request["fps"])
        if "file_type" in request:
            self._model.movie_capture_format = str(request["file_type"] or ".mp4")

        # Only honor explicit start/end overrides when the user is in custom
        # range mode — in auto mode they're derived from scenario duration and
        # the request's seconds fields are stale mirrors.
        range_mode = str(getattr(self._model, "movie_capture_range_mode", "auto") or "auto").lower()
        if range_mode == "custom":
            if "start_time" in request:
                self._model.movie_capture_start_seconds = float(request["start_time"])
            if "end_time" in request:
                self._model.movie_capture_end_seconds = float(request["end_time"])

        if "quality_index" in request:
            self._model.movie_capture_quality_index = int(request["quality_index"])

        if "render_preset" in request:
            self._model.movie_capture_render_preset = str(
                request["render_preset"] or "default_realtime"
            ).strip().lower()

        if "custom_render_preset_path" in request:
            self._model.movie_capture_user_render_preset_path = str(
                request["custom_render_preset_path"] or ""
            ).strip()

        # Backward compatibility, if any old caller still sends "preset"
        if "preset" in request and "render_preset" not in request:
            self._model.movie_capture_render_preset = str(
                request["preset"] or "default_realtime"
            ).strip().lower()


    def _resolve_camera_path(self) -> str:
        return self._get_active_viewport_camera_path()

    def _get_active_viewport_camera_path(self) -> str:
        try:
            import omni.kit.viewport.utility as vp_utils

            viewport = vp_utils.get_active_viewport()
            if viewport is not None:
                camera_path = getattr(viewport, "camera_path", None)
                if camera_path:
                    return getattr(camera_path, "pathString", str(camera_path))
        except Exception:
            LOGGER.debug("Failed reading active viewport camera.", exc_info=True)

        return "/OmniverseKit_Persp"

    def _resolve_named_camera(self, attr_name: str, create_fn_name: Optional[str] = None) -> str:
        camera_path = getattr(self._model, attr_name, None)
        if camera_path:
            return str(camera_path)

        if self._driver_camera_controller and create_fn_name:
            create_fn = getattr(self._driver_camera_controller, create_fn_name, None)
            if callable(create_fn):
                try:
                    create_fn()
                    camera_path = getattr(self._model, attr_name, None)
                    if camera_path:
                        return str(camera_path)
                except Exception:
                    LOGGER.debug("Could not auto-create camera for movie capture.", exc_info=True)

        return self._get_active_viewport_camera_path()

    def _build_capture_options(self, camera_path: str, custom_result=None):
        output_dir = str(getattr(self._model, "movie_capture_output_dir", "") or "").strip()
        file_name = str(
            getattr(self._model, "movie_capture_file_name", "tracking_motion_path") or "tracking_motion_path"
        ).strip()

        if not output_dir:
            output_dir = os.path.join(os.path.expanduser("~"), "Videos", "tracking_motion_path")

        os.makedirs(output_dir, exist_ok=True)

        # Strip any extension the user might have typed into the file name; the
        # CaptureExtension will append options.file_type itself.
        file_name_root, ext = os.path.splitext(file_name)
        if ext.lower() in {".mp4", ".png", ".tga", ".exr"}:
            file_name = file_name_root or "tracking_motion_path"

        width = max(1, int(getattr(self._model, "movie_capture_width", 1280) or 1280))
        height = max(1, int(getattr(self._model, "movie_capture_height", 720) or 720))
        fps = max(1, int(getattr(self._model, "movie_capture_fps", 24) or 24))

        range_mode = str(
            getattr(self._model, "movie_capture_range_mode", "auto") or "auto"
        ).lower()

        if range_mode == "auto":
            # Track the scenario's derived duration; ignore any stale seconds
            # values stored on the model.
            start_time = 0.0
            duration = float(getattr(self._model, "duration_seconds", 0.0) or 0.0)
            end_time = duration if duration > 0.0 else 1.0
        else:
            start_time = max(0.0, float(getattr(self._model, "movie_capture_start_seconds", 0.0) or 0.0))
            end_time = float(getattr(self._model, "movie_capture_end_seconds", 10.0) or 10.0)

        if end_time <= start_time:
            end_time = start_time + 1.0

        render_preset_settings = self._resolve_render_preset_settings(custom_result)

        options = self._capture_backend.CaptureOptions()
        options.camera = camera_path
        options.output_folder = output_dir
        options.file_name = file_name
        options.file_type = ".mp4"

        # Seconds-only range
        options.range_type = self._capture_backend.CaptureRangeType.SECONDS
        options.start_frame = int(start_time * fps)
        options.end_frame = int(end_time * fps)

        options.res_width = width
        options.res_height = height
        options.fps = fps
        options.overwrite_existing_frames = True
        options.movie_type = self._capture_backend.CaptureMovieType.SEQUENCE

        # Resolve Omniverse render preset enum
        render_preset_enum = self._capture_backend.CaptureRenderPreset
        render_preset = getattr(
            render_preset_enum,
            render_preset_settings["render_preset_name"],
            None,
        )
        if render_preset is None:
            render_preset = render_preset_enum.RAY_TRACE

        options.render_preset = render_preset

        # Sampling / subframes. Every assignment is guarded so a field missing
        # on a given Kit build (109 vs 110 drift) doesn't abort the capture.
        self._assign_option(options, "spp_per_iteration", int(render_preset_settings["spp_per_iteration"]))
        self._assign_option(options, "path_trace_spp", int(render_preset_settings["path_trace_spp"]))
        self._assign_option(options, "ptmb_subframes_per_frame", int(render_preset_settings["ptmb_subframes_per_frame"]))
        self._assign_option(options, "ptmb_fso", float(render_preset_settings["ptmb_fso"]))
        self._assign_option(options, "ptmb_fsc", float(render_preset_settings["ptmb_fsc"]))
        self._assign_option(
            options,
            "real_time_settle_latency_frames",
            int(render_preset_settings["real_time_settle_latency_frames"]),
        )
        self._assign_option(
            options,
            "rt_wait_for_render_resolve_in_seconds",
            int(render_preset_settings["rt_wait_for_render_resolve_in_seconds"]),
        )

        return options

    @staticmethod
    def _assign_option(options, field_name: str, value: Any) -> None:
        if not hasattr(options, field_name):
            LOGGER.debug(
                "CaptureOptions has no field %r on this Kit build; skipping.", field_name
            )
            return
        try:
            setattr(options, field_name, value)
        except Exception:
            LOGGER.debug(
                "CaptureOptions rejected %s=%r on this Kit build.",
                field_name,
                value,
                exc_info=True,
            )


    def validate_render_preset_file(self, preset_path: str):
        return self._render_preset_manager.validate_file(preset_path)

    def _validate_custom_render_preset_if_needed(self):
        selected = str(
            getattr(self._model, "movie_capture_render_preset", "default_realtime") or "default_realtime"
        ).strip().lower()

        if selected != "custom":
            return None

        preset_path = str(
            getattr(self._model, "movie_capture_user_render_preset_path", "") or ""
        ).strip()

        result = self._render_preset_manager.validate_file(preset_path)
        if not result.is_valid:
            joined_errors = "; ".join(result.errors or ["Unknown preset validation error."])
            raise RuntimeError(f"Custom render preset is invalid: {joined_errors}")

        return result

    def _apply_custom_render_preset(self, validation_result):
        """
        Push every rtx:*/renderer:* key from the preset into carb.settings and
        stash a restore token so the originals can be put back after capture.
        """
        preset_path = validation_result.path

        _, restore_token = self._render_preset_manager.apply_preset_to_carb_settings(preset_path)
        self._render_preset_restore_token = restore_token

        LOGGER.info(
            "Applied %d render preset entries to carb.settings from %s",
            len(restore_token or {}),
            preset_path,
        )

    def _restore_render_preset_settings(self) -> None:
        token = self._render_preset_restore_token
        if not token:
            return
        try:
            self._render_preset_manager.restore_settings(token)
        except Exception:
            LOGGER.exception("Failed restoring render preset carb.settings.")
        finally:
            self._render_preset_restore_token = None

    # ------------------------------------------------------------------
    # Live render-preset preview (viewport mirrors the capture preset)
    # ------------------------------------------------------------------
    def apply_live_preset(self, preset_key: Optional[str]) -> None:
        """
        Switch the viewport's RTX render mode and quality settings to match a
        built-in preset so the user can see what the capture will look like.
        Skips silently for "custom" — that path is handled by the file picker.
        """
        normalized = str(preset_key or "default_realtime").strip().lower()

        if normalized == "custom":
            return

        if normalized not in _BUILTIN_RENDER_MODE:
            LOGGER.debug("apply_live_preset: unknown preset %r, ignoring.", normalized)
            return

        # Restore any prior live preview before stacking a new one — otherwise
        # toggling realtime <-> pathtracing would accumulate stale prior values.
        self._restore_live_preset_settings()

        builtin = _BUILTIN_RENDER_PRESETS[normalized]
        carb_dict: Dict[str, Any] = {"/rtx/rendermode": _BUILTIN_RENDER_MODE[normalized]}
        for field, carb_key in _BUILTIN_FIELD_TO_CARB_KEY.items():
            if field in builtin:
                carb_dict[carb_key] = builtin[field]

        try:
            token = self._render_preset_manager.apply_carb_settings_dict(carb_dict)
            self._live_preset_restore_token = token
            self._live_preset_key = normalized
            LOGGER.info(
                "Live render preset applied: %s (rendermode=%s)",
                normalized,
                carb_dict["/rtx/rendermode"],
            )
        except Exception as exc:
            self._model.runtime.last_error = str(exc)
            self._model.runtime.status_text = f"Live preset apply failed: {exc}"
            LOGGER.exception("apply_live_preset failed for %s.", normalized)

    def clear_live_preset(self) -> None:
        """Restore any live-preview overrides on the viewport."""
        self._restore_live_preset_settings()

    def _restore_live_preset_settings(self) -> None:
        token = self._live_preset_restore_token
        if not token:
            self._live_preset_key = None
            return
        try:
            self._render_preset_manager.restore_settings(token)
        except Exception:
            LOGGER.exception("Failed restoring live preset carb.settings.")
        finally:
            self._live_preset_restore_token = None
            self._live_preset_key = None

    def reset_render_preset(self) -> None:
        """
        Reset the render-preset state to default real-time. Restores any custom
        or built-in carb.settings overrides, clears the user preset path, and
        re-applies the default real-time live preview. No-op (with a warning)
        during an active capture so we don't corrupt encoded output.
        """
        if self._model.movie_capture_is_recording:
            self._model.runtime.status_text = (
                "Cannot reset render preset during active capture."
            )
            return

        # Restore in order: custom-capture overrides, then live overrides.
        self._restore_render_preset_settings()
        self._restore_live_preset_settings()

        self._model.movie_capture_user_render_preset_path = ""
        self._model.movie_capture_render_preset = "default_realtime"
        self.apply_live_preset("default_realtime")
        self._model.runtime.status_text = "Render preset reset to default real-time."



    def _resolve_render_preset_settings(self, custom_result=None) -> Dict[str, Any]:
        selected = str(
            getattr(self._model, "movie_capture_render_preset", "default_realtime")
            or "default_realtime"
        ).strip().lower()

        if selected != "custom":
            return get_builtin_render_preset(selected)

        # Custom preset: start from the renderer-appropriate defaults and then
        # overlay any CaptureOptions-relevant values read straight from the
        # preset's customLayerData["renderSettings"] dict.
        if custom_result is not None and custom_result.renderer_mode == "RTX Interactive":
            settings: Dict[str, Any] = dict(DEFAULT_PATHTRACE_RENDER_PRESET)
        else:
            settings = dict(DEFAULT_REALTIME_RENDER_PRESET)

        if custom_result is None:
            return settings

        preset_values = getattr(custom_result, "valid_settings", None) or {}

        # Track which fields the preset actually overrode so a later USD key
        # with a matching CaptureOptions field does not stomp a more specific
        # earlier mapping (see totalSpp / spp ordering below).
        applied_fields = set()

        for usd_key, capture_field in _USD_KEY_TO_CAPTURE_FIELD.items():
            if usd_key not in preset_values:
                continue
            if capture_field in applied_fields:
                # Prefer the first (more specific) mapping we already took.
                LOGGER.debug(
                    "Preset key %s also maps to %s; keeping earlier value.",
                    usd_key,
                    capture_field,
                )
                continue

            raw_value = preset_values[usd_key]
            try:
                settings[capture_field] = self._coerce_capture_field(capture_field, raw_value)
                applied_fields.add(capture_field)
                LOGGER.debug(
                    "Custom preset: %s -> options.%s = %r", usd_key, capture_field, settings[capture_field]
                )
            except Exception:
                LOGGER.debug(
                    "Could not coerce preset value for %s (%r); using built-in default.",
                    usd_key,
                    raw_value,
                    exc_info=True,
                )

        # Log the RTX keys we did not translate into a CaptureOptions field.
        # Those are still pushed into carb.settings via apply_preset_to_carb_settings,
        # but it helps diagnose missing mappings.
        for usd_key in preset_values:
            if usd_key not in _USD_KEY_TO_CAPTURE_FIELD:
                LOGGER.debug(
                    "Custom preset key %s has no CaptureOptions mapping; "
                    "applied via carb.settings only.",
                    usd_key,
                )

        return settings

    @staticmethod
    def _coerce_capture_field(capture_field: str, value: Any) -> Any:
        # CaptureOptions has strict types on these fields; match them.
        int_fields = {
            "path_trace_spp",
            "ptmb_subframes_per_frame",
            "spp_per_iteration",
            "real_time_settle_latency_frames",
            "rt_wait_for_render_resolve_in_seconds",
        }
        float_fields = {"ptmb_fso", "ptmb_fsc"}

        if capture_field in int_fields:
            return int(value)
        if capture_field in float_fields:
            return float(value)
        return value



    # ------------------------------------------------------------------
    # Progress / finished callbacks
    # ------------------------------------------------------------------
    def _on_capture_progress(
        self,
        capture_status=None,
        progress=None,
        elapsed_time=None,
        estimated_time_remaining=None,
        current_frame_time=None,
        average_frame_time=None,
        encoding_time=None,
        frame_counter=None,
        total_frame_count=None,
        *extra_args,
        **_kwargs,
    ):

        try:
            completed = int(frame_counter or 0)
            total = int(total_frame_count or 0)
            if total > 0:
                fraction = max(0.0, min(1.0, float(completed) / float(total)))
            else:
                try:
                    fraction = max(0.0, min(1.0, float(progress or 0.0)))
                except Exception:
                    fraction = 0.0

            self._model.runtime.movie_capture_current_frame = completed
            self._model.runtime.movie_capture_total_frames = total
            self._model.runtime.movie_capture_progress_fraction = fraction
            if total > 0:
                self._model.runtime.movie_capture_progress_text = (
                    f"Movie capture in progress: {completed}/{total} frames"
                )
            else:
                self._model.runtime.movie_capture_progress_text = "Movie capture in progress..."
            self._model.runtime.status_text = self._model.runtime.movie_capture_progress_text

        except Exception:
            LOGGER.debug("Failed to process movie capture progress.", exc_info=True)

    def _on_capture_finished(self, *_args, **_kwargs):
        self._restore_render_preset_settings()

        # Resolve the output path directly from options. Do NOT call
        # self._capture.get_outputs() here: CaptureExtension._finish() invokes
        # capture_finished_fn() BEFORE self._progress.finish_capturing(), so
        # self._capture.done is still False when this callback runs, and
        # get_outputs() logs a spurious "Capture not done, no output files"
        # warning and returns []. For video captures (the only mode this
        # controller produces) get_outputs() would have returned
        # [options.get_full_path()] anyway, so read it straight from options.
        outputs = []
        try:
            opts = getattr(self._capture, "options", None) if self._capture is not None else None
            is_video = bool(opts and hasattr(opts, "is_video") and opts.is_video())
            if is_video and hasattr(opts, "get_full_path"):
                outputs = [opts.get_full_path()]
            elif opts is not None and self._capture is not None and self._capture.done:
                # Non-video path (image sequence) — only safe when the backend
                # has actually flipped to DONE, otherwise get_outputs() warns.
                outputs = self._capture.get_outputs() or []
        except Exception:
            LOGGER.debug("Could not read capture outputs.", exc_info=True)

        self._paused = False
        self._model.movie_capture_is_recording = False
        self._model.movie_capture_is_paused = False
        self._model.runtime.movie_capture_progress_fraction = 1.0
        self._model.runtime.movie_capture_progress_text = "Movie capture finished."

        if outputs:
            self._model.runtime.status_text = f"Movie capture finished: {outputs[0]}"
            LOGGER.info("Movie capture finished: %s", outputs[0])
        else:
            self._model.runtime.status_text = "Movie capture finished."
            LOGGER.info("Movie capture finished.")
